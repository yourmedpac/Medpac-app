import { NextRequest, NextResponse } from 'next/server';
import { generateAIDailyInsight } from '@/lib/ai';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { answers, scores, streak, recentCheckIns } = body;

    if (!answers) {
      return NextResponse.json(
        { error: 'Quiz answers are required' },
        { status: 400 }
      );
    }

    const scoresData = scores || {
      overallScore: 60,
      goalCategory: answers.q1 || 'fat_loss',
      fitnessLevel: 'beginner',
      readinessScore: 60,
      consistencyScore: 50,
    };

    const insight = await generateAIDailyInsight(
      answers,
      scoresData,
      streak || 0,
      recentCheckIns || []
    );

    return NextResponse.json({
      success: true,
      insight,
    });
  } catch (error) {
    console.error('Daily insight generation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate daily insight' },
      { status: 500 }
    );
  }
}
