import { NextRequest, NextResponse } from 'next/server';
import { generateAIWorkoutPlan, generateAIMealPlan } from '@/lib/ai';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { answers, scores } = body;

    if (!answers) {
      return NextResponse.json(
        { error: 'Quiz answers are required' },
        { status: 400 }
      );
    }

    const scoresData = scores || {
      readinessScore: 60,
      consistencyScore: 50,
      bodyTransformationScore: 55,
      nutritionComplianceScore: 50,
      supportNeedScore: 50,
      overallScore: 53,
      fitnessLevel: 'beginner',
      goalCategory: answers.q1 || 'fat_loss',
      bodyType: answers.q8 || 'average',
    };

    // Generate both plans in parallel
    const [workoutPlan, mealPlan] = await Promise.all([
      generateAIWorkoutPlan(answers, scoresData),
      generateAIMealPlan(answers, scoresData),
    ]);

    return NextResponse.json({
      success: true,
      workoutPlan,
      mealPlan,
    });
  } catch (error) {
    console.error('Plan generation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate plans' },
      { status: 500 }
    );
  }
}
