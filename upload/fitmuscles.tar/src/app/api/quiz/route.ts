import { NextRequest, NextResponse } from 'next/server';
import { calculateScores } from '@/lib/scoring';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { answers } = body;

    if (!answers) {
      return NextResponse.json(
        { error: 'Answers are required' },
        { status: 400 }
      );
    }

    const scores = calculateScores(answers);

    return NextResponse.json({
      success: true,
      scores,
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to calculate scores' },
      { status: 500 }
    );
  }
}
