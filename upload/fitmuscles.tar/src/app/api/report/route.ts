import { NextRequest, NextResponse } from 'next/server';
import { generateAIReport } from '@/lib/ai';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { answers, scores } = body;

    if (!answers || !scores) {
      return NextResponse.json(
        { error: 'Answers and scores are required' },
        { status: 400 }
      );
    }

    const report = await generateAIReport(answers, scores);

    return NextResponse.json({
      success: true,
      report,
    });
  } catch (error) {
    console.error('Report generation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate report' },
      { status: 500 }
    );
  }
}
