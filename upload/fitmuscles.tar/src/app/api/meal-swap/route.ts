import { NextRequest, NextResponse } from 'next/server';
import { generateAIMealSwap } from '@/lib/ai';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { currentMeal, answers, remainingCalories, remainingProtein } = body;

    if (!currentMeal || !answers) {
      return NextResponse.json(
        { error: 'Current meal and quiz answers are required' },
        { status: 400 }
      );
    }

    const swap = await generateAIMealSwap(
      currentMeal,
      answers,
      remainingCalories || 500,
      remainingProtein || 30
    );

    return NextResponse.json({
      success: true,
      swap,
    });
  } catch (error) {
    console.error('Meal swap generation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate meal swap' },
      { status: 500 }
    );
  }
}
