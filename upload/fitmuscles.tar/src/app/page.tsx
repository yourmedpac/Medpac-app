'use client';

import { useStore } from '@/lib/store';
import type { ScreenName } from '@/lib/types';
import TopBar from '@/components/layout/TopBar';
import BottomNav from '@/components/layout/BottomNav';
import LandingPage from '@/components/screens/LandingPage';
import LanguageSelect from '@/components/screens/LanguageSelect';
import AuthScreen from '@/components/screens/AuthScreen';
import QuizFlow from '@/components/screens/QuizFlow';
import AIReport from '@/components/screens/AIReport';
import PaywallScreen from '@/components/screens/PaywallScreen';
import Dashboard from '@/components/screens/Dashboard';
import WorkoutScreen from '@/components/screens/WorkoutScreen';
import MealPlanScreen from '@/components/screens/MealPlanScreen';
import CheckInScreen from '@/components/screens/CheckInScreen';
import ProgressScreen from '@/components/screens/ProgressScreen';
import SubscriptionScreen from '@/components/screens/SubscriptionScreen';
import ReferralScreen from '@/components/screens/ReferralScreen';
import ProfileScreen from '@/components/screens/ProfileScreen';
import AdminPanel from '@/components/screens/AdminPanel';

const screensWithNav: ScreenName[] = ['dashboard', 'workout', 'meals', 'progress'];
const screensWithTopBar: ScreenName[] = ['dashboard', 'workout', 'meals', 'progress', 'checkin', 'subscription', 'referral', 'profile', 'admin'];

export default function Home() {
  const { currentScreen, navigate, previousScreen } = useStore();

  const showNav = screensWithNav.includes(currentScreen);
  const showTopBar = screensWithTopBar.includes(currentScreen);

  const renderScreen = () => {
    switch (currentScreen) {
      case 'landing':
        return <LandingPage />;
      case 'language':
        return <LanguageSelect />;
      case 'auth':
        return <AuthScreen />;
      case 'quiz':
        return <QuizFlow />;
      case 'report':
        return <AIReport />;
      case 'paywall':
        return <PaywallScreen />;
      case 'dashboard':
        return <Dashboard />;
      case 'workout':
        return <WorkoutScreen />;
      case 'meals':
        return <MealPlanScreen />;
      case 'checkin':
        return <CheckInScreen />;
      case 'progress':
        return <ProgressScreen />;
      case 'subscription':
        return <SubscriptionScreen />;
      case 'referral':
        return <ReferralScreen />;
      case 'profile':
        return <ProfileScreen />;
      case 'admin':
        return <AdminPanel />;
      default:
        return <LandingPage />;
    }
  };

  return (
    <div className="min-h-screen bg-black">
      {showTopBar && (
        <TopBar
          showBack={!screensWithNav.includes(currentScreen)}
          onBack={() => {
            if (previousScreen) {
              navigate(previousScreen as ScreenName);
            } else {
              navigate('dashboard');
            }
          }}
        />
      )}
      <main className={showNav ? 'pb-20' : ''}>
        {renderScreen()}
      </main>
      {showNav && <BottomNav />}
    </div>
  );
}
