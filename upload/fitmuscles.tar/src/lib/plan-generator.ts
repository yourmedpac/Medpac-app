import type { WorkoutPlan, MealPlan, WorkoutExercise, Meal } from './types';

export function generateWorkoutPlan(
  goal: string,
  location: string,
  fitnessLevel: string,
  daysPerWeek: number = 3
): WorkoutPlan {
  const gymExercises: Record<string, WorkoutExercise[][]> = {
    fat_loss: [
      [
        { id: 'e1', name: 'Bench Press', equipment: 'Barbell', sets: [{ weight: 40, reps: 12, completed: false }, { weight: 45, reps: 10, completed: false }, { weight: 45, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e2', name: 'Incline Dumbbell Press', equipment: 'Dumbbells', sets: [{ weight: 16, reps: 12, completed: false }, { weight: 18, reps: 10, completed: false }, { weight: 18, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e3', name: 'Tricep Pushdowns', equipment: 'Cable', sets: [{ weight: 20, reps: 15, completed: false }, { weight: 22, reps: 12, completed: false }, { weight: 22, reps: 12, completed: false }], completed: false, skipped: false },
        { id: 'e4', name: 'Overhead Tricep Extension', equipment: 'Dumbbell', sets: [{ weight: 14, reps: 12, completed: false }, { weight: 14, reps: 12, completed: false }], completed: false, skipped: false },
        { id: 'e5', name: 'Chest Flyes', equipment: 'Dumbbells', sets: [{ weight: 12, reps: 15, completed: false }, { weight: 14, reps: 12, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'e6', name: 'Barbell Row', equipment: 'Barbell', sets: [{ weight: 40, reps: 12, completed: false }, { weight: 45, reps: 10, completed: false }, { weight: 45, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e7', name: 'Lat Pulldown', equipment: 'Cable', sets: [{ weight: 35, reps: 12, completed: false }, { weight: 40, reps: 10, completed: false }, { weight: 40, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e8', name: 'Bicep Curls', equipment: 'Dumbbells', sets: [{ weight: 10, reps: 15, completed: false }, { weight: 12, reps: 12, completed: false }, { weight: 12, reps: 12, completed: false }], completed: false, skipped: false },
        { id: 'e9', name: 'Hammer Curls', equipment: 'Dumbbells', sets: [{ weight: 10, reps: 12, completed: false }, { weight: 12, reps: 12, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'e10', name: 'Squats', equipment: 'Barbell', sets: [{ weight: 50, reps: 12, completed: false }, { weight: 55, reps: 10, completed: false }, { weight: 60, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e11', name: 'Leg Press', equipment: 'Machine', sets: [{ weight: 80, reps: 12, completed: false }, { weight: 90, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e12', name: 'Calf Raises', equipment: 'Machine', sets: [{ weight: 40, reps: 20, completed: false }, { weight: 45, reps: 15, completed: false }], completed: false, skipped: false },
        { id: 'e13', name: 'Plank', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 60, completed: false }, { weight: 0, reps: 45, completed: false }], completed: false, skipped: false },
      ],
    ],
    muscle_gain: [
      [
        { id: 'e1', name: 'Bench Press', equipment: 'Barbell', sets: [{ weight: 50, reps: 8, completed: false }, { weight: 55, reps: 8, completed: false }, { weight: 60, reps: 6, completed: false }, { weight: 60, reps: 6, completed: false }], completed: false, skipped: false },
        { id: 'e2', name: 'Incline Dumbbell Press', equipment: 'Dumbbells', sets: [{ weight: 20, reps: 10, completed: false }, { weight: 22, reps: 8, completed: false }, { weight: 24, reps: 8, completed: false }], completed: false, skipped: false },
        { id: 'e3', name: 'Cable Crossover', equipment: 'Cable', sets: [{ weight: 15, reps: 12, completed: false }, { weight: 18, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e4', name: 'Tricep Dips', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'e6', name: 'Deadlift', equipment: 'Barbell', sets: [{ weight: 60, reps: 8, completed: false }, { weight: 70, reps: 6, completed: false }, { weight: 80, reps: 5, completed: false }], completed: false, skipped: false },
        { id: 'e7', name: 'Pull-ups', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 8, completed: false }, { weight: 0, reps: 6, completed: false }, { weight: 0, reps: 6, completed: false }], completed: false, skipped: false },
        { id: 'e8', name: 'Barbell Curl', equipment: 'Barbell', sets: [{ weight: 20, reps: 10, completed: false }, { weight: 22, reps: 8, completed: false }, { weight: 22, reps: 8, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'e10', name: 'Squats', equipment: 'Barbell', sets: [{ weight: 60, reps: 10, completed: false }, { weight: 70, reps: 8, completed: false }, { weight: 80, reps: 6, completed: false }], completed: false, skipped: false },
        { id: 'e11', name: 'Romanian Deadlift', equipment: 'Barbell', sets: [{ weight: 50, reps: 10, completed: false }, { weight: 55, reps: 8, completed: false }], completed: false, skipped: false },
        { id: 'e12', name: 'Leg Curls', equipment: 'Machine', sets: [{ weight: 30, reps: 12, completed: false }, { weight: 35, reps: 10, completed: false }], completed: false, skipped: false },
      ],
    ],
    skinny_fat: [
      [
        { id: 'e1', name: 'Push-ups', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 15, completed: false }, { weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e2', name: 'Dumbbell Press', equipment: 'Dumbbells', sets: [{ weight: 14, reps: 12, completed: false }, { weight: 16, reps: 10, completed: false }, { weight: 16, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e3', name: 'Tricep Pushdowns', equipment: 'Cable', sets: [{ weight: 15, reps: 15, completed: false }, { weight: 18, reps: 12, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'e6', name: 'Dumbbell Row', equipment: 'Dumbbell', sets: [{ weight: 16, reps: 12, completed: false }, { weight: 18, reps: 10, completed: false }, { weight: 18, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e7', name: 'Lat Pulldown', equipment: 'Cable', sets: [{ weight: 30, reps: 12, completed: false }, { weight: 35, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e8', name: 'Bicep Curls', equipment: 'Dumbbells', sets: [{ weight: 8, reps: 15, completed: false }, { weight: 10, reps: 12, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'e10', name: 'Goblet Squats', equipment: 'Dumbbell', sets: [{ weight: 16, reps: 12, completed: false }, { weight: 18, reps: 10, completed: false }, { weight: 20, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e11', name: 'Lunges', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 12, completed: false }], completed: false, skipped: false },
        { id: 'e12', name: 'Plank', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 45, completed: false }, { weight: 0, reps: 30, completed: false }], completed: false, skipped: false },
      ],
    ],
    overall_fitness: [
      [
        { id: 'e1', name: 'Bench Press', equipment: 'Barbell', sets: [{ weight: 40, reps: 10, completed: false }, { weight: 45, reps: 10, completed: false }, { weight: 45, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e2', name: 'Shoulder Press', equipment: 'Dumbbells', sets: [{ weight: 12, reps: 12, completed: false }, { weight: 14, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e3', name: 'Tricep Pushdowns', equipment: 'Cable', sets: [{ weight: 18, reps: 12, completed: false }, { weight: 20, reps: 12, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'e6', name: 'Barbell Row', equipment: 'Barbell', sets: [{ weight: 40, reps: 10, completed: false }, { weight: 45, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e7', name: 'Lat Pulldown', equipment: 'Cable', sets: [{ weight: 35, reps: 12, completed: false }, { weight: 40, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'e8', name: 'Bicep Curls', equipment: 'Dumbbells', sets: [{ weight: 10, reps: 12, completed: false }, { weight: 12, reps: 10, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'e10', name: 'Squats', equipment: 'Barbell', sets: [{ weight: 50, reps: 10, completed: false }, { weight: 55, reps: 10, completed: false }, { weight: 60, reps: 8, completed: false }], completed: false, skipped: false },
        { id: 'e11', name: 'Leg Press', equipment: 'Machine', sets: [{ weight: 80, reps: 12, completed: false }, { weight: 90, reps: 10, completed: false }], completed: false, skipped: false },
      ],
    ],
  };

  const homeExercises: Record<string, WorkoutExercise[][]> = {
    fat_loss: [
      [
        { id: 'h1', name: 'Push-ups', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 15, completed: false }, { weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'h2', name: 'Diamond Push-ups', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'h3', name: 'Chair Dips', equipment: 'Chair', sets: [{ weight: 0, reps: 15, completed: false }, { weight: 0, reps: 12, completed: false }], completed: false, skipped: false },
        { id: 'h4', name: 'Plank Shoulder Taps', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 20, completed: false }, { weight: 0, reps: 20, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'h5', name: 'Pull-ups / Doorway Rows', equipment: 'Doorframe', sets: [{ weight: 0, reps: 8, completed: false }, { weight: 0, reps: 8, completed: false }, { weight: 0, reps: 6, completed: false }], completed: false, skipped: false },
        { id: 'h6', name: 'Superman Hold', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 30, completed: false }, { weight: 0, reps: 30, completed: false }], completed: false, skipped: false },
        { id: 'h7', name: 'Bicep Curls', equipment: 'Water Bottles', sets: [{ weight: 2, reps: 15, completed: false }, { weight: 2, reps: 15, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'h8', name: 'Bodyweight Squats', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 20, completed: false }, { weight: 0, reps: 18, completed: false }, { weight: 0, reps: 15, completed: false }], completed: false, skipped: false },
        { id: 'h9', name: 'Lunges', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 12, completed: false }], completed: false, skipped: false },
        { id: 'h10', name: 'Jump Squats', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 15, completed: false }, { weight: 0, reps: 12, completed: false }], completed: false, skipped: false },
        { id: 'h11', name: 'Mountain Climbers', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 30, completed: false }, { weight: 0, reps: 30, completed: false }], completed: false, skipped: false },
      ],
    ],
    muscle_gain: [
      [
        { id: 'h1', name: 'Push-up Variations', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 15, completed: false }, { weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }, { weight: 0, reps: 8, completed: false }], completed: false, skipped: false },
        { id: 'h2', name: 'Pike Push-ups', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 10, completed: false }, { weight: 0, reps: 8, completed: false }, { weight: 0, reps: 8, completed: false }], completed: false, skipped: false },
        { id: 'h3', name: 'Chair Dips', equipment: 'Chair', sets: [{ weight: 0, reps: 15, completed: false }, { weight: 0, reps: 12, completed: false }, { weight: 0, reps: 12, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'h5', name: 'Inverted Rows', equipment: 'Table', sets: [{ weight: 0, reps: 10, completed: false }, { weight: 0, reps: 10, completed: false }, { weight: 0, reps: 8, completed: false }], completed: false, skipped: false },
        { id: 'h6', name: 'Towel Curls', equipment: 'Towel', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 12, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'h8', name: 'Bulgarian Split Squats', equipment: 'Chair', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'h9', name: 'Single Leg Squats', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 8, completed: false }, { weight: 0, reps: 6, completed: false }], completed: false, skipped: false },
      ],
    ],
    skinny_fat: [
      [
        { id: 'h1', name: 'Push-ups', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }, { weight: 0, reps: 8, completed: false }], completed: false, skipped: false },
        { id: 'h2', name: 'Plank', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 30, completed: false }, { weight: 0, reps: 30, completed: false }], completed: false, skipped: false },
        { id: 'h3', name: 'Chair Dips', equipment: 'Chair', sets: [{ weight: 0, reps: 10, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'h5', name: 'Doorway Rows', equipment: 'Doorframe', sets: [{ weight: 0, reps: 10, completed: false }, { weight: 0, reps: 8, completed: false }], completed: false, skipped: false },
        { id: 'h6', name: 'Superman Hold', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 20, completed: false }, { weight: 0, reps: 20, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'h8', name: 'Bodyweight Squats', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 15, completed: false }, { weight: 0, reps: 15, completed: false }, { weight: 0, reps: 12, completed: false }], completed: false, skipped: false },
        { id: 'h9', name: 'Lunges', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 10, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false },
      ],
    ],
    overall_fitness: [
      [
        { id: 'h1', name: 'Push-ups', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'h2', name: 'Chair Dips', equipment: 'Chair', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'h3', name: 'Plank', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 30, completed: false }, { weight: 0, reps: 30, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'h5', name: 'Inverted Rows', equipment: 'Table', sets: [{ weight: 0, reps: 10, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false },
        { id: 'h6', name: 'Towel Curls', equipment: 'Towel', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 12, completed: false }], completed: false, skipped: false },
      ],
      [
        { id: 'h8', name: 'Squats', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 15, completed: false }, { weight: 0, reps: 15, completed: false }, { weight: 0, reps: 12, completed: false }], completed: false, skipped: false },
        { id: 'h9', name: 'Lunges', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 10, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false },
      ],
    ],
  };

  const exerciseSet = location === 'home' ? homeExercises : gymExercises;
  const goalExercises = exerciseSet[goal] || exerciseSet.fat_loss;

  const dayTitles = ['Chest & Triceps', 'Back & Biceps', 'Legs & Core', 'Shoulders & Abs', 'Full Body', 'Upper Body', 'Lower Body'];

  const days = goalExercises.map((exercises, i) => ({
    id: `day_${i + 1}`,
    dayNumber: i + 1,
    title: dayTitles[i] || `Day ${i + 1}`,
    exercises,
    completed: false,
    weekNumber: Math.floor(i / 3) + 1,
  }));

  const planNameMap: Record<string, string> = {
    fat_loss: 'Fat Loss Shred',
    muscle_gain: 'Muscle Builder Pro',
    skinny_fat: 'Body Recomposition',
    overall_fitness: 'Total Fitness',
  };

  return {
    id: 'wp1',
    name: planNameMap[goal] || 'Custom Plan',
    description: `${fitnessLevel === 'beginner' ? 'Beginner-friendly' : fitnessLevel === 'novice' ? 'Novice' : 'Intermediate'} ${daysPerWeek}-day ${location} plan`,
    daysPerWeek,
    duration: '90 Days',
    days,
    currentDay: 5,
  };
}

export function generateMealPlan(
  goal: string,
  dietType: string,
  budget: string = 'medium',
  mealsPerDay: number = 3
): MealPlan {
  const vegMeals: Meal[] = [
    {
      id: 'm1', type: 'breakfast', name: 'Poha & Sprouts', time: '8:00 AM',
      items: [
        { name: 'Poha (1 cup)', quantity: '1 cup', calories: 250, protein: 6, carbs: 45, fat: 5 },
        { name: 'Sprouts Salad', quantity: '1 bowl', calories: 120, protein: 8, carbs: 15, fat: 2 },
        { name: 'Green Chutney', quantity: '2 tbsp', calories: 20, protein: 1, carbs: 3, fat: 1 },
      ],
      totalCalories: 390, totalProtein: 15, swapped: false,
    },
    {
      id: 'm2', type: 'lunch', name: 'Paneer Bhurji & Roti', time: '1:00 PM',
      items: [
        { name: 'Paneer Bhurji', quantity: '150g', calories: 280, protein: 22, carbs: 8, fat: 18 },
        { name: 'Roti', quantity: '2 pcs', calories: 200, protein: 6, carbs: 38, fat: 3 },
        { name: 'Curd', quantity: '1 bowl', calories: 60, protein: 4, carbs: 5, fat: 3 },
        { name: 'Salad', quantity: '1 bowl', calories: 40, protein: 2, carbs: 6, fat: 1 },
      ],
      totalCalories: 580, totalProtein: 34, swapped: false,
    },
    {
      id: 'm3', type: 'dinner', name: 'Dal Chawal & Sabzi', time: '8:00 PM',
      items: [
        { name: 'Dal Tadka', quantity: '1 bowl', calories: 180, protein: 12, carbs: 25, fat: 5 },
        { name: 'Rice', quantity: '1 cup', calories: 200, protein: 4, carbs: 42, fat: 1 },
        { name: 'Mixed Sabzi', quantity: '1 bowl', calories: 100, protein: 4, carbs: 12, fat: 4 },
        { name: 'Salad', quantity: '1 bowl', calories: 30, protein: 1, carbs: 5, fat: 1 },
      ],
      totalCalories: 510, totalProtein: 21, swapped: false,
    },
  ];

  const nonVegMeals: Meal[] = [
    {
      id: 'm4', type: 'breakfast', name: 'Egg Bhurji & Toast', time: '8:00 AM',
      items: [
        { name: 'Egg Bhurji (3 eggs)', quantity: '3 eggs', calories: 240, protein: 20, carbs: 2, fat: 16 },
        { name: 'Brown Bread Toast', quantity: '2 slices', calories: 140, protein: 5, carbs: 24, fat: 2 },
        { name: 'Green Chutney', quantity: '2 tbsp', calories: 20, protein: 1, carbs: 3, fat: 1 },
      ],
      totalCalories: 400, totalProtein: 26, swapped: false,
    },
    {
      id: 'm5', type: 'lunch', name: 'Chicken Curry & Rice', time: '1:00 PM',
      items: [
        { name: 'Chicken Curry', quantity: '200g', calories: 320, protein: 35, carbs: 8, fat: 16 },
        { name: 'Rice', quantity: '1.5 cup', calories: 300, protein: 6, carbs: 63, fat: 1 },
        { name: 'Salad', quantity: '1 bowl', calories: 40, protein: 2, carbs: 6, fat: 1 },
      ],
      totalCalories: 660, totalProtein: 43, swapped: false,
    },
    {
      id: 'm6', type: 'dinner', name: 'Tandoori Chicken & Roti', time: '8:00 PM',
      items: [
        { name: 'Tandoori Chicken', quantity: '200g', calories: 280, protein: 38, carbs: 4, fat: 12 },
        { name: 'Roti', quantity: '2 pcs', calories: 200, protein: 6, carbs: 38, fat: 3 },
        { name: 'Curd', quantity: '1 bowl', calories: 60, protein: 4, carbs: 5, fat: 3 },
        { name: 'Salad', quantity: '1 bowl', calories: 30, protein: 1, carbs: 5, fat: 1 },
      ],
      totalCalories: 570, totalProtein: 49, swapped: false,
    },
  ];

  const veganMeals: Meal[] = [
    {
      id: 'm7', type: 'breakfast', name: 'Oats & Banana Smoothie', time: '8:00 AM',
      items: [
        { name: 'Oats', quantity: '1/2 cup', calories: 150, protein: 5, carbs: 27, fat: 3 },
        { name: 'Banana', quantity: '1 pc', calories: 105, protein: 1, carbs: 27, fat: 0 },
        { name: 'Soy Milk', quantity: '1 glass', calories: 80, protein: 7, carbs: 6, fat: 4 },
      ],
      totalCalories: 335, totalProtein: 13, swapped: false,
    },
    {
      id: 'm8', type: 'lunch', name: 'Chana Dal & Rice', time: '1:00 PM',
      items: [
        { name: 'Chana Dal', quantity: '1 bowl', calories: 200, protein: 14, carbs: 30, fat: 4 },
        { name: 'Rice', quantity: '1.5 cup', calories: 300, protein: 6, carbs: 63, fat: 1 },
        { name: 'Salad', quantity: '1 bowl', calories: 40, protein: 2, carbs: 6, fat: 1 },
      ],
      totalCalories: 540, totalProtein: 22, swapped: false,
    },
    {
      id: 'm9', type: 'dinner', name: 'Soy Chunks Curry & Roti', time: '8:00 PM',
      items: [
        { name: 'Soy Chunks Curry', quantity: '1 bowl', calories: 250, protein: 25, carbs: 15, fat: 8 },
        { name: 'Roti', quantity: '2 pcs', calories: 200, protein: 6, carbs: 38, fat: 3 },
        { name: 'Salad', quantity: '1 bowl', calories: 30, protein: 1, carbs: 5, fat: 1 },
      ],
      totalCalories: 480, totalProtein: 32, swapped: false,
    },
  ];

  let meals: Meal[];
  let dailyCalories: number;
  let dailyProtein: number;
  let planName: string;

  if (dietType === 'non_veg' || dietType === 'eggetarian') {
    meals = nonVegMeals;
    dailyCalories = 2250;
    dailyProtein = 140;
    planName = 'High Protein Non-Veg Plan';
  } else if (dietType === 'vegan') {
    meals = veganMeals;
    dailyCalories = 1800;
    dailyProtein = 100;
    planName = 'Plant Power Vegan Plan';
  } else {
    meals = vegMeals;
    dailyCalories = 2000;
    dailyProtein = 110;
    planName = 'High Protein Indian Diet';
  }

  // Adjust based on goal
  if (goal === 'fat_loss') {
    dailyCalories = Math.round(dailyCalories * 0.85);
    planName = 'Fat Loss ' + planName;
  } else if (goal === 'muscle_gain') {
    dailyCalories = Math.round(dailyCalories * 1.15);
    dailyProtein = Math.round(dailyProtein * 1.2);
    planName = 'Muscle Builder ' + planName;
  }

  return {
    id: 'mp1',
    name: planName,
    dailyCalories,
    dailyProtein,
    dietType,
    meals,
  };
}
