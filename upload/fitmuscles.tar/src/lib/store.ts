import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { ScreenName, Language, User, WorkoutPlan, MealPlan, CheckIn, Subscription, ScoringResult, ProgressEntry, Referral, Notification } from './types';
import type { AIReport, AIDailyInsight } from './ai';

interface AppState {
  // Navigation
  currentScreen: ScreenName;
  navigate: (screen: ScreenName) => void;
  previousScreen: ScreenName | null;

  // Language
  language: Language;
  setLanguage: (lang: Language) => void;

  // Auth
  user: User | null;
  setUser: (user: User | null) => void;
  isAuthenticated: boolean;

  // Quiz
  quizAnswers: Record<string, string | string[] | number>;
  setQuizAnswer: (key: string, value: string | string[] | number) => void;
  quizStep: number;
  setQuizStep: (step: number) => void;
  resetQuiz: () => void;

  // Scoring
  scoringResult: ScoringResult | null;
  setScoringResult: (result: ScoringResult | null) => void;

  // Plan
  workoutPlan: WorkoutPlan | null;
  setWorkoutPlan: (plan: WorkoutPlan | null) => void;
  mealPlan: MealPlan | null;
  setMealPlan: (plan: MealPlan | null) => void;

  // AI Generated Data
  aiReport: AIReport | null;
  setAIReport: (report: AIReport | null) => void;
  dailyInsight: AIDailyInsight | null;
  setDailyInsight: (insight: AIDailyInsight | null) => void;

  // Dashboard
  streak: number;
  setStreak: (streak: number) => void;
  checkIns: CheckIn[];
  addCheckIn: (checkIn: CheckIn) => void;

  // Progress
  progressEntries: ProgressEntry[];
  addProgressEntry: (entry: ProgressEntry) => void;

  // Subscription
  subscription: Subscription | null;
  setSubscription: (sub: Subscription | null) => void;

  // Referral
  referral: Referral | null;
  setReferral: (ref: Referral | null) => void;

  // Notifications
  notifications: Notification[];
  setNotifications: (notifs: Notification[]) => void;

  // Loading states
  isLoading: boolean;
  setLoading: (loading: boolean) => void;
  isGeneratingPlan: boolean;
  setGeneratingPlan: (generating: boolean) => void;
  isGeneratingReport: boolean;
  setGeneratingReport: (generating: boolean) => void;
  isGeneratingInsight: boolean;
  setGeneratingInsight: (generating: boolean) => void;
  isSwappingMeal: boolean;
  setSwappingMeal: (swapping: boolean) => void;
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      // Navigation
      currentScreen: 'landing',
      previousScreen: null,
      navigate: (screen) => set((state) => ({ previousScreen: state.currentScreen, currentScreen: screen })),

      // Language
      language: 'hinglish',
      setLanguage: (lang) => set({ language: lang }),

      // Auth
      user: null,
      setUser: (user) => set({ user, isAuthenticated: !!user }),
      isAuthenticated: false,

      // Quiz
      quizAnswers: {},
      setQuizAnswer: (key, value) => set((state) => ({ quizAnswers: { ...state.quizAnswers, [key]: value } })),
      quizStep: 0,
      setQuizStep: (step) => set({ quizStep: step }),
      resetQuiz: () => set({ quizAnswers: {}, quizStep: 0 }),

      // Scoring
      scoringResult: null,
      setScoringResult: (result) => set({ scoringResult: result }),

      // Plan
      workoutPlan: null,
      setWorkoutPlan: (plan) => set({ workoutPlan: plan }),
      mealPlan: null,
      setMealPlan: (plan) => set({ mealPlan: plan }),

      // AI Generated Data
      aiReport: null,
      setAIReport: (report) => set({ aiReport: report }),
      dailyInsight: null,
      setDailyInsight: (insight) => set({ dailyInsight: insight }),

      // Dashboard
      streak: 0,
      setStreak: (streak) => set({ streak }),
      checkIns: [],
      addCheckIn: (checkIn) => set((state) => {
        const newCheckIns = [...state.checkIns, checkIn];
        // Auto-calculate streak from check-ins
        let streak = 0;
        const today = new Date();
        for (let i = 0; i < 365; i++) {
          const checkDate = new Date(today);
          checkDate.setDate(checkDate.getDate() - i);
          const dateStr = checkDate.toISOString().split('T')[0];
          const hasCheckIn = newCheckIns.some(c => c.date.split('T')[0] === dateStr);
          if (hasCheckIn) {
            streak++;
          } else if (i > 0) {
            break;
          }
        }
        return { checkIns: newCheckIns, streak };
      }),

      // Progress
      progressEntries: [],
      addProgressEntry: (entry) => set((state) => ({ progressEntries: [...state.progressEntries, entry] })),

      // Subscription
      subscription: null,
      setSubscription: (sub) => set({ subscription: sub }),

      // Referral
      referral: null,
      setReferral: (ref) => set({ referral: ref }),

      // Notifications
      notifications: [],
      setNotifications: (notifs) => set({ notifications: notifs }),

      // Loading states (NOT persisted - always start false)
      isLoading: false,
      setLoading: (loading) => set({ isLoading: loading }),
      isGeneratingPlan: false,
      setGeneratingPlan: (generating) => set({ isGeneratingPlan: generating }),
      isGeneratingReport: false,
      setGeneratingReport: (generating) => set({ isGeneratingReport: generating }),
      isGeneratingInsight: false,
      setGeneratingInsight: (generating) => set({ isGeneratingInsight: generating }),
      isSwappingMeal: false,
      setSwappingMeal: (swapping) => set({ isSwappingMeal: swapping }),
    }),
    {
      name: 'fitmuscles-storage',
      partialize: (state) => ({
        // Only persist data, not UI state
        currentScreen: state.currentScreen,
        previousScreen: state.previousScreen,
        language: state.language,
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        quizAnswers: state.quizAnswers,
        quizStep: state.quizStep,
        scoringResult: state.scoringResult,
        workoutPlan: state.workoutPlan,
        mealPlan: state.mealPlan,
        aiReport: state.aiReport,
        dailyInsight: state.dailyInsight,
        streak: state.streak,
        checkIns: state.checkIns,
        progressEntries: state.progressEntries,
        subscription: state.subscription,
        referral: state.referral,
        notifications: state.notifications,
      }),
      // Don't persist loading states
      version: 1,
    }
  )
);
