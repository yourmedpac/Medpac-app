// TypeScript types for FitMuscles

export type ScreenName =
  | 'landing'
  | 'language'
  | 'auth'
  | 'quiz'
  | 'report'
  | 'paywall'
  | 'dashboard'
  | 'workout'
  | 'meals'
  | 'checkin'
  | 'progress'
  | 'subscription'
  | 'referral'
  | 'profile'
  | 'admin';

export type Language = 'hinglish' | 'en' | 'hi' | 'ta' | 'te';

export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  language: Language;
  createdAt: string;
}

export interface QuizAnswer {
  questionId: string;
  value: string | string[] | number;
}

export interface ScoringResult {
  readinessScore: number;
  consistencyScore: number;
  bodyTransformationScore: number;
  nutritionComplianceScore: number;
  supportNeedScore: number;
  overallScore: number;
  bodyType: string;
  fitnessLevel: string;
  goalCategory: string;
  recommendation: string;
  bmi: number;
  bmiCategory: string;
  height: number;
  weight: number;
  targetWeight: number;
}

export interface WorkoutExercise {
  id: string;
  name: string;
  equipment: string;
  sets: { weight: number; reps: number; completed: boolean }[];
  completed: boolean;
  skipped: boolean;
  restSeconds?: number;
  tips?: string;
}

export interface WorkoutDay {
  id: string;
  dayNumber: number;
  title: string;
  exercises: WorkoutExercise[];
  completed: boolean;
  weekNumber: number;
}

export interface WorkoutPlan {
  id: string;
  name: string;
  description: string;
  daysPerWeek: number;
  duration: string;
  days: WorkoutDay[];
  currentDay: number;
}

export interface MealItem {
  name: string;
  quantity: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface Meal {
  id: string;
  type: 'breakfast' | 'lunch' | 'snack' | 'dinner';
  name: string;
  time: string;
  items: MealItem[];
  totalCalories: number;
  totalProtein: number;
  swapped: boolean;
}

export interface MealPlan {
  id: string;
  name: string;
  dailyCalories: number;
  dailyProtein: number;
  dietType: string;
  meals: Meal[];
}

export interface CheckIn {
  id: string;
  date: string;
  workoutDone: boolean;
  proteinIntake: number;
  waterIntake: number;
  mood: 'sore' | 'tired' | 'good' | 'energized';
  notes?: string;
}

export interface ProgressEntry {
  date: string;
  weight: number;
  chest?: number;
  waist?: number;
  arms?: number;
  thighs?: number;
  shoulders?: number;
}

export interface Subscription {
  id: string;
  plan: 'free' | 'monthly' | 'quarterly' | 'yearly';
  status: 'active' | 'cancelled' | 'expired';
  startDate: string;
  endDate: string;
  amount: number;
}

export interface Referral {
  id: string;
  code: string;
  invitedUsers: { name: string; joinedAt: string; status: string }[];
  rewards: { type: string; value: string; earnedAt: string }[];
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'reminder' | 'achievement' | 'tip' | 'promo';
  read: boolean;
  createdAt: string;
}

export interface QuizQuestion {
  id: string;
  section: string;
  title: string;
  subtitle?: string;
  type: 'single' | 'multi' | 'slider' | 'scale';
  options?: { label: string; value: string; icon?: string }[];
  sliderConfig?: { min: number; max: number; step: number; unit: string; defaultValue: number };
  scaleConfig?: { min: number; max: number; labels: [string, string] };
}
