import type { Language } from './types';

type TranslationKeys = {
  // Landing
  heroTitle: string;
  heroSubtitle: string;
  startTransformation: string;
  newBatch: string;
  activeMembers: string;
  certifiedTrainers: string;
  whyFitmuscles: string;
  desiDiet: string;
  desiDietDesc: string;
  customWorkout: string;
  customWorkoutDesc: string;
  support247: string;
  support247Desc: string;
  avgFatLoss: string;
  faqTitle: string;
  faq1: string;
  faq1Ans: string;
  faq2: string;
  faq2Ans: string;
  faq3: string;
  faq3Ans: string;
  faq4: string;
  faq4Ans: string;
  // Language
  selectLanguage: string;
  selectLanguageDesc: string;
  // Auth
  welcomeBack: string;
  createAccount: string;
  email: string;
  password: string;
  signUp: string;
  logIn: string;
  orContinueWith: string;
  sendOtp: string;
  // Quiz
  stepOf: string;
  next: string;
  back: string;
  // Report
  aiAnalysisComplete: string;
  transformationRoadmap: string;
  bodyScore: string;
  dayPrediction: string;
  dietCard: string;
  trainingCard: string;
  unlockFullPlan: string;
  // Paywall
  whatYouGet: string;
  monthly: string;
  quarterly: string;
  yearly: string;
  perMonth: string;
  billed: string;
  mostPopular: string;
  subscribe: string;
  continueFree: string;
  securePayment: string;
  cancelAnytime: string;
  // Dashboard
  todayFocus: string;
  keepGoing: string;
  dayStreak: string;
  dayOf90: string;
  startWorkout: string;
  logMeal: string;
  uploadPhoto: string;
  completeCheckin: string;
  weeklyGoal: string;
  workouts: string;
  // Workout
  workoutProgress: string;
  complete: string;
  start: string;
  skip: string;
  addExercise: string;
  sets: string;
  // Meals
  todayGoal: string;
  calories: string;
  protein: string;
  swapMeal: string;
  // Check-in
  timeToLockIn: string;
  crushedGoals: string;
  hellYes: string;
  restDay: string;
  proteinTargetHit: string;
  waterIntake: string;
  howYouFeel: string;
  logDay: string;
  // Progress
  progress: string;
  trackGains: string;
  weight: string;
  physiqueUpdate: string;
  before: string;
  after: string;
  measurements: string;
  // Profile
  language: string;
  editBodyData: string;
  changeGoal: string;
  manageNotifications: string;
  managePayment: string;
  logout: string;
  // Navigation
  navToday: string;
  navWorkout: string;
  navMeals: string;
  navReport: string;
  // General
  loading: string;
  save: string;
  cancel: string;
  done: string;
};

const translations: Record<Language, TranslationKeys> = {
  hinglish: {
    heroTitle: '90 Days me badlo apni life',
    heroSubtitle: 'India ka #1 AI Fitness Transformation Platform. Personalized workout, desi diet, aur 24/7 support — sab ek jagah.',
    startTransformation: 'Start My Transformation',
    newBatch: 'NEW BATCH STARTING SOON',
    activeMembers: '10k+ ACTIVE MEMBERS',
    certifiedTrainers: '50+ CERTIFIED TRAINERS',
    whyFitmuscles: 'Why FitMuscles?',
    desiDiet: 'Desi Diet Plans',
    desiDietDesc: 'Ghar ka khana, smart plan. Roti, dal, paneer — sab included.',
    customWorkout: 'Custom Workout',
    customWorkoutDesc: 'Gym ya ghar, beginner ya advanced — plan aapke liye.',
    support247: '24/7 Support',
    support247Desc: 'WhatsApp pe coach se baat karo, koi doubt nahi rehna chahiye.',
    avgFatLoss: 'Avg. 5kg Fat Loss in first 45 days',
    faqTitle: 'Frequently Asked Questions',
    faq1: 'Kya main gym jaa bhi sakta hu?',
    faq1Ans: 'Haan! Humare plans home aur gym dono ke liye hain. Aap apna location select karo, plan wahi ke hisaab se banta hai.',
    faq2: 'Kya diet Indian hai?',
    faq2Ans: '100%! Roti, dal, chawal, paneer, eggs, chicken — sab desi food. Koi imported supplements ki zaroorat nahi.',
    faq3: 'Kitna time lagega results aane me?',
    faq3Ans: 'Most members pehle 45 days me 3-5kg fat loss dekhte hain. 90 days me transformation kaafi noticeable hota hai.',
    faq4: 'Kya main cancel kar sakta hu?',
    faq4Ans: 'Haan, kabhi bhi cancel karo. No questions asked. Par trust karo, aap cancel nahi karoge 😄',
    selectLanguage: 'Bhasha Chuniye',
    selectLanguageDesc: 'Choose your preferred language',
    welcomeBack: 'Welcome Back!',
    createAccount: 'Create Account',
    email: 'Email',
    password: 'Password',
    signUp: 'Sign Up',
    logIn: 'Log In',
    orContinueWith: 'Or continue with',
    sendOtp: 'Send OTP',
    stepOf: 'of',
    next: 'Next',
    back: 'Back',
    aiAnalysisComplete: 'AI ANALYSIS COMPLETE',
    transformationRoadmap: 'Ye raha aapka Transformation Roadmap',
    bodyScore: 'Body Score',
    dayPrediction: '90-Day Prediction',
    dietCard: 'High Protein Indian Diet',
    trainingCard: '3 Days Strength Training',
    unlockFullPlan: 'Unlock Full Plan & Start Training',
    whatYouGet: 'What You Get',
    monthly: 'Monthly',
    quarterly: 'Quarterly',
    yearly: 'Yearly',
    perMonth: '/mo',
    billed: 'billed',
    mostPopular: 'Most Popular',
    subscribe: 'Subscribe Now',
    continueFree: 'Continue with free plan',
    securePayment: 'Secure Payment',
    cancelAnytime: 'Cancel Anytime',
    todayFocus: "TODAY'S FOCUS",
    keepGoing: 'Shabaash! Keep going!',
    dayStreak: 'Day Streak',
    dayOf90: 'of 90',
    startWorkout: 'Start Workout',
    logMeal: 'Log Meal',
    uploadPhoto: 'Upload Photo',
    completeCheckin: 'Complete Check-in',
    weeklyGoal: 'Weekly Goal',
    workouts: 'Workouts',
    workoutProgress: 'Workout Progress',
    complete: 'Complete',
    start: 'Start',
    skip: 'Skip',
    addExercise: 'Add Exercise',
    sets: 'sets',
    todayGoal: 'Aaj Ka Goal!',
    calories: 'Calories',
    protein: 'Protein',
    swapMeal: 'Swap Meal',
    timeToLockIn: 'Time to Lock In.',
    crushedGoals: "Crushed today's goals? Let's log it.",
    hellYes: 'Hell Yes!',
    restDay: 'Rest Day',
    proteinTargetHit: 'Protein target hit?',
    waterIntake: 'Water Intake',
    howYouFeel: 'How do you feel?',
    logDay: 'LOG DAY',
    progress: 'Progress',
    trackGains: 'Track your gains and stay motivated',
    weight: 'Weight',
    physiqueUpdate: 'Physique Update',
    before: 'Before',
    after: 'After',
    measurements: 'Measurements',
    language: 'Language',
    editBodyData: 'Edit Body Data',
    changeGoal: 'Change Goal',
    manageNotifications: 'Manage Notifications',
    managePayment: 'Manage Payment',
    logout: 'Logout',
    navToday: 'Today',
    navWorkout: 'Workout',
    navMeals: 'Meals',
    navReport: 'Report',
    loading: 'Loading...',
    save: 'Save',
    cancel: 'Cancel',
    done: 'Done',
  },
  en: {
    heroTitle: 'Transform your life in 90 Days',
    heroSubtitle: "India's #1 AI Fitness Transformation Platform. Personalized workout, desi diet, and 24/7 support — all in one place.",
    startTransformation: 'Start My Transformation',
    newBatch: 'NEW BATCH STARTING SOON',
    activeMembers: '10k+ ACTIVE MEMBERS',
    certifiedTrainers: '50+ CERTIFIED TRAINERS',
    whyFitmuscles: 'Why FitMuscles?',
    desiDiet: 'Desi Diet Plans',
    desiDietDesc: 'Home food, smart plan. Roti, dal, paneer — everything included.',
    customWorkout: 'Custom Workout',
    customWorkoutDesc: 'Gym or home, beginner or advanced — plan made for you.',
    support247: '24/7 Support',
    support247Desc: 'Chat with your coach on WhatsApp. No doubts left unanswered.',
    avgFatLoss: 'Avg. 5kg Fat Loss in first 45 days',
    faqTitle: 'Frequently Asked Questions',
    faq1: 'Can I go to the gym?',
    faq1Ans: 'Yes! Our plans are for both home and gym. Select your location and the plan adapts accordingly.',
    faq2: 'Is the diet Indian?',
    faq2Ans: '100%! Roti, dal, rice, paneer, eggs, chicken — all desi food. No imported supplements needed.',
    faq3: 'How long until I see results?',
    faq3Ans: 'Most members see 3-5kg fat loss in the first 45 days. By 90 days, the transformation is very noticeable.',
    faq4: 'Can I cancel anytime?',
    faq4Ans: 'Yes, cancel anytime. No questions asked. But trust us, you won\'t want to 😄',
    selectLanguage: 'Select Language',
    selectLanguageDesc: 'Choose your preferred language',
    welcomeBack: 'Welcome Back!',
    createAccount: 'Create Account',
    email: 'Email',
    password: 'Password',
    signUp: 'Sign Up',
    logIn: 'Log In',
    orContinueWith: 'Or continue with',
    sendOtp: 'Send OTP',
    stepOf: 'of',
    next: 'Next',
    back: 'Back',
    aiAnalysisComplete: 'AI ANALYSIS COMPLETE',
    transformationRoadmap: 'Here is your Transformation Roadmap',
    bodyScore: 'Body Score',
    dayPrediction: '90-Day Prediction',
    dietCard: 'High Protein Indian Diet',
    trainingCard: '3 Days Strength Training',
    unlockFullPlan: 'Unlock Full Plan & Start Training',
    whatYouGet: 'What You Get',
    monthly: 'Monthly',
    quarterly: 'Quarterly',
    yearly: 'Yearly',
    perMonth: '/mo',
    billed: 'billed',
    mostPopular: 'Most Popular',
    subscribe: 'Subscribe Now',
    continueFree: 'Continue with free plan',
    securePayment: 'Secure Payment',
    cancelAnytime: 'Cancel Anytime',
    todayFocus: "TODAY'S FOCUS",
    keepGoing: 'Shabaash! Keep going!',
    dayStreak: 'Day Streak',
    dayOf90: 'of 90',
    startWorkout: 'Start Workout',
    logMeal: 'Log Meal',
    uploadPhoto: 'Upload Photo',
    completeCheckin: 'Complete Check-in',
    weeklyGoal: 'Weekly Goal',
    workouts: 'Workouts',
    workoutProgress: 'Workout Progress',
    complete: 'Complete',
    start: 'Start',
    skip: 'Skip',
    addExercise: 'Add Exercise',
    sets: 'sets',
    todayGoal: "Today's Goal!",
    calories: 'Calories',
    protein: 'Protein',
    swapMeal: 'Swap Meal',
    timeToLockIn: 'Time to Lock In.',
    crushedGoals: "Crushed today's goals? Let's log it.",
    hellYes: 'Hell Yes!',
    restDay: 'Rest Day',
    proteinTargetHit: 'Protein target hit?',
    waterIntake: 'Water Intake',
    howYouFeel: 'How do you feel?',
    logDay: 'LOG DAY',
    progress: 'Progress',
    trackGains: 'Track your gains and stay motivated',
    weight: 'Weight',
    physiqueUpdate: 'Physique Update',
    before: 'Before',
    after: 'After',
    measurements: 'Measurements',
    language: 'Language',
    editBodyData: 'Edit Body Data',
    changeGoal: 'Change Goal',
    manageNotifications: 'Manage Notifications',
    managePayment: 'Manage Payment',
    logout: 'Logout',
    navToday: 'Today',
    navWorkout: 'Workout',
    navMeals: 'Meals',
    navReport: 'Report',
    loading: 'Loading...',
    save: 'Save',
    cancel: 'Cancel',
    done: 'Done',
  },
  hi: {
    heroTitle: '90 दिनों में बदलें अपनी ज़िंदगी',
    heroSubtitle: 'भारत का #1 AI फिटनेस ट्रांसफॉर्मेशन प्लेटफॉर्म। पर्सनलाइज्ड वर्कआउट, देसी डाइट, और 24/7 सपोर्ट — सब एक जगह।',
    startTransformation: 'अपनी ट्रांसफॉर्मेशन शुरू करें',
    newBatch: 'नया बैच जल्द शुरू हो रहा है',
    activeMembers: '10k+ एक्टिव मेंबर्स',
    certifiedTrainers: '50+ सर्टिफाइड ट्रेनर्स',
    whyFitmuscles: 'FitMuscles क्यों?',
    desiDiet: 'देसी डाइट प्लान',
    desiDietDesc: 'घर का खाना, स्मार्ट प्लान। रोटी, दाल, पनीर — सब शामिल।',
    customWorkout: 'कस्टम वर्कआउट',
    customWorkoutDesc: 'जिम या घर, बिगिनर या एडवांस्ड — आपके लिए प्लान।',
    support247: '24/7 सपोर्ट',
    support247Desc: 'WhatsApp पर कोच से बात करें, कोई डाउट नहीं रहना चाहिए।',
    avgFatLoss: 'पहले 45 दिनों में औसत 5kg फैट लॉस',
    faqTitle: 'अक्सर पूछे जाने वाले सवाल',
    faq1: 'क्या मैं जिम जा सकता हूं?',
    faq1Ans: 'हाँ! हमारे प्लान होम और जिम दोनों के लिए हैं। अपना लोकेशन सेलेक्ट करें।',
    faq2: 'क्या डाइट भारतीय है?',
    faq2Ans: '100%! रोटी, दाल, चावल, पनीर, अंडे, चिकन — सब देसी फूड।',
    faq3: 'रिजल्ट आने में कितना समय लगेगा?',
    faq3Ans: 'ज्यादातर मेंबर्स पहले 45 दिनों में 3-5kg फैट लॉस देखते हैं।',
    faq4: 'क्या मैं कैंसल कर सकता हूं?',
    faq4Ans: 'हाँ, कभी भी कैंसल करें। कोई सवाल नहीं।',
    selectLanguage: 'भाषा चुनें',
    selectLanguageDesc: 'अपनी पसंदीदा भाषा चुनें',
    welcomeBack: 'वेलकम बैक!',
    createAccount: 'अकाउंट बनाएं',
    email: 'ईमेल',
    password: 'पासवर्ड',
    signUp: 'साइन अप',
    logIn: 'लॉग इन',
    orContinueWith: 'या इससे जारी रखें',
    sendOtp: 'OTP भेजें',
    stepOf: 'में से',
    next: 'आगे',
    back: 'पीछे',
    aiAnalysisComplete: 'AI एनालिसिस पूरा',
    transformationRoadmap: 'ये रहा आपका ट्रांसफॉर्मेशन रोडमैप',
    bodyScore: 'बॉडी स्कोर',
    dayPrediction: '90-दिन प्रेडिक्शन',
    dietCard: 'हाई प्रोटीन इंडियन डाइट',
    trainingCard: '3 दिन स्ट्रेंथ ट्रेनिंग',
    unlockFullPlan: 'फुल प्लान अनलॉक करें',
    whatYouGet: 'आपको क्या मिलेगा',
    monthly: 'मंथली',
    quarterly: 'क्वार्टरली',
    yearly: 'यीयरली',
    perMonth: '/महीना',
    billed: 'बिल्ड',
    mostPopular: 'सबसे लोकप्रिय',
    subscribe: 'सब्सक्राइब करें',
    continueFree: 'फ्री प्लान से जारी रखें',
    securePayment: 'सिक्योर पेमेंट',
    cancelAnytime: 'कभी भी कैंसल करें',
    todayFocus: 'आज का फोकस',
    keepGoing: 'शाबाश! जारी रखें!',
    dayStreak: 'दिन स्ट्रीक',
    dayOf90: '90 में से',
    startWorkout: 'वर्कआउट शुरू करें',
    logMeal: 'मील लॉग करें',
    uploadPhoto: 'फोटो अपलोड करें',
    completeCheckin: 'चेक-इन पूरा करें',
    weeklyGoal: 'साप्ताहिक लक्ष्य',
    workouts: 'वर्कआउट',
    workoutProgress: 'वर्कआउट प्रोग्रेस',
    complete: 'पूरा करें',
    start: 'शुरू करें',
    skip: 'स्किप करें',
    addExercise: 'एक्सरसाइज जोड़ें',
    sets: 'सेट्स',
    todayGoal: 'आज का लक्ष्य!',
    calories: 'कैलोरी',
    protein: 'प्रोटीन',
    swapMeal: 'मील बदलें',
    timeToLockIn: 'लॉक इन करने का समय।',
    crushedGoals: 'आज के लक्ष्य पूरे किए? लॉग करें।',
    hellYes: 'हेल यस!',
    restDay: 'रेस्ट डे',
    proteinTargetHit: 'प्रोटीन टारगेट हिट?',
    waterIntake: 'पानी पीना',
    howYouFeel: 'आप कैसा महसूस कर रहे हैं?',
    logDay: 'दिन लॉग करें',
    progress: 'प्रोग्रेस',
    trackGains: 'अपनी प्रगति ट्रैक करें',
    weight: 'वजन',
    physiqueUpdate: 'फिज़िक अपडेट',
    before: 'पहले',
    after: 'बाद',
    measurements: 'माप',
    language: 'भाषा',
    editBodyData: 'बॉडी डेटा एडिट करें',
    changeGoal: 'लक्ष्य बदलें',
    manageNotifications: 'नोटिफिकेशन मैनेज करें',
    managePayment: 'पेमेंट मैनेज करें',
    logout: 'लॉगआउट',
    navToday: 'आज',
    navWorkout: 'वर्कआउट',
    navMeals: 'मील्स',
    navReport: 'रिपोर्ट',
    loading: 'लोड हो रहा है...',
    save: 'सेव',
    cancel: 'कैंसल',
    done: 'हो गया',
  },
  ta: {
    heroTitle: '90 நாட்களில் உங்கள் வாழ்க்கையை மாற்றுங்கள்',
    heroSubtitle: 'இந்தியாவின் #1 AI ஃபிட்னஸ் மாற்ற தளம். தனிப்பயன் உடற்பயிற்சி, தேசி உணவு, மற்றும் 24/7 ஆதரவு.',
    startTransformation: 'என் மாற்றத்தை தொடங்கு',
    newBatch: 'புதிய பேட்ச் விரைவில் தொடங்குகிறது',
    activeMembers: '10k+ செயலில் உறுப்பினர்கள்',
    certifiedTrainers: '50+ சான்றளிக்கப்பட்ட பயிற்சியாளர்கள்',
    whyFitmuscles: 'FitMuscles ஏன்?',
    desiDiet: 'தேசி உணவு திட்டங்கள்',
    desiDietDesc: 'வீட்டு உணவு, ஸ்மார்ட் திட்டம். ரொட்டி, தால், பனீர் — அனைத்தும் உள்ளடக்கியது.',
    customWorkout: 'தனிப்பயன் உடற்பயிற்சி',
    customWorkoutDesc: 'ஜிம் அல்லது வீடு, ஆரம்பநிலை அல்லது மேம்பட்ட — உங்களுக்கான திட்டம்.',
    support247: '24/7 ஆதரவு',
    support247Desc: 'WhatsApp-ல் உங்கள் கோச்சுடன் பேசுங்கள்.',
    avgFatLoss: 'முதல் 45 நாட்களில் சராசரி 5kg கொழுப்பு இழப்பு',
    faqTitle: 'அடிக்கடி கேட்கப்படும் கேள்விகள்',
    faq1: 'நான் ஜிம் செல்ல முடியுமா?',
    faq1Ans: 'ஆம்! எங்கள் திட்டங்கள் வீடு மற்றும் ஜிம் இரண்டிற்கும்.',
    faq2: 'உணவு இந்தியதா?',
    faq2Ans: '100%! ரொட்டி, தால், அரிசி, பனீர், முட்டை, கோழி — அனைத்தும் தேசி உணவு.',
    faq3: 'முடிவுகள் வர எவ்வளவு நேரம் ஆகும்?',
    faq3Ans: 'பெரும்பாலான உறுப்பினர்கள் முதல் 45 நாட்களில் 3-5kg கொழுப்பு இழப்பைக் காண்கிறார்கள்.',
    faq4: 'நான் ரத்து செய்ய முடியுமா?',
    faq4Ans: 'ஆம், எப்போது வேண்டுமானாலும் ரத்து செய்யலாம்.',
    selectLanguage: 'மொழியை தேர்வு செய்யவும்',
    selectLanguageDesc: 'உங்கள் விருப்பமான மொழியை தேர்வு செய்யவும்',
    welcomeBack: 'மீண்டும் வரவேற்கிறோம்!',
    createAccount: 'கணக்கை உருவாக்கு',
    email: 'மின்னஞ்சல்',
    password: 'கடவுச்சொல்',
    signUp: 'பதிவு செய்',
    logIn: 'உள்நுழை',
    orContinueWith: 'அல்லது இதனுடன் தொடரவும்',
    sendOtp: 'OTP அனுப்பு',
    stepOf: 'இல்',
    next: 'அடுத்து',
    back: 'பின்னுக்கு',
    aiAnalysisComplete: 'AI பகுப்பாய்வு முடிந்தது',
    transformationRoadmap: 'உங்கள் மாற்ற வரைபடம் இதோ',
    bodyScore: 'உடல் மதிப்பெண்',
    dayPrediction: '90-நாள் கணிப்பு',
    dietCard: 'அதிக புரத இந்திய உணவு',
    trainingCard: '3 நாட்கள் வலிமை பயிற்சி',
    unlockFullPlan: 'முழு திட்டத்தை திறக்கவும்',
    whatYouGet: 'நீங்கள் என்ன பெறுவீர்கள்',
    monthly: 'மாதாந்திர',
    quarterly: 'காலாண்டு',
    yearly: 'ஆண்டு',
    perMonth: '/மாதம்',
    billed: 'பில் செய்யப்பட்டது',
    mostPopular: 'மிகவும் பிரபலமான',
    subscribe: 'குழுசேர்',
    continueFree: 'இலவச திட்டத்துடன் தொடரவும்',
    securePayment: 'பாதுகாப்பான கட்டணம்',
    cancelAnytime: 'எப்போது வேண்டுமானாலும் ரத்து செய்யவும்',
    todayFocus: 'இன்றைய கவனம்',
    keepGoing: 'சபாஷ்! தொடருங்கள்!',
    dayStreak: 'நாள் ஸ்ட்ரீக்',
    dayOf90: '90 இல்',
    startWorkout: 'உடற்பயிற்சி தொடங்கு',
    logMeal: 'உணவு பதிவு செய்',
    uploadPhoto: 'புகைப்படம் பதிவேற்று',
    completeCheckin: 'செக்-இன் முடிக்கவும்',
    weeklyGoal: 'வார இலக்கு',
    workouts: 'உடற்பயிற்சி',
    workoutProgress: 'உடற்பயிற்சி முன்னேற்றம்',
    complete: 'முடிக்கவும்',
    start: 'தொடங்கு',
    skip: 'தவிர்',
    addExercise: 'உடற்பயிற்சி சேர்',
    sets: 'செட்கள்',
    todayGoal: 'இன்றைய இலக்கு!',
    calories: 'கலோரி',
    protein: 'புரதம்',
    swapMeal: 'உணவை மாற்று',
    timeToLockIn: 'லாக் இன் செய்ய நேரம்.',
    crushedGoals: 'இன்றைய இலக்குகளை முடித்தீர்களா? பதிவு செய்யுங்கள்.',
    hellYes: 'ஆம்!',
    restDay: 'ஓய்வு நாள்',
    proteinTargetHit: 'புரத இலக்கு அடைந்ததா?',
    waterIntake: 'தண்ணீர் உட்கொள்ளல்',
    howYouFeel: 'நீங்கள் எப்படி உணர்கிறீர்கள்?',
    logDay: 'நாள் பதிவு செய்',
    progress: 'முன்னேற்றம்',
    trackGains: 'உங்கள் முன்னேற்றத்தை கண்காணியுங்கள்',
    weight: 'எடை',
    physiqueUpdate: 'உடல் புதுப்பிப்பு',
    before: 'முன்',
    after: 'பின்',
    measurements: 'அளவீடுகள்',
    language: 'மொழி',
    editBodyData: 'உடல் தரவை திருத்து',
    changeGoal: 'இலக்கை மாற்று',
    manageNotifications: 'அறிவிப்புகளை நிர்வகி',
    managePayment: 'கட்டணத்தை நிர்வகி',
    logout: 'வெளியேறு',
    navToday: 'இன்று',
    navWorkout: 'உடற்பயிற்சி',
    navMeals: 'உணவு',
    navReport: 'அறிக்கை',
    loading: 'ஏற்றுகிறது...',
    save: 'சேமி',
    cancel: 'ரத்து செய்',
    done: 'முடிந்தது',
  },
  te: {
    heroTitle: '90 రోజుల్లో మీ జీవితాన్ని మార్చుకోండి',
    heroSubtitle: 'భారతదేశం #1 AI ఫిట్‌నెస్ ట్రాన్స్‌ఫార్మేషన్ ప్లాట్‌ఫాం. వ్యక్తిగతీకరించిన వర్కౌట్, దేశీ ఆహారం, మరియు 24/7 మద్దతు.',
    startTransformation: 'నా ట్రాన్స్‌ఫార్మేషన్ ప్రారంభించు',
    newBatch: 'కొత్త బ్యాచ్ త్వరలో ప్రారంభమవుతుంది',
    activeMembers: '10k+ యాక్టివ్ మెంబర్లు',
    certifiedTrainers: '50+ సర్టిఫైడ్ ట్రైనర్లు',
    whyFitmuscles: 'FitMuscles ఎందుకు?',
    desiDiet: 'దేశీ ఆహార ప్రణాళికలు',
    desiDietDesc: 'ఇంటి ఆహారం, స్మార్ట్ ప్లాన్. రొట్టె, దాల్, పన్నీర్ — అన్నీ ఉన్నాయి.',
    customWorkout: 'కస్టమ్ వర్కౌట్',
    customWorkoutDesc: 'జిమ్ లేదా ఇల్లు, బిగినర్ లేదా అడ్వాన్స్డ్ — మీ కోసం ప్లాన్.',
    support247: '24/7 మద్దతు',
    support247Desc: 'WhatsApp లో మీ కోచ్ తో మాట్లాడండి.',
    avgFatLoss: 'మొదటి 45 రోజుల్లో సగటున 5kg కొవ్వు నష్టం',
    faqTitle: 'తరచుగా అడిగే ప్రశ్నలు',
    faq1: 'నేను జిమ్‌కి వెళ్ళవచ్చా?',
    faq1Ans: 'అవును! మా ప్లాన్లు ఇంటి మరియు జిమ్ రెండింటికీ.',
    faq2: 'ఆహారం భారతీయమా?',
    faq2Ans: '100%! రొట్టె, దాల్, బియ్యం, పన్నీర్, గుడ్లు, చికెన్ — అన్నీ దేశీ ఆహారం.',
    faq3: 'ఫలితాలు రావడానికి ఎంత సమయం పడుతుంది?',
    faq3Ans: 'చాలా మంది మొదటి 45 రోజుల్లో 3-5kg కొవ్వు నష్టం చూస్తారు.',
    faq4: 'నేను రద్దు చేయవచ్చా?',
    faq4Ans: 'అవును, ఎప్పుడైనా రద్దు చేయవచ్చు.',
    selectLanguage: 'భాషను ఎంచుకోండి',
    selectLanguageDesc: 'మీ ఇష్టమైన భాషను ఎంచుకోండి',
    welcomeBack: 'తిరిగి స్వాగతం!',
    createAccount: 'ఖాతా సృష్టించు',
    email: 'ఇమెయిల్',
    password: 'పాస్‌వర్డ్',
    signUp: 'సైన్ అప్',
    logIn: 'లాగిన్',
    orContinueWith: 'లేదా దీనితో కొనసాగించు',
    sendOtp: 'OTP పంపు',
    stepOf: 'లో',
    next: 'తదుపరి',
    back: 'వెనుకకు',
    aiAnalysisComplete: 'AI విశ్లేషణ పూర్తి',
    transformationRoadmap: 'మీ ట్రాన్స్‌ఫార్మేషన్ రోడ్‌మ్యాప్ ఇదిగో',
    bodyScore: 'బాడీ స్కోర్',
    dayPrediction: '90-రోజు అంచనా',
    dietCard: 'అధిక ప్రోటీన్ భారతీయ ఆహారం',
    trainingCard: '3 రోజుల బల శిక్షణ',
    unlockFullPlan: 'పూర్తి ప్లాన్ అన్‌లాక్ చేయండి',
    whatYouGet: 'మీరు ఏమి పొందుతారు',
    monthly: 'నెలవారీ',
    quarterly: 'త్రైమాసిక',
    yearly: 'వార్షిక',
    perMonth: '/నెల',
    billed: 'బిల్డ్',
    mostPopular: 'అత్యంత ప్రజాదరణ',
    subscribe: 'సబ్‌స్క్రైబ్',
    continueFree: 'ఉచిత ప్లాన్‌తో కొనసాగించు',
    securePayment: 'సురక్షిత చెల్లింపు',
    cancelAnytime: 'ఎప్పుడైనా రద్దు చేయండి',
    todayFocus: 'ఈరోజు దృష్టి',
    keepGoing: 'శభాష్! కొనసాగించండి!',
    dayStreak: 'రోజు స్ట్రీక్',
    dayOf90: '90 లో',
    startWorkout: 'వర్కౌట్ ప్రారంభించు',
    logMeal: 'భోజనం లాగ్ చేయండి',
    uploadPhoto: 'ఫోటో అప్‌లోడ్ చేయండి',
    completeCheckin: 'చెక్-ఇన్ పూర్తి చేయండి',
    weeklyGoal: 'వార లక్ష్యం',
    workouts: 'వర్కౌట్లు',
    workoutProgress: 'వర్కౌట్ ప్రోగ్రెస్',
    complete: 'పూర్తి చేయండి',
    start: 'ప్రారంభించు',
    skip: 'దాటవేయి',
    addExercise: 'వ్యాయామం జోడించు',
    sets: 'సెట్లు',
    todayGoal: 'ఈరోజు లక్ష్యం!',
    calories: 'కేలరీలు',
    protein: 'ప్రోటీన్',
    swapMeal: 'భోజనం మార్చు',
    timeToLockIn: 'లాక్ ఇన్ చేయడానికి సమయం.',
    crushedGoals: 'ఈరోజు లక్ష్యాలు చేరుకున్నారా? లాగ్ చేయండి.',
    hellYes: 'అవును!',
    restDay: 'విశ్రాంతి రోజు',
    proteinTargetHit: 'ప్రోటీన్ లక్ష్యం చేరుకున్నారా?',
    waterIntake: 'నీరు తాగడం',
    howYouFeel: 'మీరు ఎలా అనుభవిస్తున్నారు?',
    logDay: 'రోజు లాగ్ చేయండి',
    progress: 'ప్రోగ్రెస్',
    trackGains: 'మీ పురోగతిని ట్రాక్ చేయండి',
    weight: 'బరువు',
    physiqueUpdate: 'ఫిజిక్ అప్‌డేట్',
    before: 'ముందు',
    after: 'తర్వాత',
    measurements: 'కొలమానాలు',
    language: 'భాష',
    editBodyData: 'బాడీ డేటా ఎడిట్ చేయండి',
    changeGoal: 'లక్ష్యం మార్చు',
    manageNotifications: 'నోటిఫికేషన్లు నిర్వహించు',
    managePayment: 'చెల్లింపు నిర్వహించు',
    logout: 'లాగ్అవుట్',
    navToday: 'ఈరోజు',
    navWorkout: 'వర్కౌట్',
    navMeals: 'భోజనం',
    navReport: 'నివేదిక',
    loading: 'లోడ్ అవుతోంది...',
    save: 'సేవ్',
    cancel: 'రద్దు',
    done: 'పూర్తి',
  },
};

export type TranslationKey = keyof TranslationKeys;

export function t(key: TranslationKey, lang: Language = 'hinglish'): string {
  return translations[lang]?.[key] ?? translations.hinglish[key] ?? key;
}

export function getTranslations(lang: Language = 'hinglish'): TranslationKeys {
  return translations[lang] ?? translations.hinglish;
}

export default translations;
