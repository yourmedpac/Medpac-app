import ZAI from 'z-ai-web-dev-sdk';

// Singleton AI client
let aiClient: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getAIClient() {
  if (!aiClient) {
    aiClient = await ZAI.create();
  }
  return aiClient;
}

// ============================================================
// TYPES
// ============================================================

export interface AIWorkoutPlan {
  name: string;
  description: string;
  daysPerWeek: number;
  duration: string;
  days: {
    dayNumber: number;
    title: string;
    exercises: {
      id: string;
      name: string;
      equipment: string;
      sets: { weight: number; reps: number; completed: boolean }[];
      completed: boolean;
      skipped: boolean;
      restSeconds?: number;
      tips?: string;
    }[];
    completed: boolean;
    weekNumber: number;
  }[];
}

export interface AIMealPlan {
  name: string;
  dailyCalories: number;
  dailyProtein: number;
  dailyCarbs: number;
  dailyFat: number;
  meals: {
    id: string;
    type: 'breakfast' | 'lunch' | 'snack' | 'dinner';
    name: string;
    time: string;
    items: {
      name: string;
      quantity: string;
      calories: number;
      protein: number;
      carbs: number;
      fat: number;
    }[];
    totalCalories: number;
    totalProtein: number;
    swapped: boolean;
  }[];
}

export interface AIReport {
  summary: string;
  bodyAnalysis: string;
  bmiAnalysis: string;
  strengths: string[];
  weaknesses: string[];
  month1Prediction: { weightChange: string; muscleChange: string; strengthGain: string; confidence: string };
  month2Prediction: { weightChange: string; muscleChange: string; strengthGain: string; confidence: string };
  month3Prediction: { weightChange: string; muscleChange: string; strengthGain: string; confidence: string };
  dietAdvice: string;
  workoutAdvice: string;
  lifestyleAdvice: string;
  motivationalMessage: string;
  dietRecommendation: { type: string; calories: number; protein: number; reason: string };
  workoutRecommendation: { location: string; daysPerWeek: number; sessionDuration: string; focus: string; splitType: string };
}

export interface AIDailyInsight {
  greeting: string;
  focus: string;
  motivation: string;
  workoutTip: string;
  nutritionTip: string;
  mindsetTip: string;
}

export interface AIMealSwap {
  name: string;
  items: {
    name: string;
    quantity: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  }[];
  totalCalories: number;
  totalProtein: number;
  reason: string;
}

// ============================================================
// HELPER: Safe JSON parse from AI response
// ============================================================

function safeParseAIResponse<T>(text: string, fallback: T): T {
  try {
    // Try to extract JSON from the response - handle markdown code blocks
    let jsonStr = text.trim();
    
    // Remove markdown code blocks if present
    const codeBlockMatch = jsonStr.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (codeBlockMatch) {
      jsonStr = codeBlockMatch[1].trim();
    }
    
    // Try to find JSON object or array
    const jsonMatch = jsonStr.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
    if (jsonMatch) {
      jsonStr = jsonMatch[1];
    }
    
    return JSON.parse(jsonStr) as T;
  } catch {
    console.warn('Failed to parse AI response as JSON, using fallback');
    return fallback;
  }
}

// ============================================================
// CORE: Generate Personalized Workout Plan
// ============================================================

export async function generateAIWorkoutPlan(
  quizAnswers: Record<string, string | string[] | number>,
  scores: { readinessScore: number; consistencyScore: number; bodyTransformationScore: number; nutritionComplianceScore: number; supportNeedScore: number; overallScore: number; fitnessLevel: string; goalCategory: string; bodyType: string; bmi?: number; bmiCategory?: string }
): Promise<AIWorkoutPlan> {
  const goal = quizAnswers.q1 || 'fat_loss';
  const location = quizAnswers.q14 || 'gym';
  const age = quizAnswers.q5 || 25;
  const weight = quizAnswers.q7 || 75;
  const height = quizAnswers.q6 || 170;
  const bodyType = quizAnswers.q8 || 'average';
  const timeCommitment = quizAnswers.q15 || '30_45_min';
  const fitnessExperience = quizAnswers.q3 || 'just_starting';
  const workoutTime = quizAnswers.q16 || 'evening';
  const dreamBody = quizAnswers.q9 || 'athletic_toned';
  const stress = Number(quizAnswers.q18) || 5;
  const sleep = Number(quizAnswers.q17) || 5;
  const activityLevel = quizAnswers.q19 || 'sedentary';
  const importantFactors = Array.isArray(quizAnswers.q12) ? quizAnswers.q12.join(', ') : 'strength';
  const bmi = scores.bmi || Math.round(Number(weight) / ((Number(height)/100) ** 2) * 10) / 10;
  const bmiCategory = scores.bmiCategory || 'Normal';

  const bmiGuidance = bmiCategory === 'Obese'
    ? 'IMPORTANT: User is obese. Start with low-impact exercises. NO jumping. Include walking, modified push-ups, resistance bands. Focus on consistency over intensity. Protect joints.'
    : bmiCategory === 'Overweight'
    ? 'User is overweight. Mix of low-impact and moderate exercises. Include some HIIT but not too intense. Protect knees and lower back.'
    : bmiCategory === 'Underweight'
    ? 'User is underweight. Focus on muscle building, NOT cardio. Heavier weights, fewer reps, longer rest. Progressive overload is key.'
    : 'User is in normal BMI range. Focus on body recomposition - building muscle while maintaining low body fat.';

  const prompt = `You are an expert Indian fitness coach creating a highly personalized workout plan. Generate a detailed workout plan in JSON format.

USER PROFILE:
- Goal: ${goal} (${goal === 'fat_loss' ? 'Fat Loss' : goal === 'muscle_gain' ? 'Muscle Gain' : goal === 'skinny_fat' ? 'Body Recomposition' : 'Overall Fitness'})
- Workout Location: ${location === 'home' ? 'Home (no gym equipment)' : location === 'gym' ? 'Gym (full equipment)' : 'Both Home and Gym'}
- Age: ${age}, Weight: ${weight}kg, Height: ${height}cm
- BMI: ${bmi} (${bmiCategory})
- Body Type: ${bodyType}
- Fitness Experience: ${fitnessExperience}
- Time Per Session: ${timeCommitment === '20_30_min' ? '20-30 min' : timeCommitment === '30_45_min' ? '30-45 min' : timeCommitment === '45_60_min' ? '45-60 min' : '60+ min'}
- Preferred Workout Time: ${workoutTime}
- Dream Body: ${dreamBody}
- Activity Level: ${activityLevel}
- Stress Level: ${stress}/10, Sleep Quality: ${sleep}/10
- Important Factors: ${importantFactors}
- Readiness Score: ${scores.readinessScore}/100
- Consistency Score: ${scores.consistencyScore}/100
- Fitness Level: ${scores.fitnessLevel}

BMI GUIDANCE: ${bmiGuidance}

RULES:
1. Generate ${scores.fitnessLevel === 'beginner' ? '3' : scores.fitnessLevel === 'novice' ? '4' : '5'} workout days
2. For beginners: focus on form, compound movements, lighter weights, more reps
3. For intermediate: progressive overload, heavier weights, supersets
4. For home workouts: use bodyweight, resistance bands, water bottles, chairs
5. Adjust weight recommendations based on the user's weight and fitness level
6. Include Indian exercise names where relevant (surya namaskar, etc.)
7. Add specific rest times between sets based on goal (fat loss = shorter rest, muscle gain = longer)
8. Add a "tips" field per exercise with form cues in Hinglish

Return ONLY valid JSON in this exact structure:
{
  "name": "Personalized plan name (creative, e.g. 'Beta Block Shred Plan')",
  "description": "One-line description in Hinglish",
  "daysPerWeek": number,
  "duration": "90 Days",
  "days": [
    {
      "dayNumber": 1,
      "title": "Day title (e.g. 'Push Day - Chest & Shoulders')",
      "exercises": [
        {
          "id": "e1",
          "name": "Exercise name",
          "equipment": "Equipment needed",
          "sets": [
            {"weight": number_in_kg, "reps": number, "completed": false}
          ],
          "completed": false,
          "skipped": false,
          "restSeconds": 60,
          "tips": "Hinglish form tip"
        }
      ],
      "completed": false,
      "weekNumber": 1
    }
  ]
}`;

  const fallbackWorkout: AIWorkoutPlan = {
    name: 'FitMuscles Starter Plan',
    description: 'Beginner-friendly plan to start your transformation',
    daysPerWeek: 3,
    duration: '90 Days',
    days: [
      {
        dayNumber: 1,
        title: 'Push Day - Chest & Triceps',
        exercises: [
          { id: 'e1', name: 'Push-ups', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }, { weight: 0, reps: 8, completed: false }], completed: false, skipped: false, restSeconds: 45, tips: 'Body straight rakho, core tight rakho' },
          { id: 'e2', name: 'Dumbbell Press', equipment: 'Dumbbells', sets: [{ weight: 12, reps: 12, completed: false }, { weight: 14, reps: 10, completed: false }], completed: false, skipped: false, restSeconds: 60, tips: 'Slowly niche lao, control me rakho' },
          { id: 'e3', name: 'Tricep Dips', equipment: 'Chair', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false, restSeconds: 45, tips: 'Chair pe haath rakho, slowly niche jao' },
        ],
        completed: false,
        weekNumber: 1,
      },
      {
        dayNumber: 2,
        title: 'Pull Day - Back & Biceps',
        exercises: [
          { id: 'e4', name: 'Lat Pulldown', equipment: 'Cable', sets: [{ weight: 30, reps: 12, completed: false }, { weight: 35, reps: 10, completed: false }], completed: false, skipped: false, restSeconds: 60, tips: 'Bar ko chest tak kheencho, squeeze karo' },
          { id: 'e5', name: 'Dumbbell Row', equipment: 'Dumbbell', sets: [{ weight: 14, reps: 12, completed: false }, { weight: 16, reps: 10, completed: false }], completed: false, skipped: false, restSeconds: 60, tips: 'Elbow peeche le jao, back squeeze karo' },
          { id: 'e6', name: 'Bicep Curls', equipment: 'Dumbbells', sets: [{ weight: 8, reps: 15, completed: false }, { weight: 10, reps: 12, completed: false }], completed: false, skipped: false, restSeconds: 45, tips: 'Body mat hilao, sirf haath move karo' },
        ],
        completed: false,
        weekNumber: 1,
      },
      {
        dayNumber: 3,
        title: 'Legs & Core',
        exercises: [
          { id: 'e7', name: 'Squats', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 15, completed: false }, { weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false, restSeconds: 60, tips: 'Ghutne toes se aage mat jaane do' },
          { id: 'e8', name: 'Lunges', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 12, completed: false }, { weight: 0, reps: 10, completed: false }], completed: false, skipped: false, restSeconds: 45, tips: 'Dono ghutne 90 degree pe jhaanko' },
          { id: 'e9', name: 'Plank', equipment: 'Bodyweight', sets: [{ weight: 0, reps: 30, completed: false }, { weight: 0, reps: 30, completed: false }], completed: false, skipped: false, restSeconds: 30, tips: 'Core tight rakho, hips mat utaaro' },
        ],
        completed: false,
        weekNumber: 1,
      },
    ],
  };

  try {
    const ai = await getAIClient();
    const completion = await ai.chat.completions.create({
      messages: [
        { role: 'system', content: 'You are an expert Indian fitness coach. Always respond with valid JSON only. No markdown, no explanation, just the JSON object. Use Hinglish for tips and descriptions.' },
        { role: 'user', content: prompt },
      ],
      temperature: 0.7,
      max_tokens: 4000,
    });

    const text = completion.choices?.[0]?.message?.content || '';
    return safeParseAIResponse<AIWorkoutPlan>(text, fallbackWorkout);
  } catch (error) {
    console.error('AI Workout Plan generation failed:', error);
    return fallbackWorkout;
  }
}

// ============================================================
// CORE: Generate Personalized Meal Plan
// ============================================================

export async function generateAIMealPlan(
  quizAnswers: Record<string, string | string[] | number>,
  scores: { overallScore: number; goalCategory: string; fitnessLevel: string; bodyType: string; nutritionComplianceScore: number }
): Promise<AIMealPlan> {
  const goal = quizAnswers.q1 || 'fat_loss';
  const dietType = quizAnswers.q20 || 'non_veg';
  const budget = quizAnswers.q21 || 'medium';
  const mealsPerDay = quizAnswers.q22 === '2_meals' ? 2 : quizAnswers.q22 === '4_meals' ? 4 : quizAnswers.q22 === '5_plus' ? 5 : 3;
  const weight = quizAnswers.q7 || 75;
  const height = quizAnswers.q6 || 170;
  const age = quizAnswers.q5 || 25;
  const gender = quizAnswers.q4 || 'male';
  const activityLevel = quizAnswers.q19 || 'sedentary';
  const dietStruggle = quizAnswers.q23 || 'dont_know';
  const waterIntake = quizAnswers.q24 || '1_2l';

  // Calculate TDEE (Mifflin-St Jeor)
  const heightNum = Number(height);
  const weightNum = Number(weight);
  const ageNum = Number(age);
  const bmr = gender === 'female'
    ? 10 * weightNum + 6.25 * heightNum - 5 * ageNum - 161
    : 10 * weightNum + 6.25 * heightNum - 5 * ageNum + 5;
  const activityMultiplier = activityLevel === 'sedentary' ? 1.2 : activityLevel === 'light_active' ? 1.375 : activityLevel === 'moderate_active' ? 1.55 : 1.725;
  let tdee = Math.round(bmr * activityMultiplier);

  // Adjust for goal
  if (goal === 'fat_loss') tdee = Math.round(tdee * 0.8);
  else if (goal === 'muscle_gain') tdee = Math.round(tdee * 1.15);

  const proteinTarget = Math.round(weightNum * (goal === 'muscle_gain' ? 2.2 : goal === 'fat_loss' ? 2.0 : 1.8));

  const dietLabel = dietType === 'veg' ? 'Vegetarian' : dietType === 'non_veg' ? 'Non-Vegetarian' : dietType === 'vegan' ? 'Vegan' : 'Eggetarian';
  const budgetLabel = budget === 'budget' ? 'Budget (Rs 2000-3000/month)' : budget === 'premium' ? 'Premium (Rs 5000+/month)' : 'Medium (Rs 3000-5000/month)';
  const struggleLabel = dietStruggle === 'junk_cravings' ? 'Junk food cravings' : dietStruggle === 'no_time' ? 'No time to cook' : dietStruggle === 'dont_know' ? "Doesn't know what to eat" : 'Portion control';

  const prompt = `You are an expert Indian nutritionist creating a highly personalized meal plan. Generate a detailed meal plan in JSON format.

USER PROFILE:
- Goal: ${goal} (${goal === 'fat_loss' ? 'Fat Loss' : goal === 'muscle_gain' ? 'Muscle Gain' : goal === 'skinny_fat' ? 'Body Recomposition' : 'Overall Fitness'})
- Diet Type: ${dietLabel}
- Budget: ${budgetLabel}
- Meals Per Day: ${mealsPerDay}
- Weight: ${weightNum}kg, Height: ${heightNum}cm, Age: ${ageNum}
- Calculated TDEE: ${tdee} kcal/day
- Protein Target: ${proteinTarget}g/day
- Diet Struggle: ${struggleLabel}
- Water Intake: ${waterIntake}
- Activity Level: ${activityLevel}

CRITICAL RULES:
1. ALL meals must be Indian food (dals, sabzis, roti, rice, paneer, eggs, chicken, etc.)
2. Match the user's budget - for budget users use affordable proteins (dal, eggs, soya, paneer), for premium use chicken, whey, dry fruits
3. Respect the diet type strictly - NO non-veg in veg plan, NO dairy in vegan plan
4. Calculate macros that add up correctly for each meal
5. Include proper meal timing based on Indian eating habits
6. ${goal === 'fat_loss' ? 'Keep calories around ' + tdee + ' kcal (deficit from TDEE)' : goal === 'muscle_gain' ? 'Keep calories around ' + tdee + ' kcal (surplus from TDEE)' : 'Keep calories around ' + tdee + ' kcal'}
7. Protein must be high: target ${proteinTarget}g per day
8. Include ${mealsPerDay >= 4 ? 'snacks between meals' : 'just main meals'}
9. Make meals varied and interesting - not the same everyday food
10. Add specific quantities in Indian cooking terms (katori, roti, bowl, glass)

Return ONLY valid JSON:
{
  "name": "Creative plan name in Hinglish",
  "dailyCalories": ${tdee},
  "dailyProtein": ${proteinTarget},
  "dailyCarbs": number,
  "dailyFat": number,
  "meals": [
    {
      "id": "m1",
      "type": "breakfast|lunch|snack|dinner",
      "name": "Meal name",
      "time": "8:00 AM",
      "items": [
        {"name": "Food item", "quantity": "1 katori", "calories": number, "protein": number, "carbs": number, "fat": number}
      ],
      "totalCalories": number,
      "totalProtein": number,
      "swapped": false
    }
  ]
}`;

  const fallbackMeal: AIMealPlan = {
    name: 'High Protein Indian Plan',
    dailyCalories: tdee,
    dailyProtein: proteinTarget,
    dailyCarbs: Math.round((tdee - proteinTarget * 4 - tdee * 0.25) / 4),
    dailyFat: Math.round(tdee * 0.25 / 9),
    meals: dietType === 'vegan' ? [
      { id: 'm1', type: 'breakfast', name: 'Oats & Banana Smoothie', time: '8:00 AM', items: [{ name: 'Oats', quantity: '1/2 cup', calories: 150, protein: 5, carbs: 27, fat: 3 }, { name: 'Banana', quantity: '1 pc', calories: 105, protein: 1, carbs: 27, fat: 0 }, { name: 'Soy Milk', quantity: '1 glass', calories: 80, protein: 7, carbs: 6, fat: 4 }], totalCalories: 335, totalProtein: 13, swapped: false },
      { id: 'm2', type: 'lunch', name: 'Chana Dal & Rice', time: '1:00 PM', items: [{ name: 'Chana Dal', quantity: '1 bowl', calories: 200, protein: 14, carbs: 30, fat: 4 }, { name: 'Rice', quantity: '1 cup', calories: 200, protein: 4, carbs: 42, fat: 1 }, { name: 'Soy Chunks Sabzi', quantity: '1 katori', calories: 180, protein: 18, carbs: 10, fat: 6 }], totalCalories: 580, totalProtein: 36, swapped: false },
      { id: 'm3', type: 'dinner', name: 'Tofu Bhurji & Roti', time: '8:00 PM', items: [{ name: 'Tofu Bhurji', quantity: '150g', calories: 220, protein: 20, carbs: 6, fat: 12 }, { name: 'Roti', quantity: '2 pcs', calories: 200, protein: 6, carbs: 38, fat: 3 }], totalCalories: 420, totalProtein: 26, swapped: false },
    ] : dietType === 'veg' ? [
      { id: 'm1', type: 'breakfast', name: 'Poha & Sprouts', time: '8:00 AM', items: [{ name: 'Poha', quantity: '1 cup', calories: 250, protein: 6, carbs: 45, fat: 5 }, { name: 'Sprouts Salad', quantity: '1 bowl', calories: 120, protein: 8, carbs: 15, fat: 2 }], totalCalories: 370, totalProtein: 14, swapped: false },
      { id: 'm2', type: 'lunch', name: 'Paneer Bhurji & Roti', time: '1:00 PM', items: [{ name: 'Paneer Bhurji', quantity: '150g', calories: 280, protein: 22, carbs: 8, fat: 18 }, { name: 'Roti', quantity: '2 pcs', calories: 200, protein: 6, carbs: 38, fat: 3 }, { name: 'Curd', quantity: '1 bowl', calories: 60, protein: 4, carbs: 5, fat: 3 }], totalCalories: 540, totalProtein: 32, swapped: false },
      { id: 'm3', type: 'dinner', name: 'Dal Chawal & Sabzi', time: '8:00 PM', items: [{ name: 'Dal Tadka', quantity: '1 bowl', calories: 180, protein: 12, carbs: 25, fat: 5 }, { name: 'Rice', quantity: '1 cup', calories: 200, protein: 4, carbs: 42, fat: 1 }, { name: 'Mixed Sabzi', quantity: '1 bowl', calories: 100, protein: 4, carbs: 12, fat: 4 }], totalCalories: 480, totalProtein: 20, swapped: false },
    ] : [
      { id: 'm1', type: 'breakfast', name: 'Egg Bhurji & Toast', time: '8:00 AM', items: [{ name: 'Egg Bhurji (3 eggs)', quantity: '3 eggs', calories: 240, protein: 20, carbs: 2, fat: 16 }, { name: 'Brown Bread Toast', quantity: '2 slices', calories: 140, protein: 5, carbs: 24, fat: 2 }], totalCalories: 380, totalProtein: 25, swapped: false },
      { id: 'm2', type: 'lunch', name: 'Chicken Curry & Rice', time: '1:00 PM', items: [{ name: 'Chicken Curry', quantity: '200g', calories: 320, protein: 35, carbs: 8, fat: 16 }, { name: 'Rice', quantity: '1 cup', calories: 200, protein: 4, carbs: 42, fat: 1 }], totalCalories: 520, totalProtein: 39, swapped: false },
      { id: 'm3', type: 'dinner', name: 'Tandoori Chicken & Roti', time: '8:00 PM', items: [{ name: 'Tandoori Chicken', quantity: '200g', calories: 280, protein: 38, carbs: 4, fat: 12 }, { name: 'Roti', quantity: '2 pcs', calories: 200, protein: 6, carbs: 38, fat: 3 }], totalCalories: 480, totalProtein: 44, swapped: false },
    ],
  };

  try {
    const ai = await getAIClient();
    const completion = await ai.chat.completions.create({
      messages: [
        { role: 'system', content: 'You are an expert Indian nutritionist. Always respond with valid JSON only. No markdown, no explanation, just the JSON object. All meals must be Indian food.' },
        { role: 'user', content: prompt },
      ],
      temperature: 0.7,
      max_tokens: 4000,
    });

    const text = completion.choices?.[0]?.message?.content || '';
    return safeParseAIResponse<AIMealPlan>(text, fallbackMeal);
  } catch (error) {
    console.error('AI Meal Plan generation failed:', error);
    return fallbackMeal;
  }
}

// ============================================================
// CORE: Generate Personalized AI Report
// ============================================================

export async function generateAIReport(
  quizAnswers: Record<string, string | string[] | number>,
  scores: { readinessScore: number; consistencyScore: number; bodyTransformationScore: number; nutritionComplianceScore: number; supportNeedScore: number; overallScore: number; fitnessLevel: string; goalCategory: string; bodyType: string; bmi?: number; bmiCategory?: string; height?: number; weight?: number; targetWeight?: number }
): Promise<AIReport> {
  const goal = quizAnswers.q1 || 'fat_loss';
  const age = quizAnswers.q5 || 25;
  const weight = quizAnswers.q7 || 75;
  const height = quizAnswers.q6 || 170;
  const bodyType = quizAnswers.q8 || 'average';
  const dreamBody = quizAnswers.q9 || 'athletic_toned';
  const frustration = quizAnswers.q2 || 'confused';
  const commitment = quizAnswers.q28 || 5;
  const dietType = quizAnswers.q20 || 'non_veg';
  const location = quizAnswers.q14 || 'gym';
  const timeCommitment = quizAnswers.q11 || '90_days';
  const quitReason = quizAnswers.q26 || 'boredom';
  const selfDescription = quizAnswers.q27 || 'action_taker';
  const stress = Number(quizAnswers.q18) || 5;
  const sleep = Number(quizAnswers.q17) || 5;
  const bmi = scores.bmi || Math.round(Number(weight) / ((Number(height)/100) ** 2) * 10) / 10;
  const bmiCategory = scores.bmiCategory || 'Normal';
  const targetWeight = scores.targetWeight || Math.round(24.9 * (Number(height)/100) ** 2 * 10) / 10;

  const prompt = `You are an expert AI fitness analyst creating a deeply personalized transformation report. Analyze this user's quiz data and generate a comprehensive report in JSON format.

USER COMPLETE PROFILE:
- Goal: ${goal}
- Age: ${age}, Weight: ${weight}kg, Height: ${height}cm
- BMI: ${bmi} (${bmiCategory}) - Target Weight: ${targetWeight}kg
- Body Type: ${bodyType}, Dream Body: ${dreamBody}
- Biggest Frustration: ${frustration}
- Commitment Level: ${commitment}/10
- Diet Type: ${dietType}
- Workout Location: ${location}
- Time Commitment: ${timeCommitment}
- Past Quit Reason: ${quitReason}
- Self Description: ${selfDescription}
- Stress: ${stress}/10, Sleep: ${sleep}/10

SCORES:
- Readiness: ${scores.readinessScore}/100
- Consistency: ${scores.consistencyScore}/100
- Body Transformation Potential: ${scores.bodyTransformationScore}/100
- Nutrition Compliance: ${scores.nutritionComplianceScore}/100
- Support Need: ${scores.supportNeedScore}/100
- Overall: ${scores.overallScore}/100
- Fitness Level: ${scores.fitnessLevel}

Generate a highly personalized report in Hinglish that feels like it was written by a real coach who understands this specific person. Be specific about their body, their struggles, their potential. MENTION THEIR BMI AND WHAT IT MEANS FOR THEM.

Return ONLY valid JSON:
{
  "summary": "2-3 sentence personalized summary in Hinglish about who they are and what they need",
  "bodyAnalysis": "2-3 sentence specific analysis of their body type, current state, and what needs to change - mention their specific weight and body type",
  "bmiAnalysis": "2-3 sentence analysis of their BMI (${bmi}, ${bmiCategory}), what it means for their health, and what their target weight should be (${targetWeight}kg)",
  "strengths": ["strength1 in Hinglish", "strength2", "strength3"],
  "weaknesses": ["weakness1 in Hinglish with specific advice", "weakness2", "weakness3"],
  "month1Prediction": {"weightChange": "specific kg range", "muscleChange": "specific description", "strengthGain": "specific % range", "confidence": "High/Medium/Low with reason"},
  "month2Prediction": {"weightChange": "specific kg range", "muscleChange": "specific description", "strengthGain": "specific % range", "confidence": "High/Medium/Low with reason"},
  "month3Prediction": {"weightChange": "specific kg range", "muscleChange": "specific description", "strengthGain": "specific % range", "confidence": "High/Medium/Low with reason"},
  "dietAdvice": "2-3 sentences of specific diet advice mentioning their diet type and struggle",
  "workoutAdvice": "2-3 sentences of specific workout advice mentioning their location and time",
  "lifestyleAdvice": "2-3 sentences about sleep, stress, and habits",
  "motivationalMessage": "A powerful, personal motivational message in Hinglish that addresses their specific frustration and quit reason",
  "dietRecommendation": {"type": "Diet type name", "calories": number, "protein": number, "reason": "Why these specific numbers for this person"},
  "workoutRecommendation": {"location": "gym/home", "daysPerWeek": number, "sessionDuration": "duration", "focus": "specific focus area", "splitType": "Push/Pull/Legs or Upper/Lower or Full Body"}
}`;

  const fallbackReport: AIReport = {
    summary: `Aap ${scores.fitnessLevel === 'beginner' ? 'ek beginner ho jo abhi start karna chahte ho' : scores.fitnessLevel === 'novice' ? 'kuch experience wale ho par consistency chahiye' : 'experienced ho par next level pe jaana hai'}. Aapka main goal ${goal === 'fat_loss' ? 'fat loss' : goal === 'muscle_gain' ? 'muscle gain' : 'body transformation'} hai aur aapka readiness score ${scores.readinessScore}% hai.`,
    bodyAnalysis: `Aapka current weight ${weight}kg hai aur body type ${bodyType} hai. Aapka dream body ${dreamBody} hai jo achievable hai with right plan and consistency.`,
    bmiAnalysis: `Aapka BMI ${bmi} hai jo ${bmiCategory} category me aata hai. ${bmiCategory === 'Obese' ? 'Ye health ke liye concern hai - consistent exercise aur diet se aap healthy range me aa sakte ho.' : bmiCategory === 'Overweight' ? 'Thoda aur focus lagao aur aap normal range me aa jaaoge. Target weight ' + targetWeight + 'kg hai.' : bmiCategory === 'Underweight' ? 'Aapko muscle gain karna hai healthy weight achieve karne ke liye. Target weight ' + targetWeight + 'kg hai.' : 'Aapka BMI healthy range me hai - ab body composition improve karo muscle building se. Target weight ' + targetWeight + 'kg.'}`,
    strengths: [scores.readinessScore >= 70 ? 'Aapki readiness bahut strong hai - aap ready ho start karne ke liye!' : 'Aapme potential hai, bas thoda aur commitment chahiye', scores.consistencyScore >= 60 ? 'Consistency aapki strong side hai' : 'Daily routine banana aapke liye important hoga', 'Aapko apna body transform karna hai - ye motivation bahut powerful hai'],
    weaknesses: [scores.supportNeedScore >= 60 ? 'Aapko zyada support chahiye - isliye daily reminders aur check-ins important hain' : 'Thoda aur focus chahiye diet pe', scores.consistencyScore < 60 ? 'Past me consistency ruki hai - is baar daily check-in karo' : 'Progressive overload follow karo strictly', scores.nutritionComplianceScore < 60 ? 'Diet pe zyada focus karo - 70% results diet se aate hain' : 'Recovery pe dhyan do'],
    month1Prediction: { weightChange: goal === 'fat_loss' ? '-2 to -3 kg' : goal === 'muscle_gain' ? '+1 to +1.5 kg' : '-1 to +0.5 kg', muscleChange: 'Initial muscle activation and neural adaptation', strengthGain: '15-25%', confidence: 'High - first month me body respond karti hai' },
    month2Prediction: { weightChange: goal === 'fat_loss' ? '-4 to -5 kg' : goal === 'muscle_gain' ? '+2 to +3 kg' : '-2 to +1 kg', muscleChange: 'Visible muscle definition starts', strengthGain: '30-45%', confidence: 'Medium-High - consistency key hai' },
    month3Prediction: { weightChange: goal === 'fat_loss' ? '-6 to -8 kg' : goal === 'muscle_gain' ? '+3.5 to +5 kg' : '-3 to +2 kg', muscleChange: 'Noticeable body transformation', strengthGain: '50-70%', confidence: 'Medium - long term commitment required' },
    dietAdvice: `Aapki diet ${dietType} hai. Protein target hit karna sabse important hai - ${dietType === 'veg' ? 'paneer, dal, soya chunks' : dietType === 'vegan' ? 'tofu, lentils, soy milk, nuts' : 'chicken, eggs, fish'} se protein lein. ${quizAnswers.q23 === 'junk_cravings' ? 'Junk food cravings ke liye healthy alternatives rakhho - roasted chana, makhana.' : quizAnswers.q23 === 'no_time' ? 'Meal prep Sunday karo - full week ka tiffin ready rakho.' : 'Right food choice hi sabse bada game changer hai.'}`,
    workoutAdvice: `${location === 'home' ? 'Home workout me consistency important hai - daily same time pe karo' : 'Gym me progressive overload follow karo - har week thoda weight badhao'}. ${timeCommitment === '30_days' ? '30 days me noticeable changes aayenge par 90 days me real transformation' : '90 days consistent rehna is the key'}.`,
    lifestyleAdvice: `Aapki sleep quality ${sleep}/10 hai ${sleep < 5 ? '- ye improve karna bahut zaroori hai, 7-8 hours sona target karo' : '- achhi hai, maintain karo'}. Stress level ${stress}/10 ${stress >= 7 ? '- ye body recovery ko affect karta hai. Meditation ya walking try karo' : '- manageable hai'}. Paani 3L+ piyo daily.`,
    motivationalMessage: `${frustration === 'confused' ? 'Ab confusion khatam! Tumhare paas ab clear plan hai - bas follow karo. No more "kya karu" - ab sab clear hai!' : frustration === 'inconsistent' ? 'Is baar consistency nahi rukegi! Daily check-in + WhatsApp reminders = no more skipping. Tum kar sakte ho!' : frustration === 'no_results' ? 'Pehle results nahi dikhe kyunki plan personalized nahi tha. Ab AI ne tumhare liye custom plan banaya hai - results aayenge!' : 'Diet follow nahi hoti? Is baar Indian food se plan bana hai - jo tum khate ho, wohi but healthier version. Easy to follow!'}`,
    dietRecommendation: { type: `${dietType === 'veg' ? 'High Protein Vegetarian' : dietType === 'non_veg' ? 'High Protein Non-Veg' : dietType === 'vegan' ? 'Plant Power Vegan' : 'High Protein Eggetarian'}`, calories: goal === 'fat_loss' ? 1800 : goal === 'muscle_gain' ? 2500 : 2200, protein: goal === 'muscle_gain' ? Math.round(Number(weight) * 2.2) : Math.round(Number(weight) * 1.8), reason: `Ye calories aur protein aapke ${weight}kg weight aur ${goal} goal ke hisaab se calculated hai` },
    workoutRecommendation: { location: location === 'home' ? 'home' : 'gym', daysPerWeek: scores.fitnessLevel === 'beginner' ? 3 : 4, sessionDuration: '45 min', focus: goal === 'fat_loss' ? 'Strength + HIIT Circuit' : goal === 'muscle_gain' ? 'Heavy Compound Lifts + Progressive Overload' : 'Balanced Strength Training', splitType: scores.fitnessLevel === 'beginner' ? 'Full Body' : 'Push/Pull/Legs' },
  };

  try {
    const ai = await getAIClient();
    const completion = await ai.chat.completions.create({
      messages: [
        { role: 'system', content: 'You are an expert AI fitness analyst. Always respond with valid JSON only. No markdown, no explanation, just the JSON object. Write all text in Hinglish (Hindi-English mix that Indian youth speaks). Be specific and personal.' },
        { role: 'user', content: prompt },
      ],
      temperature: 0.8,
      max_tokens: 3000,
    });

    const text = completion.choices?.[0]?.message?.content || '';
    return safeParseAIResponse<AIReport>(text, fallbackReport);
  } catch (error) {
    console.error('AI Report generation failed:', error);
    return fallbackReport;
  }
}

// ============================================================
// CORE: Generate Daily Insight
// ============================================================

export async function generateAIDailyInsight(
  quizAnswers: Record<string, string | string[] | number>,
  scores: { overallScore: number; goalCategory: string; fitnessLevel: string; readinessScore: number; consistencyScore: number; bmi?: number; bmiCategory?: string },
  streak: number,
  recentCheckIns: { workoutDone: boolean; proteinIntake: number; mood: string }[]
): Promise<AIDailyInsight> {
  const goal = quizAnswers.q1 || 'fat_loss';
  const name = quizAnswers.q4 === 'female' ? 'Didi' : 'Bhai';
  const frustration = quizAnswers.q2 || 'confused';
  const motivationStyle = quizAnswers.q25 || 'rewards';
  const selfDescription = quizAnswers.q27 || 'action_taker';
  const weight = quizAnswers.q7 || 75;
  const bmi = scores.bmi || '';

  const recentWorkouts = recentCheckIns.filter(c => c.workoutDone).length;
  const avgProtein = recentCheckIns.length > 0 ? Math.round(recentCheckIns.reduce((s, c) => s + c.proteinIntake, 0) / recentCheckIns.length) : 0;

  const prompt = `Generate a personalized daily fitness insight in JSON for this user:

- Name style: ${name}
- Goal: ${goal}
- Current weight: ${weight}kg, BMI: ${bmi}
- Current streak: ${streak} days
- Recent activity: ${recentWorkouts} workouts done in recent check-ins
- Average protein intake: ${avgProtein}g
- Frustration: ${frustration}
- Motivation style: ${motivationStyle}
- Self description: ${selfDescription}
- Readiness: ${scores.readinessScore}/100

${motivationStyle === 'competition' ? 'Use competitive, challenging language' : motivationStyle === 'accountability' ? 'Use accountability partner style' : motivationStyle === 'data_tracking' ? 'Use data-driven, analytical language' : 'Use rewards and milestone language'}

Return ONLY valid JSON:
{
  "greeting": "Personalized greeting in Hinglish (e.g. 'Good morning bhai!')",
  "focus": "Today's specific focus based on their goal and recent activity",
  "motivation": "A powerful 1-2 line motivational message addressing their specific frustration",
  "workoutTip": "One specific workout tip for today",
  "nutritionTip": "One specific nutrition tip for today based on their protein intake",
  "mindsetTip": "One mindset tip based on their self description"
}`;

  const fallbackInsight: AIDailyInsight = {
    greeting: streak > 0 ? `${name}, ${streak} din ho gaye! 🔥` : `Aaj naya din hai ${name}!`,
    focus: goal === 'fat_loss' ? 'Aaj calorie deficit maintain karo aur workout miss mat karo' : goal === 'muscle_gain' ? 'Aaj heavy lifts pe focus karo - progressive overload is key' : 'Aaj balanced training + proper nutrition pe focus karo',
    motivation: frustration === 'confused' ? 'Ab clear plan hai - bas execute karo!' : frustration === 'inconsistent' ? 'Ek aur day done = streak strong!' : 'Consistency hi transformation laati hai!',
    workoutTip: scores.fitnessLevel === 'beginner' ? 'Form pe focus karo, weight baad me badhana' : 'Last set me failure tak jao',
    nutritionTip: avgProtein < 100 ? 'Protein thoda aur lelo - egg ya dal add karo' : 'Protein target lag raha hai, aise hi rakhho!',
    mindsetTip: selfDescription === 'overthinker' ? 'Overthinking band karo, bas start karo - 20 min bhi kaafi hai' : selfDescription === 'need_push' ? 'Aaj push yourself - last rep pe rukna mat!' : 'Consistency > perfection',
  };

  try {
    const ai = await getAIClient();
    const completion = await ai.chat.completions.create({
      messages: [
        { role: 'system', content: 'You are a fitness motivation coach. Always respond with valid JSON only. Write in Hinglish. Be energetic, personal, and specific.' },
        { role: 'user', content: prompt },
      ],
      temperature: 0.9,
      max_tokens: 800,
    });

    const text = completion.choices?.[0]?.message?.content || '';
    return safeParseAIResponse<AIDailyInsight>(text, fallbackInsight);
  } catch (error) {
    console.error('AI Daily Insight generation failed:', error);
    return fallbackInsight;
  }
}

// ============================================================
// CORE: Generate Meal Swap
// ============================================================

export async function generateAIMealSwap(
  currentMeal: { name: string; type: string; totalCalories: number; totalProtein: number },
  quizAnswers: Record<string, string | string[] | number>,
  remainingCalories: number,
  remainingProtein: number
): Promise<AIMealSwap> {
  const dietType = quizAnswers.q20 || 'non_veg';
  const goal = quizAnswers.q1 || 'fat_loss';
  const budget = quizAnswers.q21 || 'medium';

  const prompt = `Suggest an alternative Indian meal to swap for this:

Current Meal: ${currentMeal.name} (${currentMeal.type})
Current Calories: ${currentMeal.totalCalories}, Protein: ${currentMeal.totalProtein}g
Remaining daily calories: ${remainingCalories}, Remaining protein: ${remainingProtein}g
Diet Type: ${dietType}, Goal: ${goal}, Budget: ${budget}

Keep the swap in similar calorie/protein range. Must be Indian food. Must match diet type.

Return ONLY valid JSON:
{
  "name": "Swap meal name",
  "items": [
    {"name": "Item", "quantity": "amount", "calories": number, "protein": number, "carbs": number, "fat": number}
  ],
  "totalCalories": number,
  "totalProtein": number,
  "reason": "Why this is a good swap in Hinglish"
}`;

  const fallbackSwap: AIMealSwap = {
    name: dietType === 'veg' ? 'Palak Paneer & Roti' : dietType === 'vegan' ? 'Tofu Tikka & Roti' : 'Grilled Chicken & Roti',
    items: dietType === 'veg' ? [
      { name: 'Palak Paneer', quantity: '1 katori', calories: 250, protein: 18, carbs: 10, fat: 15 },
      { name: 'Roti', quantity: '2 pcs', calories: 200, protein: 6, carbs: 38, fat: 3 },
    ] : dietType === 'vegan' ? [
      { name: 'Tofu Tikka', quantity: '150g', calories: 230, protein: 20, carbs: 8, fat: 12 },
      { name: 'Roti', quantity: '2 pcs', calories: 200, protein: 6, carbs: 38, fat: 3 },
    ] : [
      { name: 'Grilled Chicken', quantity: '200g', calories: 280, protein: 38, carbs: 2, fat: 12 },
      { name: 'Roti', quantity: '2 pcs', calories: 200, protein: 6, carbs: 38, fat: 3 },
    ],
    totalCalories: 450,
    totalProtein: dietType === 'vegan' ? 26 : dietType === 'veg' ? 24 : 44,
    reason: 'Same calories aur protein ke saath variety ke liye perfect swap!',
  };

  try {
    const ai = await getAIClient();
    const completion = await ai.chat.completions.create({
      messages: [
        { role: 'system', content: 'You are an Indian nutritionist. Always respond with valid JSON only. Suggest Indian food meals only.' },
        { role: 'user', content: prompt },
      ],
      temperature: 0.8,
      max_tokens: 1000,
    });

    const text = completion.choices?.[0]?.message?.content || '';
    return safeParseAIResponse<AIMealSwap>(text, fallbackSwap);
  } catch (error) {
    console.error('AI Meal Swap generation failed:', error);
    return fallbackSwap;
  }
}
