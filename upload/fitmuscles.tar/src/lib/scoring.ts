import type { ScoringResult, QuizQuestion } from './types';

export const quizQuestions: QuizQuestion[] = [
  // A. Emotional Hook (Q1-3)
  {
    id: 'q1',
    section: 'Emotional Hook',
    title: 'Aap kya improve karna chahte ho?',
    subtitle: 'Sabse bada goal kya hai aapka?',
    type: 'single',
    options: [
      { label: '🏋️ Fat Loss', value: 'fat_loss' },
      { label: '💪 Muscle Gain', value: 'muscle_gain' },
      { label: '🎯 Skinny Fat to Fit', value: 'skinny_fat' },
      { label: '⚡ Overall Fitness', value: 'overall_fitness' },
    ],
  },
  {
    id: 'q2',
    section: 'Emotional Hook',
    title: 'Sabse bada frustration kya hai?',
    subtitle: 'Aapko sabse zyada kya pareshan karta hai?',
    type: 'single',
    options: [
      { label: 'Kya karu samajh nahi aata', value: 'confused' },
      { label: 'Consistency nahi rukti', value: 'inconsistent' },
      { label: 'Results nahi dikhte', value: 'no_results' },
      { label: 'Diet follow nahi ho paati', value: 'diet_issue' },
    ],
  },
  {
    id: 'q3',
    section: 'Emotional Hook',
    title: 'Kitne time se try kar rahe ho?',
    subtitle: 'Aap kab se transform karna chahte hain?',
    type: 'single',
    options: [
      { label: 'Abhi start karna hai', value: 'just_starting' },
      { label: '1-3 mahine try kiya', value: '1_3_months' },
      { label: '3-6 mahine', value: '3_6_months' },
      { label: '6+ mahine, ab change chahiye', value: '6_plus' },
    ],
  },
  // B. Physical Data (Q4-9)
  {
    id: 'q4',
    section: 'Physical Data',
    title: 'Aapka gender?',
    type: 'single',
    options: [
      { label: '👨 Male', value: 'male' },
      { label: '👩 Female', value: 'female' },
      { label: '🧑 Other', value: 'other' },
    ],
  },
  {
    id: 'q5',
    section: 'Physical Data',
    title: 'Aapki age?',
    subtitle: 'Slider se select karein',
    type: 'slider',
    sliderConfig: { min: 16, max: 60, step: 1, unit: 'years', defaultValue: 25 },
  },
  {
    id: 'q6',
    section: 'Physical Data',
    title: 'Aapki height?',
    subtitle: 'Yeh aapka BMI calculate karne ke liye zaroori hai',
    type: 'slider',
    sliderConfig: { min: 140, max: 200, step: 1, unit: 'cm', defaultValue: 170 },
  },
  {
    id: 'q7',
    section: 'Physical Data',
    title: 'Aapka current weight?',
    subtitle: 'BMI ke liye — aapko apna ideal weight bhi milega',
    type: 'slider',
    sliderConfig: { min: 40, max: 150, step: 0.5, unit: 'kg', defaultValue: 75 },
  },
  {
    id: 'q8',
    section: 'Physical Data',
    title: 'Aapka body type?',
    type: 'single',
    options: [
      { label: '🪶 Skinny / Lean', value: 'skinny' },
      { label: '⚖️ Average', value: 'average' },
      { label: '🐻 Chubby / Heavy', value: 'chubby' },
      { label: '💪 Muscular', value: 'muscular' },
    ],
  },
  {
    id: 'q9',
    section: 'Physical Data',
    title: 'Aapka dream body kaisa hai?',
    type: 'single',
    options: [
      { label: '🏋️ Lean & Ripped', value: 'lean_ripped' },
      { label: '💪 Muscular & Big', value: 'muscular_big' },
      { label: '⚡ Athletic & Toned', value: 'athletic_toned' },
      { label: '🧘 Slim & Flexible', value: 'slim_flexible' },
    ],
  },
  // C. Goal (Q10-13)
  {
    id: 'q10',
    section: 'Goal',
    title: 'Aapka main goal?',
    type: 'single',
    options: [
      { label: '🔥 Lose 5-10 kg', value: 'lose_5_10' },
      { label: '🔥 Lose 10+ kg', value: 'lose_10_plus' },
      { label: '💪 Gain 3-5 kg muscle', value: 'gain_muscle_mod' },
      { label: '💪 Gain 5+ kg muscle', value: 'gain_muscle_high' },
    ],
  },
  {
    id: 'q11',
    section: 'Goal',
    title: 'Kitna time de sakte ho?',
    type: 'single',
    options: [
      { label: '⚡ 30 days challenge', value: '30_days' },
      { label: '🔥 90 days transformation', value: '90_days' },
      { label: '🏆 6 months lifestyle change', value: '6_months' },
      { label: '♾️ Lifetime fitness', value: 'lifetime' },
    ],
  },
  {
    id: 'q12',
    section: 'Goal',
    title: 'Aapke liye kya sabse important hai?',
    type: 'multi',
    options: [
      { label: '💪 Strength', value: 'strength' },
      { label: '🏃 Stamina', value: 'stamina' },
      { label: '👔 Looks', value: 'looks' },
      { label: '🧠 Mental Health', value: 'mental_health' },
      { label: '⚡ Energy', value: 'energy' },
      { label: '🏥 Health Markers', value: 'health' },
    ],
  },
  {
    id: 'q13',
    section: 'Goal',
    title: 'Aapka dream outcome?',
    type: 'single',
    options: [
      { label: '😎 Confident dikhna', value: 'confidence' },
      { label: '👕 Clothes fit hona', value: 'clothes_fit' },
      { label: '💪 Strong feel karna', value: 'feel_strong' },
      { label: '❤️ Healthy rehna', value: 'stay_healthy' },
    ],
  },
  // D. Lifestyle (Q14-19)
  {
    id: 'q14',
    section: 'Lifestyle',
    title: 'Aap kahan workout karenge?',
    type: 'single',
    options: [
      { label: '🏠 Home', value: 'home' },
      { label: '🏋️ Gym', value: 'gym' },
      { label: '🏠🏋️ Both', value: 'both' },
    ],
  },
  {
    id: 'q15',
    section: 'Lifestyle',
    title: 'Kitna time de sakte ho per day?',
    type: 'single',
    options: [
      { label: '⏱️ 20-30 min', value: '20_30_min' },
      { label: '⏱️ 30-45 min', value: '30_45_min' },
      { label: '⏱️ 45-60 min', value: '45_60_min' },
      { label: '⏱️ 60+ min', value: '60_plus_min' },
    ],
  },
  {
    id: 'q16',
    section: 'Lifestyle',
    title: 'Kaunsa time suit karta hai?',
    type: 'single',
    options: [
      { label: '🌅 Morning (6-9 AM)', value: 'morning' },
      { label: '☀️ Afternoon (12-3 PM)', value: 'afternoon' },
      { label: '🌆 Evening (5-8 PM)', value: 'evening' },
      { label: '🌙 Night (8-10 PM)', value: 'night' },
    ],
  },
  {
    id: 'q17',
    section: 'Lifestyle',
    title: 'Aapki sleep quality?',
    type: 'scale',
    scaleConfig: { min: 1, max: 10, labels: ['Very Poor', 'Excellent'] },
  },
  {
    id: 'q18',
    section: 'Lifestyle',
    title: 'Aapka stress level?',
    type: 'scale',
    scaleConfig: { min: 1, max: 10, labels: ['Chill hai', 'Bahut stress'] },
  },
  {
    id: 'q19',
    section: 'Lifestyle',
    title: 'Aapki daily activity level?',
    type: 'single',
    options: [
      { label: '🪑 Sedentary (desk job)', value: 'sedentary' },
      { label: '🚶 Lightly Active', value: 'light_active' },
      { label: '🏃 Moderately Active', value: 'moderate_active' },
      { label: '🏋️ Very Active', value: 'very_active' },
    ],
  },
  // E. Nutrition (Q20-24)
  {
    id: 'q20',
    section: 'Nutrition',
    title: 'Aapki diet preference?',
    type: 'single',
    options: [
      { label: '🥬 Vegetarian', value: 'veg' },
      { label: '🍗 Non-Vegetarian', value: 'non_veg' },
      { label: '🥑 Eggetarian', value: 'eggetarian' },
      { label: '🌱 Vegan', value: 'vegan' },
    ],
  },
  {
    id: 'q21',
    section: 'Nutrition',
    title: 'Aapka diet budget?',
    type: 'single',
    options: [
      { label: '💰 Budget (2-3k/mo)', value: 'budget' },
      { label: '💰💰 Medium (3-5k/mo)', value: 'medium' },
      { label: '💰💰💰 Premium (5k+/mo)', value: 'premium' },
    ],
  },
  {
    id: 'q22',
    section: 'Nutrition',
    title: 'Kitne meals khate ho daily?',
    type: 'single',
    options: [
      { label: '🍽️ 2 meals', value: '2_meals' },
      { label: '🍽️ 3 meals', value: '3_meals' },
      { label: '🍽️ 4 meals', value: '4_meals' },
      { label: '🍽️ 5+ meals', value: '5_plus' },
    ],
  },
  {
    id: 'q23',
    section: 'Nutrition',
    title: 'Diet me sabse bada struggle?',
    type: 'single',
    options: [
      { label: '🍟 Junk food cravings', value: 'junk_cravings' },
      { label: '⏰ Time nahi milta cook karne ka', value: 'no_time' },
      { label: '🤔 Kya khau pata nahi', value: 'dont_know' },
      { label: '🍱 Portion control', value: 'portion_control' },
    ],
  },
  {
    id: 'q24',
    section: 'Nutrition',
    title: 'Daily paani kitna peete ho?',
    type: 'single',
    options: [
      { label: '💧 Less than 1L', value: 'less_1l' },
      { label: '💧 1-2L', value: '1_2l' },
      { label: '💧 2-3L', value: '2_3l' },
      { label: '💧 3L+', value: '3_plus' },
    ],
  },
  // F. Psychology (Q25-28)
  {
    id: 'q25',
    section: 'Psychology',
    title: 'Aapko kya motivate karta hai?',
    type: 'single',
    options: [
      { label: '🔥 Competition / Challenge', value: 'competition' },
      { label: '👥 Accountability partner', value: 'accountability' },
      { label: '📊 Data & tracking', value: 'data_tracking' },
      { label: '🏆 Rewards & milestones', value: 'rewards' },
    ],
  },
  {
    id: 'q26',
    section: 'Psychology',
    title: 'Aap usually kyun quit karte ho?',
    type: 'single',
    options: [
      { label: '😢 Bore ho jata hu', value: 'boredom' },
      { label: '⏰ Time nahi milta', value: 'no_time' },
      { label: '📉 Results nahi dikhte', value: 'no_results' },
      { label: '🤕 Injury / Pain', value: 'injury' },
    ],
  },
  {
    id: 'q27',
    section: 'Psychology',
    title: 'Aap khud ko describe kaise karenge?',
    type: 'single',
    options: [
      { label: '🚀 Action taker', value: 'action_taker' },
      { label: '🤔 Overthinker but committed', value: 'overthinker' },
      { label: '🐌 Slow starter but consistent', value: 'slow_starter' },
      { label: '🎯 Need push & structure', value: 'need_push' },
    ],
  },
  {
    id: 'q28',
    section: 'Psychology',
    title: 'Aapki commitment level?',
    type: 'scale',
    scaleConfig: { min: 1, max: 10, labels: ['Dekhte hain', '100% committed'] },
  },
  // G. Conversion (Q29-31)
  {
    id: 'q29',
    section: 'Conversion',
    title: 'Kya aap aaj hi start karna chahte ho?',
    type: 'single',
    options: [
      { label: '🔥 Haan! Abhi start!', value: 'yes_now' },
      { label: '🤔 Soch ke bataunga', value: 'will_think' },
      { label: '📅 Kal se', value: 'tomorrow' },
      { label: '❌ Abhi nahi', value: 'not_now' },
    ],
  },
  {
    id: 'q30',
    section: 'Conversion',
    title: 'Kya aap WhatsApp reminders chahte ho?',
    type: 'single',
    options: [
      { label: '✅ Haan, zaroor!', value: 'yes_whatsapp' },
      { label: '❌ Nahi, rehne do', value: 'no_whatsapp' },
    ],
  },
  {
    id: 'q31',
    section: 'Conversion',
    title: 'Aapko full plan unlock karna hai?',
    subtitle: 'Custom workout + diet plan + daily tracking',
    type: 'single',
    options: [
      { label: '🔓 YES! Unlock full plan', value: 'unlock_full' },
      { label: '👀 Pehle free report dekhunga', value: 'free_report_first' },
    ],
  },
];

export function calculateBMI(height: number, weight: number): { bmi: number; category: string; color: string; targetWeight: number } {
  // Height in cm, weight in kg
  const heightM = height / 100;
  const bmi = weight / (heightM * heightM);

  let category: string;
  let color: string;
  let targetWeight: number;

  if (bmi < 18.5) {
    category = 'Underweight';
    color = 'text-blue-400';
    targetWeight = Math.round(18.5 * heightM * heightM * 10) / 10;
  } else if (bmi < 25) {
    category = 'Normal';
    color = 'text-lime-400';
    targetWeight = weight; // Already at good weight
  } else if (bmi < 30) {
    category = 'Overweight';
    color = 'text-orange-400';
    targetWeight = Math.round(24.9 * heightM * heightM * 10) / 10;
  } else {
    category = 'Obese';
    color = 'text-red-400';
    targetWeight = Math.round(24.9 * heightM * heightM * 10) / 10;
  }

  return { bmi: Math.round(bmi * 10) / 10, category, color, targetWeight };
}

export function calculateScores(answers: Record<string, string | string[] | number>): ScoringResult {
  // Calculate BMI first
  const height = Number(answers.q6) || 170;
  const weight = Number(answers.q7) || 75;
  const bmiResult = calculateBMI(height, weight);

  // Readiness Score (out of 100)
  let readiness = 50;
  if (answers.q29 === 'yes_now') readiness += 25;
  else if (answers.q29 === 'tomorrow') readiness += 15;
  else if (answers.q29 === 'will_think') readiness += 5;
  if (answers.q28 && typeof answers.q28 === 'number') readiness += Math.round((answers.q28 / 10) * 15);
  if (answers.q30 === 'yes_whatsapp') readiness += 10;
  readiness = Math.min(100, readiness);

  // Consistency Score (out of 100)
  let consistency = 40;
  if (answers.q26 === 'boredom') consistency += 5;
  else if (answers.q26 === 'no_time') consistency += 10;
  else if (answers.q26 === 'no_results') consistency += 15;
  else if (answers.q26 === 'injury') consistency += 20;
  if (answers.q27 === 'action_taker') consistency += 25;
  else if (answers.q27 === 'slow_starter') consistency += 20;
  else if (answers.q27 === 'overthinker') consistency += 10;
  else if (answers.q27 === 'need_push') consistency += 5;
  if (answers.q3 === 'just_starting') consistency += 5;
  else if (answers.q3 === '1_3_months') consistency += 15;
  else if (answers.q3 === '3_6_months') consistency += 20;
  else consistency += 25;
  consistency = Math.min(100, consistency);

  // Body Transformation Score (out of 100) - BMI influences this
  let bodyTransform = 50;
  if (answers.q1 === 'fat_loss') bodyTransform += 15;
  else if (answers.q1 === 'muscle_gain') bodyTransform += 20;
  else if (answers.q1 === 'skinny_fat') bodyTransform += 18;
  if (answers.q8 === 'chubby') bodyTransform += 10;
  else if (answers.q8 === 'skinny') bodyTransform += 12;
  else if (answers.q8 === 'average') bodyTransform += 8;
  if (answers.q11 === '90_days') bodyTransform += 15;
  else if (answers.q11 === '6_months') bodyTransform += 10;
  else if (answers.q11 === '30_days') bodyTransform += 5;
  // BMI influence: higher BMI away from normal = more transformation potential
  if (bmiResult.bmi > 30 || bmiResult.bmi < 18) bodyTransform += 5;
  bodyTransform = Math.min(100, bodyTransform);

  // Nutrition Compliance Score (out of 100)
  let nutrition = 40;
  if (answers.q20 === 'non_veg') nutrition += 15;
  else if (answers.q20 === 'eggetarian') nutrition += 12;
  else if (answers.q20 === 'veg') nutrition += 5;
  if (answers.q24 === '3_plus') nutrition += 15;
  else if (answers.q24 === '2_3l') nutrition += 10;
  else if (answers.q24 === '1_2l') nutrition += 5;
  if (answers.q22 === '4_meals' || answers.q22 === '5_plus') nutrition += 10;
  if (answers.q23 === 'portion_control') nutrition += 15;
  else if (answers.q23 === 'dont_know') nutrition += 5;
  else if (answers.q23 === 'no_time') nutrition += 8;
  nutrition = Math.min(100, nutrition);

  // Support Need Score (out of 100) - higher means more support needed
  let supportNeed = 50;
  if (answers.q2 === 'confused') supportNeed += 20;
  else if (answers.q2 === 'inconsistent') supportNeed += 15;
  if (answers.q27 === 'need_push') supportNeed += 15;
  else if (answers.q27 === 'overthinker') supportNeed += 10;
  if (answers.q17 && typeof answers.q17 === 'number' && answers.q17 <= 4) supportNeed += 10;
  if (answers.q18 && typeof answers.q18 === 'number' && answers.q18 >= 7) supportNeed += 10;
  supportNeed = Math.min(100, supportNeed);

  const overallScore = Math.round((readiness + consistency + bodyTransform + nutrition + (100 - supportNeed)) / 5);

  // Determine body type
  const bodyType = (answers.q8 as string) || 'average';
  const fitnessLevel = answers.q3 === 'just_starting' ? 'beginner' : answers.q3 === '1_3_months' ? 'novice' : 'intermediate';
  const goalCategory = (answers.q1 as string) || 'overall_fitness';

  // BMI-based recommendation enhancement
  const bmiAdvice = bmiResult.category === 'Underweight'
    ? `Aapka BMI ${bmiResult.bmi} hai (Underweight). Aapko healthy weight gain karna hai - target ${bmiResult.targetWeight}kg. `
    : bmiResult.category === 'Overweight'
    ? `Aapka BMI ${bmiResult.bmi} hai (Overweight). Aapko healthy fat loss karni hai - target ${bmiResult.targetWeight}kg. `
    : bmiResult.category === 'Obese'
    ? `Aapka BMI ${bmiResult.bmi} hai (Obese). Health ke liye weight loss zaroori hai - target ${bmiResult.targetWeight}kg. `
    : `Aapka BMI ${bmiResult.bmi} hai (Normal). Body composition improve karna hai - muscle gain aur fat loss dono. `;

  const recommendationMap: Record<string, string> = {
    fat_loss: bmiAdvice + 'Aapko calorie deficit + strength training chahiye. Cardio bhi important hai, par weights se body recomposition hoti hai.',
    muscle_gain: bmiAdvice + 'Aapko calorie surplus + progressive overload chahiye. Heavy compound lifts focus me rakhein.',
    skinny_fat: bmiAdvice + 'Aapko body recomposition chahiye — same time me fat loss aur muscle gain. Ye tricky hai par possible hai with right plan.',
    overall_fitness: bmiAdvice + 'Aapko balanced approach chahiye — strength, cardio, flexibility sab ek saath. Consistency is key.',
  };

  return {
    readinessScore: readiness,
    consistencyScore: consistency,
    bodyTransformationScore: bodyTransform,
    nutritionComplianceScore: nutrition,
    supportNeedScore: supportNeed,
    overallScore,
    bodyType,
    fitnessLevel,
    goalCategory,
    recommendation: recommendationMap[goalCategory] || recommendationMap.overall_fitness,
    bmi: bmiResult.bmi,
    bmiCategory: bmiResult.category,
    height,
    weight,
    targetWeight: bmiResult.targetWeight,
  };
}
