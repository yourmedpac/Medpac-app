'use client';

import { useStore } from '@/lib/store';
import { motion } from 'framer-motion';
import type { Language, ScreenName } from '@/lib/types';

const languages: { id: Language; name: string; native: string; flag: string }[] = [
  { id: 'hinglish', name: 'Hinglish', native: 'Default', flag: '🇮🇳' },
  { id: 'en', name: 'English', native: 'English', flag: '🇬🇧' },
  { id: 'hi', name: 'Hindi', native: 'हिंदी', flag: '🇮🇳' },
  { id: 'ta', name: 'Tamil', native: 'தமிழ்', flag: '🇮🇳' },
  { id: 'te', name: 'Telugu', native: 'తెలుగు', flag: '🇮🇳' },
];

export default function LanguageSelect() {
  const { language, setLanguage, navigate } = useStore();

  const handleSelect = (lang: Language) => {
    setLanguage(lang);
    setTimeout(() => navigate('auth' as ScreenName), 600);
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-sm text-center"
      >
        <div className="text-5xl mb-6">🌍</div>
        <h1 className="text-3xl font-extrabold text-white mb-2">Bhasha Chuniye</h1>
        <p className="text-zinc-400 mb-8">Choose your preferred language</p>

        <div className="space-y-3">
          {languages.map((lang, i) => (
            <motion.button
              key={lang.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              onClick={() => handleSelect(lang.id)}
              className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all duration-300 ${
                language === lang.id
                  ? 'bg-lime-400/10 border-lime-400'
                  : 'bg-zinc-900/80 border-white/5 hover:border-white/20'
              }`}
            >
              <span className="text-3xl">{lang.flag}</span>
              <div className="text-left flex-1">
                <p className={`font-semibold ${language === lang.id ? 'text-lime-400' : 'text-white'}`}>
                  {lang.name}
                </p>
                <p className="text-zinc-500 text-sm">{lang.native}</p>
              </div>
              {language === lang.id && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="w-6 h-6 rounded-full bg-lime-400 flex items-center justify-center"
                >
                  <span className="text-black text-xs font-bold">✓</span>
                </motion.div>
              )}
            </motion.button>
          ))}
        </div>

        <p className="text-zinc-600 text-xs mt-6">
          {language === 'hinglish' ? 'Default: Hinglish' : `Selected: ${language.toUpperCase()}`}
        </p>
      </motion.div>
    </div>
  );
}
