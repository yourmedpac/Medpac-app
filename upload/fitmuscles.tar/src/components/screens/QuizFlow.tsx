'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { quizQuestions, calculateScores, calculateBMI } from '@/lib/scoring';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import type { ScreenName } from '@/lib/types';

export default function QuizFlow() {
  const { quizStep, setQuizStep, quizAnswers, setQuizAnswer, navigate, setScoringResult, language } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const questions = quizQuestions;
  const currentQuestion = questions[quizStep];
  const totalSteps = questions.length;
  const progressPercent = ((quizStep + 1) / totalSteps) * 100;

  const handleSingleSelect = (value: string) => {
    setQuizAnswer(currentQuestion.id, value);
  };

  const handleMultiSelect = (value: string) => {
    const current = (quizAnswers[currentQuestion.id] as string[]) || [];
    if (current.includes(value)) {
      setQuizAnswer(currentQuestion.id, current.filter(v => v !== value));
    } else {
      setQuizAnswer(currentQuestion.id, [...current, value]);
    }
  };

  const handleNext = () => {
    if (quizStep < totalSteps - 1) {
      setQuizStep(quizStep + 1);
    } else {
      // Quiz complete - calculate scores
      const scores = calculateScores(quizAnswers);
      setScoringResult(scores);
      navigate('report' as ScreenName);
    }
  };

  const handleBack = () => {
    if (quizStep > 0) {
      setQuizStep(quizStep - 1);
    } else {
      navigate('auth' as ScreenName);
    }
  };

  const canProceed = () => {
    const answer = quizAnswers[currentQuestion.id];
    if (currentQuestion.type === 'multi') {
      return Array.isArray(answer) && answer.length > 0;
    }
    return answer !== undefined && answer !== '';
  };

  const renderOptions = () => {
    if (!currentQuestion.options) return null;

    if (currentQuestion.type === 'single') {
      return (
        <div className="space-y-3">
          {currentQuestion.options.map((option, i) => {
            const isSelected = quizAnswers[currentQuestion.id] === option.value;
            return (
              <motion.button
                key={option.value}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => handleSingleSelect(option.value)}
                className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all duration-200 ${
                  isSelected
                    ? 'bg-lime-400/10 border-lime-400'
                    : 'bg-zinc-900/80 border-white/5 hover:border-white/20'
                }`}
              >
                <span className="text-lg">{option.icon || option.label.split(' ')[0]}</span>
                <span className={`flex-1 text-left font-medium ${isSelected ? 'text-lime-400' : 'text-white'}`}>
                  {option.label}
                </span>
                {isSelected && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-6 h-6 rounded-full bg-lime-400 flex items-center justify-center"
                  >
                    <Check className="w-3.5 h-3.5 text-black" />
                  </motion.div>
                )}
              </motion.button>
            );
          })}
        </div>
      );
    }

    if (currentQuestion.type === 'multi') {
      return (
        <div className="space-y-3">
          {currentQuestion.options.map((option, i) => {
            const selected = (quizAnswers[currentQuestion.id] as string[]) || [];
            const isSelected = selected.includes(option.value);
            return (
              <motion.button
                key={option.value}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => handleMultiSelect(option.value)}
                className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all duration-200 ${
                  isSelected
                    ? 'bg-lime-400/10 border-lime-400'
                    : 'bg-zinc-900/80 border-white/5 hover:border-white/20'
                }`}
              >
                <span className="text-lg">{option.icon || option.label.split(' ')[0]}</span>
                <span className={`flex-1 text-left font-medium ${isSelected ? 'text-lime-400' : 'text-white'}`}>
                  {option.label}
                </span>
                {isSelected && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-6 h-6 rounded-full bg-lime-400 flex items-center justify-center"
                  >
                    <Check className="w-3.5 h-3.5 text-black" />
                  </motion.div>
                )}
              </motion.button>
            );
          })}
        </div>
      );
    }

    return null;
  };

  const renderSlider = () => {
    if (!currentQuestion.sliderConfig) return null;
    const config = currentQuestion.sliderConfig;
    const value = (quizAnswers[currentQuestion.id] as number) ?? config.defaultValue;

    // Calculate BMI if on height or weight question
    const height = currentQuestion.id === 'q6' ? value : (quizAnswers.q6 as number) ?? 170;
    const weight = currentQuestion.id === 'q7' ? value : (quizAnswers.q7 as number) ?? 75;
    const showBMI = currentQuestion.id === 'q6' || currentQuestion.id === 'q7';
    const bmiResult = showBMI ? calculateBMI(height, weight) : null;

    return (
      <div className="space-y-6">
        <div className="text-center">
          <span className="text-5xl font-extrabold text-lime-400 neon-text-glow">{value}</span>
          <span className="text-zinc-400 text-xl ml-2">{config.unit}</span>
        </div>
        <input
          type="range"
          min={config.min}
          max={config.max}
          step={config.step}
          value={value}
          onChange={(e) => setQuizAnswer(currentQuestion.id, Number(e.target.value))}
          className="w-full h-2 bg-zinc-800 rounded-full appearance-none cursor-pointer accent-lime-400"
        />
        <div className="flex justify-between text-zinc-500 text-sm">
          <span>{config.min} {config.unit}</span>
          <span>{config.max} {config.unit}</span>
        </div>
        {/* Live BMI Display */}
        {showBMI && bmiResult && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-zinc-900/80 rounded-xl p-4 border border-lime-400/20 text-center"
          >
            <p className="text-zinc-500 text-xs mb-1">Aapka BMI</p>
            <p className="text-3xl font-extrabold text-lime-400">{bmiResult.bmi}</p>
            <p className={`text-sm font-bold ${bmiResult.color} mt-1`}>{bmiResult.category}</p>
            <div className="flex justify-center gap-4 mt-2 text-zinc-500 text-xs">
              <span>Height: {height}cm</span>
              <span>Weight: {weight}kg</span>
            </div>
            {bmiResult.category !== 'Normal' && (
              <p className="text-zinc-400 text-xs mt-2">Healthy target: {bmiResult.targetWeight}kg</p>
            )}
          </motion.div>
        )}
      </div>
    );
  };

  const renderScale = () => {
    if (!currentQuestion.scaleConfig) return null;
    const config = currentQuestion.scaleConfig;
    const value = (quizAnswers[currentQuestion.id] as number) ?? Math.ceil((config.min + config.max) / 2);

    return (
      <div className="space-y-6">
        <div className="text-center">
          <span className="text-5xl font-extrabold text-lime-400 neon-text-glow">{value}</span>
          <span className="text-zinc-400 text-xl ml-1">/ {config.max}</span>
        </div>
        <div className="flex gap-2 justify-center flex-wrap">
          {Array.from({ length: config.max - config.min + 1 }, (_, i) => i + config.min).map((num) => (
            <button
              key={num}
              onClick={() => setQuizAnswer(currentQuestion.id, num)}
              className={`w-10 h-10 rounded-lg font-bold text-sm transition-all ${
                value === num
                  ? 'bg-lime-400 text-black'
                  : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'
              }`}
            >
              {num}
            </button>
          ))}
        </div>
        <div className="flex justify-between text-zinc-500 text-sm">
          <span>{config.labels[0]}</span>
          <span>{config.labels[1]}</span>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-black flex flex-col">
      {/* Progress Bar */}
      <div className="sticky top-0 z-10 bg-black/80 backdrop-blur-lg pt-3 pb-2 px-4">
        <div className="flex items-center justify-between mb-2">
          <button
            onClick={handleBack}
            className="text-zinc-400 hover:text-white p-1"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className="text-zinc-400 text-sm font-medium">
            Step {quizStep + 1} {t('stepOf', lang)} {totalSteps}
          </span>
          <div className="w-6" />
        </div>
        <Progress value={progressPercent} className="h-1.5 bg-zinc-800" />
        <p className="text-zinc-600 text-xs mt-1.5 text-center">{currentQuestion.section}</p>
      </div>

      {/* Question Content */}
      <div className="flex-1 px-6 py-6 max-w-md mx-auto w-full">
        <AnimatePresence mode="wait">
          <motion.div
            key={quizStep}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.25 }}
          >
            <h2 className="text-2xl font-bold text-white mb-2">{currentQuestion.title}</h2>
            {currentQuestion.subtitle && (
              <p className="text-zinc-400 mb-6">{currentQuestion.subtitle}</p>
            )}

            {!currentQuestion.subtitle && <div className="mb-6" />}

            {currentQuestion.type === 'slider' && renderSlider()}
            {currentQuestion.type === 'scale' && renderScale()}
            {(currentQuestion.type === 'single' || currentQuestion.type === 'multi') && renderOptions()}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Next Button */}
      <div className="sticky bottom-0 bg-black/80 backdrop-blur-lg px-6 py-4">
        <Button
          onClick={handleNext}
          disabled={!canProceed()}
          className={`w-full h-12 rounded-xl font-bold text-lg transition-all ${
            canProceed()
              ? 'bg-lime-400 hover:bg-lime-300 text-black neon-glow'
              : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
          }`}
        >
          {quizStep === totalSteps - 1 ? 'Get My Report' : t('next', lang)}
          <ChevronRight className="w-5 h-5 ml-1" />
        </Button>
      </div>
    </div>
  );
}
