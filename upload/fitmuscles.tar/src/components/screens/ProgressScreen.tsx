'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { TrendingDown, TrendingUp, Camera, Ruler, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';

export default function ProgressScreen() {
  const { progressEntries, language } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';

  const latestEntry = progressEntries[progressEntries.length - 1];
  const previousEntry = progressEntries[progressEntries.length - 2];
  const weightChange = latestEntry && previousEntry
    ? (latestEntry.weight - previousEntry.weight)
    : -1.2;

  const chartData = progressEntries.map((entry, i) => ({
    name: `W${i + 1}`,
    weight: entry.weight,
  }));

  const measurements = latestEntry ? [
    { label: 'Chest', value: latestEntry.chest, prev: previousEntry?.chest, unit: 'cm' },
    { label: 'Waist', value: latestEntry.waist, prev: previousEntry?.waist, unit: 'cm' },
    { label: 'Arms', value: latestEntry.arms, prev: previousEntry?.arms, unit: 'cm' },
    { label: 'Thighs', value: latestEntry.thighs, prev: previousEntry?.thighs, unit: 'cm' },
    { label: 'Shoulders', value: latestEntry.shoulders, prev: previousEntry?.shoulders, unit: 'cm' },
  ].filter(m => m.value != null) : [];

  return (
    <div className="min-h-screen bg-black pb-4">
      <div className="max-w-md mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="pt-2 pb-4"
        >
          <h1 className="text-2xl font-bold text-white">{t('progress', lang)}</h1>
          <p className="text-zinc-500 text-sm">{t('trackGains', lang)}</p>
        </motion.div>

        {/* Weight Card */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-4"
        >
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-zinc-500 text-xs">{t('weight', lang)}</p>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-white">{latestEntry?.weight ?? 82.5} kg</span>
                <span className={`text-sm font-bold flex items-center gap-0.5 ${
                  weightChange < 0 ? 'text-lime-400' : 'text-orange-400'
                }`}>
                  {weightChange < 0 ? <ArrowDownRight className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                  {Math.abs(weightChange)} kg
                </span>
              </div>
            </div>
          </div>
          <div className="h-32">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <XAxis
                  dataKey="name"
                  tick={{ fill: '#71717A', fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  domain={['dataMin - 2', 'dataMax + 2']}
                  hide
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1A1A1A',
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: 12,
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="weight"
                  stroke="#A3E635"
                  strokeWidth={2}
                  dot={{ fill: '#A3E635', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Physique Update */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-4"
        >
          <h3 className="text-white font-semibold mb-3">{t('physiqueUpdate', lang)}</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-zinc-800/50 rounded-xl p-6 text-center border border-dashed border-white/10 flex flex-col items-center justify-center min-h-[140px]">
              <Camera className="w-8 h-8 text-zinc-600 mb-2" />
              <p className="text-zinc-500 text-sm">{t('before', lang)}</p>
              <Button variant="ghost" className="text-lime-400 text-xs mt-2 h-6 hover:bg-lime-400/10">
                Upload
              </Button>
            </div>
            <div className="bg-zinc-800/50 rounded-xl p-6 text-center border border-dashed border-white/10 flex flex-col items-center justify-center min-h-[140px]">
              <Camera className="w-8 h-8 text-zinc-600 mb-2" />
              <p className="text-zinc-500 text-sm">{t('after', lang)}</p>
              <Button variant="ghost" className="text-lime-400 text-xs mt-2 h-6 hover:bg-lime-400/10">
                Upload
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Measurements */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-4"
        >
          <div className="flex items-center gap-2 mb-3">
            <Ruler className="w-4 h-4 text-lime-400" />
            <h3 className="text-white font-semibold">{t('measurements', lang)}</h3>
          </div>
          <div className="space-y-3">
            {measurements.map((m, i) => {
              const change = m.prev && m.value ? m.value - m.prev : 0;
              const isPositive = change > 0;
              const isGood = m.label === 'Waist' ? change < 0 : change > 0;
              return (
                <div key={i} className="flex items-center justify-between">
                  <span className="text-zinc-400 text-sm">{m.label}</span>
                  <div className="flex items-center gap-3">
                    {m.prev && (
                      <span className="text-zinc-600 text-xs">{m.prev} {m.unit}</span>
                    )}
                    <span className="text-white font-bold">{m.value} {m.unit}</span>
                    {change !== 0 && (
                      <span className={`text-xs font-semibold flex items-center ${
                        isGood ? 'text-lime-400' : 'text-orange-400'
                      }`}>
                        {isPositive ? (
                          <ArrowUpRight className="w-3 h-3" />
                        ) : (
                          <ArrowDownRight className="w-3 h-3" />
                        )}
                        {Math.abs(change).toFixed(0)}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
