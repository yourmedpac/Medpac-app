'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Lock, Eye, EyeOff, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import type { ScreenName, User } from '@/lib/types';

export default function AuthScreen() {
  const { navigate, language, setUser } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const [mode, setMode] = useState<'login' | 'signup'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleAuth = () => {
    if (!email || !password) return;
    const user: User = {
      id: 'user_' + Date.now(),
      email,
      name: email.split('@')[0],
      language: language as User['language'],
      createdAt: new Date().toISOString(),
    };
    setUser(user);
    navigate('quiz' as ScreenName);
  };

  const handleGoogleLogin = () => {
    const user: User = {
      id: 'user_google_' + Date.now(),
      email: 'user@gmail.com',
      name: 'FitMuscles User',
      language: language as User['language'],
      createdAt: new Date().toISOString(),
    };
    setUser(user);
    navigate('quiz' as ScreenName);
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-sm"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-lime-400 flex items-center justify-center mx-auto mb-4 neon-glow">
            <span className="text-black font-extrabold text-2xl">F</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white">
            {mode === 'login' ? t('welcomeBack', lang) : t('createAccount', lang)}
          </h1>
        </div>

        {/* Tabs */}
        <div className="flex bg-zinc-900 rounded-xl p-1 mb-6">
          <button
            onClick={() => setMode('signup')}
            className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${
              mode === 'signup' ? 'bg-lime-400 text-black' : 'text-zinc-400'
            }`}
          >
            {t('signUp', lang)}
          </button>
          <button
            onClick={() => setMode('login')}
            className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${
              mode === 'login' ? 'bg-lime-400 text-black' : 'text-zinc-400'
            }`}
          >
            {t('logIn', lang)}
          </button>
        </div>

        {/* Form */}
        <div className="space-y-4">
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" />
            <Input
              type="email"
              placeholder={t('email', lang)}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-zinc-900 border-white/10 pl-11 text-white placeholder:text-zinc-500 h-12 rounded-xl"
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" />
            <Input
              type={showPassword ? 'text' : 'password'}
              placeholder={t('password', lang)}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-zinc-900 border-white/10 pl-11 pr-11 text-white placeholder:text-zinc-500 h-12 rounded-xl"
            />
            <button
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
            >
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>

          <Button
            onClick={handleAuth}
            className="w-full bg-lime-400 hover:bg-lime-300 text-black font-bold h-12 rounded-xl"
          >
            {mode === 'signup' ? t('signUp', lang) : t('logIn', lang)}
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-3 my-6">
          <div className="flex-1 h-px bg-white/10" />
          <span className="text-zinc-500 text-xs">{t('orContinueWith', lang)}</span>
          <div className="flex-1 h-px bg-white/10" />
        </div>

        {/* Google Login */}
        <Button
          onClick={handleGoogleLogin}
          variant="outline"
          className="w-full bg-zinc-900 border-white/10 text-white hover:bg-zinc-800 h-12 rounded-xl"
        >
          <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" />
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
          </svg>
          Google
        </Button>

        {/* OTP */}
        <Button
          onClick={handleAuth}
          variant="ghost"
          className="w-full text-zinc-400 hover:text-white mt-3"
        >
          {t('sendOtp', lang)}
        </Button>

        <p className="text-zinc-600 text-xs text-center mt-6">
          By continuing, you agree to our Terms & Privacy Policy
        </p>
      </motion.div>
    </div>
  );
}
