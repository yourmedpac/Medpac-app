'use client';

import { useState } from 'react';
import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { Check, Shield, Lock, Sparkles, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { ScreenName, Subscription } from '@/lib/types';

const plans = [
  {
    id: 'monthly' as const,
    name: 'Monthly',
    price: 499,
    perMonth: 499,
    billed: 499,
    period: 'mo',
    features: ['AI-Personalized Workout Plan', 'AI-Generated Indian Diet Chart', 'Daily AI Check-ins & Insights', 'Progress Tracking'],
    popular: false,
  },
  {
    id: 'quarterly' as const,
    name: 'Quarterly',
    price: 399,
    perMonth: 399,
    billed: 1197,
    period: 'mo',
    features: ['Everything in Monthly', 'AI Progress Reports', 'WhatsApp Reminders', 'Priority Support', 'AI Meal Swaps'],
    popular: true,
  },
  {
    id: 'yearly' as const,
    name: 'Yearly',
    price: 249,
    perMonth: 249,
    billed: 2988,
    period: 'mo',
    features: ['Everything in Quarterly', '1-on-1 Coach Calls', 'Custom AI Meal Plans', 'Video Form Checks', 'Lifetime Community Access', 'Family Discount'],
    popular: false,
  },
];

export default function PaywallScreen() {
  const { navigate, language, setSubscription, quizAnswers, scoringResult } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const [selected, setSelected] = useState<'monthly' | 'quarterly' | 'yearly'>('quarterly');
  const [isSubscribing, setIsSubscribing] = useState(false);

  const handleSubscribe = async () => {
    setIsSubscribing(true);
    const plan = plans.find(p => p.id === selected)!;
    const sub: Subscription = {
      id: 'sub_' + Date.now(),
      plan: selected,
      status: 'active',
      startDate: new Date().toISOString(),
      endDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(),
      amount: plan.billed,
    };
    setSubscription(sub);
    navigate('dashboard' as ScreenName);
  };

  const handleContinueFree = () => {
    setSubscription({
      id: 'free',
      plan: 'free',
      status: 'active',
      startDate: new Date().toISOString(),
      endDate: '',
      amount: 0,
    });
    navigate('dashboard' as ScreenName);
  };

  return (
    <div className="min-h-screen bg-black px-6 py-6">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-6"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-lime-400/10 border border-lime-400/30 mb-4">
            <Sparkles className="w-3.5 h-3.5 text-lime-400" />
            <span className="text-lime-400 text-xs font-semibold">AI-Powered Personalization</span>
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">{t('whatYouGet', lang)}</h1>
          <div className="space-y-2 mt-4">
            {[
              'AI-Personalized Workout & Diet Plan',
              '90-Day AI Transformation Roadmap',
              'Daily AI Coach Insights & Check-ins',
              'WhatsApp Reminders & Support',
              'AI-Powered Meal Swaps & Adjustments',
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-5 h-5 rounded-full bg-lime-400/20 flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-3 h-3 text-lime-400" />
                </div>
                <span className="text-zinc-300 text-sm text-left">{item}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Plans */}
        <div className="space-y-3 mb-6">
          {plans.map((plan, i) => (
            <motion.button
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              onClick={() => setSelected(plan.id)}
              className={`w-full p-4 rounded-xl border-2 text-left transition-all relative ${
                selected === plan.id
                  ? 'bg-lime-400/5 border-lime-400'
                  : 'bg-zinc-900/80 border-white/5'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-lime-400 text-black text-xs font-bold px-3 py-1 rounded-full">
                    {t('mostPopular', lang)}
                  </span>
                </div>
              )}
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h3 className={`font-bold ${selected === plan.id ? 'text-lime-400' : 'text-white'}`}>
                    {plan.name}
                  </h3>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-extrabold text-white">₹{plan.price}</span>
                    <span className="text-zinc-500 text-sm">{t('perMonth', lang)}</span>
                  </div>
                  <p className="text-zinc-500 text-xs mt-0.5">{t('billed', lang)} ₹{plan.billed}</p>
                </div>
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                  selected === plan.id ? 'border-lime-400 bg-lime-400' : 'border-zinc-600'
                }`}>
                  {selected === plan.id && <Check className="w-4 h-4 text-black" />}
                </div>
              </div>
              <div className="space-y-1.5 mt-3">
                {plan.features.map((feat, j) => (
                  <div key={j} className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-lime-400 flex-shrink-0" />
                    <span className="text-zinc-400 text-xs">{feat}</span>
                  </div>
                ))}
              </div>
            </motion.button>
          ))}
        </div>

        {/* CTA */}
        <Button
          onClick={handleSubscribe}
          disabled={isSubscribing}
          className="w-full bg-lime-400 hover:bg-lime-300 text-black font-bold h-12 rounded-xl neon-glow text-lg mb-3"
        >
          {isSubscribing ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Setting up AI plan...
            </>
          ) : (
            t('subscribe', lang)
          )}
        </Button>

        <button
          onClick={handleContinueFree}
          className="w-full text-center text-zinc-500 text-sm hover:text-zinc-300 py-2"
        >
          {t('continueFree', lang)}
        </button>

        {/* Trust badges */}
        <div className="flex items-center justify-center gap-6 mt-6">
          <div className="flex items-center gap-2 text-zinc-500">
            <Lock className="w-4 h-4" />
            <span className="text-xs">{t('securePayment', lang)}</span>
          </div>
          <div className="flex items-center gap-2 text-zinc-500">
            <Shield className="w-4 h-4" />
            <span className="text-xs">{t('cancelAnytime', lang)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
