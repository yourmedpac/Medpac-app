'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { Crown, Check, Calendar, CreditCard, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { ScreenName } from '@/lib/types';

export default function SubscriptionScreen() {
  const { navigate, language, subscription, setSubscription } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';

  const currentPlan = subscription?.plan ?? 'free';
  const planDetails: Record<string, { name: string; price: string; features: string[] }> = {
    free: {
      name: 'Free Plan',
      price: '₹0',
      features: ['Basic workout plan', 'Sample diet chart', 'Limited check-ins'],
    },
    monthly: {
      name: 'Monthly Plan',
      price: '₹499/mo',
      features: ['Personalized workout', 'Indian diet chart', 'Daily check-ins', 'Progress tracking'],
    },
    quarterly: {
      name: 'Quarterly Plan',
      price: '₹399/mo',
      features: ['Everything in Monthly', 'AI progress reports', 'WhatsApp reminders', 'Priority support'],
    },
    yearly: {
      name: 'Yearly Plan',
      price: '₹249/mo',
      features: ['Everything in Quarterly', '1-on-1 coach calls', 'Custom meal plans', 'Video form checks'],
    },
  };

  const details = planDetails[currentPlan] || planDetails.free;

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-md mx-auto px-6 py-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center">
              <Crown className="w-6 h-6 text-lime-400" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">{details.name}</h1>
              <p className="text-lime-400 font-semibold">{details.price}</p>
            </div>
          </div>

          {/* Status */}
          <div className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-zinc-400 text-sm">Status</span>
              <span className="text-lime-400 font-semibold text-sm flex items-center gap-1">
                <Check className="w-4 h-4" /> Active
              </span>
            </div>
            {subscription?.endDate && (
              <div className="flex items-center justify-between">
                <span className="text-zinc-400 text-sm">Renewal</span>
                <span className="text-white text-sm">{new Date(subscription.endDate).toLocaleDateString()}</span>
              </div>
            )}
          </div>

          {/* Features */}
          <div className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-4">
            <h3 className="text-white font-semibold mb-3">Plan Features</h3>
            <div className="space-y-2">
              {details.features.map((feat, i) => (
                <div key={i} className="flex items-center gap-3">
                  <Check className="w-4 h-4 text-lime-400 flex-shrink-0" />
                  <span className="text-zinc-300 text-sm">{feat}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Payment History */}
          <div className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-6">
            <h3 className="text-white font-semibold mb-3">Payment History</h3>
            <div className="space-y-2">
              {subscription?.amount ? (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-zinc-500" />
                    <span className="text-zinc-300 text-sm">Plan purchase</span>
                  </div>
                  <span className="text-white text-sm font-semibold">₹{subscription.amount}</span>
                </div>
              ) : (
                <p className="text-zinc-500 text-sm">No payment history</p>
              )}
            </div>
          </div>

          {/* Actions */}
          {currentPlan === 'free' ? (
            <Button
              onClick={() => navigate('paywall' as ScreenName)}
              className="w-full bg-lime-400 hover:bg-lime-300 text-black font-bold h-12 rounded-xl neon-glow"
            >
              <Crown className="w-4 h-4 mr-2" />
              Upgrade Plan
            </Button>
          ) : (
            <div className="space-y-3">
              <Button
                onClick={() => navigate('paywall' as ScreenName)}
                className="w-full bg-lime-400 hover:bg-lime-300 text-black font-bold h-12 rounded-xl"
              >
                Change Plan
              </Button>
              <Button
                variant="ghost"
                className="w-full text-red-400 hover:text-red-300 hover:bg-red-400/10 h-10"
                onClick={() => {
                  setSubscription({
                    id: 'free',
                    plan: 'free',
                    status: 'active',
                    startDate: new Date().toISOString(),
                    endDate: '',
                    amount: 0,
                  });
                }}
              >
                Cancel Subscription
              </Button>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
