'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { Flame, Play, Camera, CheckCircle2, UtensilsCrossed, TrendingUp, Sparkles, Loader2, Brain, Lightbulb, Dumbbell, Apple, Scale } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useEffect, useState } from 'react';
import type { ScreenName } from '@/lib/types';
import type { AIDailyInsight } from '@/lib/ai';

export default function Dashboard() {
  const {
    navigate, language, streak, subscription, workoutPlan, mealPlan,
    quizAnswers, scoringResult, checkIns, dailyInsight, setDailyInsight,
    isGeneratingInsight, setGeneratingInsight
  } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const [insight, setInsight] = useState<AIDailyInsight | null>(dailyInsight);

  const currentDay = workoutPlan?.currentDay ?? 1;
  const planName = workoutPlan?.days?.[Math.min(currentDay - 1, (workoutPlan?.days?.length || 1) - 1)]?.title ?? 'Today\'s Workout';

  // Get next meal based on current time
  const getNextMeal = () => {
    if (!mealPlan?.meals?.length) return null;
    const hour = new Date().getHours();
    const mealsByTime = [...mealPlan.meals].sort((a, b) => {
      const timeA = parseInt(a.time.split(':')[0]);
      const timeB = parseInt(b.time.split(':')[0]);
      return timeA - timeB;
    });
    // Find next upcoming meal
    const nextMeal = mealsByTime.find(m => {
      const mealHour = parseInt(m.time.split(':')[0]);
      return mealHour > hour;
    });
    return nextMeal || mealsByTime[0]; // Default to breakfast if all passed
  };

  const nextMeal = getNextMeal();

  // Calculate weekly workout progress from check-ins
  const thisWeekCheckIns = checkIns.filter(c => {
    const d = new Date(c.date);
    const now = new Date();
    const weekAgo = new Date(now);
    weekAgo.setDate(weekAgo.getDate() - 7);
    return d >= weekAgo;
  });
  const workoutsThisWeek = thisWeekCheckIns.filter(c => c.workoutDone).length;
  const totalWorkoutsTarget = workoutPlan?.daysPerWeek || 3;
  const weeklyProgress = totalWorkoutsTarget > 0 ? Math.round((workoutsThisWeek / totalWorkoutsTarget) * 100) : 0;

  // Fetch AI daily insight on mount
  useEffect(() => {
    if (dailyInsight) {
      setInsight(dailyInsight);
      return;
    }
    if (!quizAnswers || Object.keys(quizAnswers).length === 0) return;

    const fetchInsight = async () => {
      setGeneratingInsight(true);
      try {
        const res = await fetch('/api/daily-insight', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            answers: quizAnswers,
            scores: scoringResult,
            streak,
            recentCheckIns: checkIns.slice(-7),
          }),
        });
        const data = await res.json();
        if (data.success && data.insight) {
          setInsight(data.insight);
          setDailyInsight(data.insight);
        }
      } catch (err) {
        console.error('Failed to fetch daily insight:', err);
      } finally {
        setGeneratingInsight(false);
      }
    };

    fetchInsight();
  }, [quizAnswers, streak]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="min-h-screen bg-black pb-4">
      <div className="max-w-md mx-auto px-4">
        {/* AI Daily Insight - Personalized Greeting */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="pt-2 pb-4"
        >
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-3.5 h-3.5 text-lime-400" />
            <p className="text-lime-400 text-xs font-semibold tracking-wider">{t('todayFocus', lang)}</p>
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">
            {isGeneratingInsight ? 'Loading your day...' : insight?.greeting || t('keepGoing', lang)}
          </h1>

          {/* Streak Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-orange-500/10 border border-orange-500/30">
            <Flame className="w-5 h-5 text-orange-400" />
            <span className="text-orange-400 font-bold">{streak} {t('dayStreak', lang)}</span>
            {streak > 0 && <span className="text-orange-400/60 text-sm">🔥</span>}
          </div>
        </motion.div>

        {/* AI Coaching Tip */}
        {!isGeneratingInsight && insight && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="bg-lime-400/5 rounded-xl p-4 border border-lime-400/20 mb-3"
          >
            <div className="flex items-start gap-3">
              <Brain className="w-5 h-5 text-lime-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-lime-400 text-xs font-semibold mb-1">AI Coach</p>
                <p className="text-zinc-300 text-sm">{insight.focus}</p>
                <p className="text-zinc-400 text-xs mt-1 italic">"{insight.motivation}"</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* BMI Quick Stats */}
        {scoringResult && scoringResult.bmi && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.08 }}
            className="bg-zinc-900/80 rounded-xl p-3 border border-white/5 mb-3"
          >
            <div className="flex items-center gap-2 mb-2">
              <Scale className="w-3.5 h-3.5 text-lime-400" />
              <span className="text-zinc-500 text-xs font-medium">Your Body Stats</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="text-center flex-1">
                <p className="text-xl font-bold text-white">{scoringResult.weight}<span className="text-zinc-500 text-xs ml-0.5">kg</span></p>
                <p className="text-zinc-600 text-[10px]">Weight</p>
              </div>
              <div className="w-px h-8 bg-white/5" />
              <div className="text-center flex-1">
                <p className="text-xl font-bold text-lime-400">{scoringResult.bmi}</p>
                <p className={`text-[10px] font-medium ${
                  scoringResult.bmiCategory === 'Normal' ? 'text-lime-400' :
                  scoringResult.bmiCategory === 'Overweight' ? 'text-orange-400' :
                  scoringResult.bmiCategory === 'Obese' ? 'text-red-400' :
                  'text-blue-400'
                }`}>{scoringResult.bmiCategory}</p>
              </div>
              <div className="w-px h-8 bg-white/5" />
              <div className="text-center flex-1">
                <p className="text-xl font-bold text-lime-400">{scoringResult.targetWeight}<span className="text-zinc-500 text-xs ml-0.5">kg</span></p>
                <p className="text-zinc-600 text-[10px]">Target</p>
              </div>
              <div className="w-px h-8 bg-white/5" />
              <div className="text-center flex-1">
                <p className="text-xl font-bold text-white">{scoringResult.height}<span className="text-zinc-500 text-xs ml-0.5">cm</span></p>
                <p className="text-zinc-600 text-[10px]">Height</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Loading state for insight */}
        {isGeneratingInsight && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-3 flex items-center gap-3"
          >
            <Loader2 className="w-5 h-5 text-lime-400 animate-spin" />
            <div>
              <p className="text-lime-400 text-xs font-semibold">AI analyzing your profile...</p>
              <p className="text-zinc-500 text-xs">Personalizing today&apos;s plan</p>
            </div>
          </motion.div>
        )}

        {/* Workout Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-3"
        >
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-zinc-500 text-xs">Day {currentDay} {t('dayOf90', lang)}</p>
              <h3 className="text-white font-bold text-lg">{planName}</h3>
            </div>
            <Button
              onClick={() => navigate('workout' as ScreenName)}
              className="bg-lime-400 hover:bg-lime-300 text-black font-bold rounded-xl px-4"
              size="sm"
            >
              <Play className="w-4 h-4 mr-1 fill-current" />
              Play
            </Button>
          </div>
          <Progress value={(currentDay / 90) * 100} className="h-1.5 bg-zinc-800" />
          {/* AI Workout Tip */}
          {insight?.workoutTip && (
            <div className="flex items-center gap-2 mt-2">
              <Dumbbell className="w-3 h-3 text-lime-400/60" />
              <p className="text-zinc-500 text-xs">{insight.workoutTip}</p>
            </div>
          )}
        </motion.div>

        {/* Two Column Cards */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-zinc-900/80 rounded-xl p-4 border border-white/5"
          >
            <div className="flex items-center gap-2 mb-2">
              <UtensilsCrossed className="w-4 h-4 text-lime-400" />
              <span className="text-zinc-500 text-xs">{nextMeal ? 'Next Meal' : 'Meal'}</span>
            </div>
            <p className="text-white font-semibold text-sm mb-1">
              {nextMeal?.name || (mealPlan?.meals?.[0]?.name ?? 'Loading...')}
            </p>
            {nextMeal && (
              <p className="text-zinc-500 text-xs">{nextMeal.time} • {nextMeal.totalCalories} kcal</p>
            )}
            <Button
              onClick={() => navigate('meals' as ScreenName)}
              variant="ghost"
              className="text-lime-400 text-xs p-0 h-auto hover:bg-transparent mt-1"
            >
              + Log Meal
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.25 }}
            className="bg-zinc-900/80 rounded-xl p-4 border border-white/5"
          >
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-lime-400" />
              <span className="text-zinc-500 text-xs">{t('weeklyGoal', lang)}</span>
            </div>
            <p className="text-white font-bold text-lg">{weeklyProgress}%</p>
            <Progress value={weeklyProgress} className="h-1.5 bg-zinc-800 mt-2" />
            <p className="text-zinc-500 text-xs mt-1">{workoutsThisWeek}/{totalWorkoutsTarget} {t('workouts', lang)}</p>
          </motion.div>
        </div>

        {/* Nutrition Tip Card */}
        {insight?.nutritionTip && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-zinc-900/80 rounded-xl p-3 border border-white/5 mb-4 flex items-start gap-3"
          >
            <Apple className="w-4 h-4 text-orange-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-zinc-400 text-xs font-medium mb-0.5">Nutrition Tip</p>
              <p className="text-zinc-300 text-xs">{insight.nutritionTip}</p>
            </div>
          </motion.div>
        )}

        {/* Mindset Tip */}
        {insight?.mindsetTip && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className="bg-zinc-900/80 rounded-xl p-3 border border-white/5 mb-4 flex items-start gap-3"
          >
            <Lightbulb className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-zinc-400 text-xs font-medium mb-0.5">Mindset</p>
              <p className="text-zinc-300 text-xs">{insight.mindsetTip}</p>
            </div>
          </motion.div>
        )}

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="grid grid-cols-2 gap-3"
        >
          <Button
            onClick={() => navigate('workout' as ScreenName)}
            className="bg-zinc-900 hover:bg-zinc-800 text-white font-medium h-14 rounded-xl border border-white/5 justify-start px-4"
          >
            <Play className="w-5 h-5 text-lime-400 mr-3" />
            {t('startWorkout', lang)}
          </Button>
          <Button
            onClick={() => navigate('meals' as ScreenName)}
            className="bg-zinc-900 hover:bg-zinc-800 text-white font-medium h-14 rounded-xl border border-white/5 justify-start px-4"
          >
            <UtensilsCrossed className="w-5 h-5 text-lime-400 mr-3" />
            {t('logMeal', lang)}
          </Button>
          <Button
            onClick={() => navigate('progress' as ScreenName)}
            className="bg-zinc-900 hover:bg-zinc-800 text-white font-medium h-14 rounded-xl border border-white/5 justify-start px-4"
          >
            <Camera className="w-5 h-5 text-lime-400 mr-3" />
            {t('uploadPhoto', lang)}
          </Button>
          <Button
            onClick={() => navigate('checkin' as ScreenName)}
            className="bg-zinc-900 hover:bg-zinc-800 text-white font-medium h-14 rounded-xl border border-white/5 justify-start px-4"
          >
            <CheckCircle2 className="w-5 h-5 text-lime-400 mr-3" />
            {t('completeCheckin', lang)}
          </Button>
        </motion.div>

        {/* Subscription Badge */}
        {subscription && subscription.plan !== 'free' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-4 bg-lime-400/5 rounded-xl p-3 border border-lime-400/20 flex items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-lime-400" />
              <span className="text-lime-400 text-sm font-medium">{subscription.plan.charAt(0).toUpperCase() + subscription.plan.slice(1)} Plan</span>
            </div>
            <button
              onClick={() => navigate('subscription' as ScreenName)}
              className="text-zinc-500 text-xs hover:text-white"
            >
              Manage →
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
