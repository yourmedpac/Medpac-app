'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { ChevronDown, ChevronUp, Globe, Star, Users, Award, Flame, Check } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import type { ScreenName, Language } from '@/lib/types';

export default function LandingPage() {
  const { navigate, language, setLanguage } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const faqs = [
    { q: t('faq1', lang), a: t('faq1Ans', lang) },
    { q: t('faq2', lang), a: t('faq2Ans', lang) },
    { q: t('faq3', lang), a: t('faq3Ans', lang) },
    { q: t('faq4', lang), a: t('faq4Ans', lang) },
  ];

  const features = [
    { icon: '🍛', title: t('desiDiet', lang), desc: t('desiDietDesc', lang) },
    { icon: '🏋️', title: t('customWorkout', lang), desc: t('customWorkoutDesc', lang) },
    { icon: '💬', title: t('support247', lang), desc: t('support247Desc', lang) },
  ];

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-lime-400 flex items-center justify-center">
            <span className="text-black font-bold text-sm">F</span>
          </div>
          <span className="text-white font-bold text-lg">FitMuscles</span>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="text-zinc-400 hover:text-white"
          onClick={() => navigate('language' as ScreenName)}
        >
          <Globe className="w-5 h-5" />
        </Button>
      </div>

      {/* Hero Section */}
      <section className="relative px-6 pt-12 pb-8 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-lime-400/10 rounded-full blur-3xl" />
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="relative text-center"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-lime-400/10 border border-lime-400/30 mb-6">
            <Flame className="w-4 h-4 text-lime-400" />
            <span className="text-lime-400 text-sm font-semibold">{t('newBatch', lang)}</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-white leading-tight mb-4">
            {t('heroTitle', lang)}
          </h1>
          <p className="text-zinc-400 text-base mb-8 max-w-sm mx-auto">
            {t('heroSubtitle', lang)}
          </p>
          <Button
            onClick={() => navigate('language' as ScreenName)}
            className="bg-lime-400 hover:bg-lime-300 text-black font-bold text-lg px-8 py-6 rounded-xl neon-glow transition-all duration-300 hover:scale-105"
            size="lg"
          >
            {t('startTransformation', lang)}
          </Button>
        </motion.div>
      </section>

      {/* Social Proof */}
      <section className="px-6 py-6">
        <div className="grid grid-cols-2 gap-3">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 text-center"
          >
            <Users className="w-6 h-6 text-lime-400 mx-auto mb-2" />
            <p className="text-2xl font-extrabold text-white">10k+</p>
            <p className="text-zinc-400 text-sm">{t('activeMembers', lang)}</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 text-center"
          >
            <Award className="w-6 h-6 text-lime-400 mx-auto mb-2" />
            <p className="text-2xl font-extrabold text-white">50+</p>
            <p className="text-zinc-400 text-sm">{t('certifiedTrainers', lang)}</p>
          </motion.div>
        </div>
      </section>

      {/* Avg Stat */}
      <section className="px-6 py-4">
        <div className="bg-gradient-to-r from-lime-400/10 to-lime-400/5 rounded-xl p-4 border border-lime-400/20 text-center">
          <p className="text-lime-400 text-sm font-semibold mb-1">🔥 {t('avgFatLoss', lang)}</p>
          <p className="text-zinc-400 text-xs">Based on active member data</p>
        </div>
      </section>

      {/* Why FitMuscles */}
      <section className="px-6 py-8">
        <h2 className="text-2xl font-bold text-white text-center mb-6">{t('whyFitmuscles', lang)}</h2>
        <div className="space-y-3">
          {features.map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + i * 0.1 }}
              className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 flex items-start gap-4"
            >
              <span className="text-3xl">{feature.icon}</span>
              <div>
                <h3 className="text-white font-semibold mb-1">{feature.title}</h3>
                <p className="text-zinc-400 text-sm">{feature.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* What You Get */}
      <section className="px-6 py-8 bg-zinc-950">
        <h2 className="text-2xl font-bold text-white text-center mb-6">What You Get</h2>
        <div className="space-y-3">
          {[
            'Personalized Workout Plan',
            'Indian Diet Chart (Veg/Non-Veg)',
            'Daily Check-in & Tracking',
            'Progress Reports with AI',
            'WhatsApp Reminders',
            'Community Support',
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className="w-5 h-5 rounded-full bg-lime-400/20 flex items-center justify-center flex-shrink-0">
                <Check className="w-3 h-3 text-lime-400" />
              </div>
              <span className="text-zinc-300 text-sm">{item}</span>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="px-6 py-8">
        <h2 className="text-2xl font-bold text-white text-center mb-6">{t('faqTitle', lang)}</h2>
        <div className="space-y-2">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="bg-zinc-900/80 rounded-xl border border-white/5 overflow-hidden"
            >
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                className="w-full flex items-center justify-between p-4 text-left"
              >
                <span className="text-white text-sm font-medium pr-4">{faq.q}</span>
                {openFaq === i ? (
                  <ChevronUp className="w-4 h-4 text-zinc-400 flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-zinc-400 flex-shrink-0" />
                )}
              </button>
              {openFaq === i && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="px-4 pb-4"
                >
                  <p className="text-zinc-400 text-sm">{faq.a}</p>
                </motion.div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* CTA Footer */}
      <section className="px-6 py-8 text-center">
        <Button
          onClick={() => navigate('language' as ScreenName)}
          className="bg-lime-400 hover:bg-lime-300 text-black font-bold text-lg px-8 py-6 rounded-xl neon-glow w-full"
          size="lg"
        >
          {t('startTransformation', lang)}
        </Button>
        <p className="text-zinc-500 text-xs mt-4">No credit card required • Start in 2 minutes</p>
      </section>

      {/* Footer */}
      <footer className="px-6 py-8 border-t border-white/5 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="w-6 h-6 rounded bg-lime-400 flex items-center justify-center">
            <span className="text-black font-bold text-xs">F</span>
          </div>
          <span className="text-zinc-400 text-sm font-semibold">FitMuscles</span>
        </div>
        <p className="text-zinc-500 text-xs">India&apos;s #1 AI Fitness Transformation Platform</p>
        <p className="text-zinc-600 text-xs mt-2">© 2024 FitMuscles. All rights reserved.</p>
      </footer>
    </div>
  );
}
