'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { useState } from 'react';
import {
  Users, FileText, BarChart3, Bell, Languages, CreditCard,
  ChevronLeft, Search, MoreVertical
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, LineChart, Line } from 'recharts';

type AdminTab = 'users' | 'plans' | 'analytics' | 'notifications' | 'translations' | 'subscriptions';

const tabs: { id: AdminTab; icon: typeof Users; label: string }[] = [
  { id: 'users', icon: Users, label: 'Users' },
  { id: 'plans', icon: FileText, label: 'Plans' },
  { id: 'analytics', icon: BarChart3, label: 'Analytics' },
  { id: 'notifications', icon: Bell, label: 'Notify' },
  { id: 'translations', icon: Languages, label: 'i18n' },
  { id: 'subscriptions', icon: CreditCard, label: 'Subs' },
];

const mockUsers = [
  { id: '1', name: 'Rahul Sharma', email: 'rahul@email.com', plan: 'Quarterly', status: 'Active', joined: '2024-01-10' },
  { id: '2', name: 'Priya Patel', email: 'priya@email.com', plan: 'Yearly', status: 'Active', joined: '2024-01-12' },
  { id: '3', name: 'Amit Kumar', email: 'amit@email.com', plan: 'Monthly', status: 'Active', joined: '2024-01-15' },
  { id: '4', name: 'Sneha Reddy', email: 'sneha@email.com', plan: 'Free', status: 'Churned', joined: '2024-01-18' },
  { id: '5', name: 'Vikram Singh', email: 'vikram@email.com', plan: 'Quarterly', status: 'Active', joined: '2024-01-20' },
];

const analyticsData = [
  { month: 'Jan', signups: 120, revenue: 45000 },
  { month: 'Feb', signups: 180, revenue: 62000 },
  { month: 'Mar', signups: 240, revenue: 89000 },
  { month: 'Apr', signups: 310, revenue: 125000 },
  { month: 'May', signups: 420, revenue: 178000 },
  { month: 'Jun', signups: 580, revenue: 245000 },
];

export default function AdminPanel() {
  const { navigate, language } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const [activeTab, setActiveTab] = useState<AdminTab>('analytics');
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-white/5">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('profile' as Parameters<typeof navigate>[0])}
            className="text-white hover:bg-white/10"
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-bold text-white">Admin Panel</h1>
        </div>

        {/* Tab Navigation */}
        <div className="flex overflow-x-auto gap-1 px-4 py-3 border-b border-white/5">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-lime-400 text-black'
                  : 'bg-zinc-900 text-zinc-400 hover:text-white'
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="px-4 py-4">
          {activeTab === 'analytics' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                {[
                  { label: 'Total Users', value: '1,842', change: '+12%' },
                  { label: 'Active Subs', value: '1,024', change: '+8%' },
                  { label: 'Revenue (MTD)', value: '₹2.4L', change: '+23%' },
                  { label: 'Churn Rate', value: '4.2%', change: '-1.1%' },
                ].map((stat, i) => (
                  <div key={i} className="bg-zinc-900/80 rounded-xl p-3 border border-white/5">
                    <p className="text-zinc-500 text-xs">{stat.label}</p>
                    <p className="text-white font-bold text-lg">{stat.value}</p>
                    <span className={`text-xs font-medium ${stat.change.startsWith('+') ? 'text-lime-400' : 'text-red-400'}`}>
                      {stat.change}
                    </span>
                  </div>
                ))}
              </div>

              {/* Chart */}
              <div className="bg-zinc-900/80 rounded-xl p-4 border border-white/5">
                <h3 className="text-white font-semibold text-sm mb-3">Revenue Trend</h3>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analyticsData}>
                      <XAxis dataKey="month" tick={{ fill: '#71717A', fontSize: 10 }} axisLine={false} tickLine={false} />
                      <YAxis hide />
                      <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', color: '#fff', fontSize: 12 }} />
                      <Bar dataKey="revenue" fill="#A3E635" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Signups Chart */}
              <div className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mt-3">
                <h3 className="text-white font-semibold text-sm mb-3">User Signups</h3>
                <div className="h-32">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={analyticsData}>
                      <XAxis dataKey="month" tick={{ fill: '#71717A', fontSize: 10 }} axisLine={false} tickLine={false} />
                      <YAxis hide />
                      <Line type="monotone" dataKey="signups" stroke="#A3E635" strokeWidth={2} dot={{ fill: '#A3E635', r: 3 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'users' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="mb-3">
                <Input
                  placeholder="Search users..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-zinc-900 border-white/10 text-white placeholder:text-zinc-500 h-10"
                />
              </div>
              <div className="space-y-2">
                {mockUsers
                  .filter(u => u.name.toLowerCase().includes(searchQuery.toLowerCase()) || u.email.toLowerCase().includes(searchQuery.toLowerCase()))
                  .map((user) => (
                  <div key={user.id} className="bg-zinc-900/80 rounded-xl p-3 border border-white/5 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-sm font-bold text-zinc-400">
                      {user.name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm font-medium truncate">{user.name}</p>
                      <p className="text-zinc-500 text-xs truncate">{user.email}</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                        user.status === 'Active' ? 'bg-lime-400/10 text-lime-400' : 'bg-red-400/10 text-red-400'
                      }`}>
                        {user.plan}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'plans' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="space-y-3">
                {['Fat Loss Shred', 'Muscle Builder Pro', 'Body Recomposition', 'Total Fitness'].map((plan, i) => (
                  <div key={i} className="bg-zinc-900/80 rounded-xl p-4 border border-white/5">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-white font-semibold text-sm">{plan}</h3>
                      <span className="text-zinc-500 text-xs">{[342, 218, 156, 89][i]} users</span>
                    </div>
                    <div className="flex gap-2">
                      <span className="text-xs px-2 py-0.5 rounded bg-zinc-800 text-zinc-400">Gym</span>
                      <span className="text-xs px-2 py-0.5 rounded bg-zinc-800 text-zinc-400">Home</span>
                      <span className="text-xs px-2 py-0.5 rounded bg-zinc-800 text-zinc-400">3 Days</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'subscriptions' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="grid grid-cols-3 gap-3 mb-4">
                {[
                  { plan: 'Monthly', count: 312, revenue: '₹1.5L' },
                  { plan: 'Quarterly', count: 456, revenue: '₹5.4L' },
                  { plan: 'Yearly', count: 256, revenue: '₹7.6L' },
                ].map((item, i) => (
                  <div key={i} className="bg-zinc-900/80 rounded-xl p-3 border border-white/5 text-center">
                    <p className="text-white font-bold text-sm">{item.count}</p>
                    <p className="text-zinc-500 text-xs">{item.plan}</p>
                    <p className="text-lime-400 text-xs font-medium">{item.revenue}</p>
                  </div>
                ))}
              </div>
              <div className="bg-zinc-900/80 rounded-xl p-4 border border-white/5">
                <h3 className="text-white font-semibold text-sm mb-3">MRR Breakdown</h3>
                <div className="h-40">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={[{ name: 'M', Monthly: 155000, Quarterly: 182000, Yearly: 63000 }]}>
                      <XAxis dataKey="name" hide />
                      <YAxis hide />
                      <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', color: '#fff' }} />
                      <Bar dataKey="Monthly" stackId="a" fill="#A3E635" radius={[0, 0, 0, 0]} />
                      <Bar dataKey="Quarterly" stackId="a" fill="#22D3EE" />
                      <Bar dataKey="Yearly" stackId="a" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'notifications' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-4">
                <h3 className="text-white font-semibold text-sm mb-3">Send Notification</h3>
                <Input placeholder="Title" className="bg-zinc-800 border-white/10 text-white mb-2 h-10" />
                <Input placeholder="Message" className="bg-zinc-800 border-white/10 text-white mb-3 h-10" />
                <div className="flex gap-2 mb-3">
                  {['All', 'Free', 'Premium'].map((target) => (
                    <button key={target} className="px-3 py-1.5 rounded-lg bg-zinc-800 text-zinc-400 text-xs hover:bg-zinc-700">
                      {target}
                    </button>
                  ))}
                </div>
                <Button className="bg-lime-400 hover:bg-lime-300 text-black font-bold w-full">
                  Send Notification
                </Button>
              </div>

              <h3 className="text-white font-semibold text-sm mb-2">Recent</h3>
              <div className="space-y-2">
                {[
                  { title: 'New Batch Starting!', msg: 'Share with your friends', time: '2h ago' },
                  { title: 'Weekend Challenge', msg: 'Complete 3 workouts this weekend', time: '1d ago' },
                ].map((notif, i) => (
                  <div key={i} className="bg-zinc-900/80 rounded-xl p-3 border border-white/5">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-white text-sm font-medium">{notif.title}</span>
                      <span className="text-zinc-600 text-xs">{notif.time}</span>
                    </div>
                    <p className="text-zinc-400 text-xs">{notif.msg}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'translations' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="space-y-3">
                {['Hinglish', 'English', 'Hindi', 'Tamil', 'Telugu'].map((lang, i) => (
                  <div key={i} className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 flex items-center justify-between">
                    <div>
                      <p className="text-white font-semibold text-sm">{lang}</p>
                      <p className="text-zinc-500 text-xs">{[98, 100, 95, 88, 82][i]}% translated</p>
                    </div>
                    <div className="w-16">
                      <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-lime-400 rounded-full"
                          style={{ width: `${[98, 100, 95, 88, 82][i]}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
