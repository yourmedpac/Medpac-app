'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { Activity, Dumbbell, UtensilsCrossed, Sparkles, ArrowRight, Target, TrendingUp, Shield, Loader2, Brain, Heart, Zap, Clock, Scale, Ruler } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell } from 'recharts';
import { useEffect, useState } from 'react';
import type { ScreenName } from '@/lib/types';
import type { AIReport as AIReportType } from '@/lib/ai';

export default function AIReport() {
  const { scoringResult, navigate, language, quizAnswers, aiReport, setAIReport, isGeneratingReport, setGeneratingReport } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const scores = scoringResult;
  const [report, setReport] = useState<AIReportType | null>(aiReport);

  const bodyScore = scores?.overallScore ?? 72;
  const circumference = 2 * Math.PI * 60;
  const strokeDashoffset = circumference - (bodyScore / 100) * circumference;

  // Fetch AI report on mount
  useEffect(() => {
    if (aiReport) {
      setReport(aiReport);
      return;
    }
    if (!quizAnswers || !scores || Object.keys(quizAnswers).length === 0) return;

    const fetchReport = async () => {
      setGeneratingReport(true);
      try {
        const res = await fetch('/api/report', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            answers: quizAnswers,
            scores,
          }),
        });
        const data = await res.json();
        if (data.success && data.report) {
          setReport(data.report);
          setAIReport(data.report);
        }
      } catch (err) {
        console.error('Failed to fetch AI report:', err);
      } finally {
        setGeneratingReport(false);
      }
    };

    fetchReport();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Dynamic prediction data from AI report
  const predictionData = report ? [
    { month: 'Month 1', current: 30, predicted: parseInt(report.month1Prediction?.strengthGain || '20') },
    { month: 'Month 2', current: 30, predicted: parseInt(report.month2Prediction?.strengthGain || '40') },
    { month: 'Month 3', current: 30, predicted: parseInt(report.month3Prediction?.strengthGain || '60') },
  ] : [
    { month: 'Month 1', current: 30, predicted: 55 },
    { month: 'Month 2', current: 30, predicted: 72 },
    { month: 'Month 3', current: 30, predicted: 88 },
  ];

  // Loading state
  if (isGeneratingReport && !report) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center max-w-xs"
        >
          <div className="relative w-24 h-24 mx-auto mb-6">
            <div className="absolute inset-0 rounded-full border-2 border-lime-400/30 animate-ping" />
            <div className="absolute inset-2 rounded-full border-2 border-lime-400/50 animate-pulse" />
            <div className="absolute inset-0 flex items-center justify-center">
              <Brain className="w-10 h-10 text-lime-400" />
            </div>
          </div>
          <h2 className="text-xl font-bold text-white mb-2">AI Analyzing Your Body...</h2>
          <p className="text-zinc-400 text-sm mb-4">
            Our AI is reading your quiz answers, calculating your scores, and building a personalized transformation roadmap.
          </p>
          <div className="flex items-center justify-center gap-2 text-lime-400 text-sm">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>This takes 5-10 seconds</span>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black px-6 py-6">
      <div className="max-w-md mx-auto">
        {/* Header Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-6"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-lime-400/10 border border-lime-400/30 mb-4">
            <Sparkles className="w-4 h-4 text-lime-400" />
            <span className="text-lime-400 text-sm font-semibold">{t('aiAnalysisComplete', lang)}</span>
          </div>
          <h1 className="text-2xl font-bold text-white">{t('transformationRoadmap', lang)}</h1>
        </motion.div>

        {/* AI Summary */}
        {report?.summary && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-lime-400/5 rounded-xl p-4 border border-lime-400/20 mb-4"
          >
            <div className="flex items-start gap-3">
              <Brain className="w-5 h-5 text-lime-400 flex-shrink-0 mt-0.5" />
              <p className="text-zinc-200 text-sm leading-relaxed">{report.summary}</p>
            </div>
          </motion.div>
        )}

        {/* BMI Card */}
        {scores && scores.bmi && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.15 }}
            className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-4"
          >
            <div className="flex items-center gap-2 mb-3">
              <Scale className="w-4 h-4 text-lime-400" />
              <h3 className="text-white font-semibold text-sm">Your BMI</h3>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-extrabold text-lime-400">{scores.bmi}</span>
                <span className={`text-sm font-bold ${
                  scores.bmiCategory === 'Normal' ? 'text-lime-400' :
                  scores.bmiCategory === 'Overweight' ? 'text-orange-400' :
                  scores.bmiCategory === 'Obese' ? 'text-red-400' :
                  'text-blue-400'
                }`}>{scores.bmiCategory}</span>
              </div>
              <div className="text-right">
                <p className="text-zinc-500 text-xs">Height</p>
                <p className="text-white text-sm font-semibold">{scores.height} cm</p>
              </div>
              <div className="text-right">
                <p className="text-zinc-500 text-xs">Weight</p>
                <p className="text-white text-sm font-semibold">{scores.weight} kg</p>
              </div>
              <div className="text-right">
                <p className="text-zinc-500 text-xs">Target</p>
                <p className="text-lime-400 text-sm font-semibold">{scores.targetWeight} kg</p>
              </div>
            </div>
            {/* BMI Scale Bar */}
            <div className="mt-3 relative">
              <div className="h-2 rounded-full bg-gradient-to-r from-blue-400 via-lime-400 via-50% to-orange-400 to-red-400" />
              <div
                className="absolute top-0 w-3 h-3 bg-white rounded-full border-2 border-black shadow-lg transform -translate-y-0.5"
                style={{ left: `${Math.min(Math.max(((scores.bmi - 15) / 25) * 100, 0), 100)}%` }}
              />
              <div className="flex justify-between text-zinc-600 text-[10px] mt-1">
                <span>15</span>
                <span>18.5</span>
                <span>25</span>
                <span>30</span>
                <span>40</span>
              </div>
            </div>
            {/* AI BMI Analysis */}
            {report?.bmiAnalysis && (
              <p className="text-zinc-400 text-xs mt-3 leading-relaxed">{report.bmiAnalysis}</p>
            )}
          </motion.div>
        )}

        {/* Body Score */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-zinc-900/80 rounded-xl p-6 border border-white/5 text-center mb-4"
        >
          <h3 className="text-zinc-400 text-sm font-medium mb-4">{t('bodyScore', lang)}</h3>
          <div className="relative w-32 h-32 mx-auto mb-4">
            <svg className="w-32 h-32 circular-progress" viewBox="0 0 140 140">
              <circle cx="70" cy="70" r="60" fill="none" stroke="#27272A" strokeWidth="8" />
              <circle
                cx="70" cy="70" r="60" fill="none"
                stroke="#A3E635" strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-1000"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-extrabold text-lime-400">{bodyScore}</span>
              <span className="text-zinc-500 text-xs">/100</span>
            </div>
          </div>
          {/* AI Body Analysis */}
          {report?.bodyAnalysis ? (
            <p className="text-zinc-300 text-sm">{report.bodyAnalysis}</p>
          ) : (
            <p className="text-zinc-400 text-sm">
              {scores?.fitnessLevel === 'beginner' ? 'Aap beginner ho aur aapko simple structure chahiye.' :
               scores?.fitnessLevel === 'novice' ? 'Aap kuch experience rakhte ho, next level pe jaane ka time hai.' :
               'Aap intermediate ho, proper periodization se best results aayenge.'}
            </p>
          )}
        </motion.div>

        {/* Strengths & Weaknesses */}
        {report && (
          <div className="grid grid-cols-2 gap-3 mb-4">
            {report.strengths && report.strengths.length > 0 && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.25 }}
                className="bg-zinc-900/80 rounded-xl p-4 border border-lime-400/10"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-lime-400" />
                  <h4 className="text-lime-400 text-xs font-semibold">Strengths</h4>
                </div>
                <ul className="space-y-1.5">
                  {report.strengths.map((s, i) => (
                    <li key={i} className="text-zinc-300 text-xs flex items-start gap-1.5">
                      <span className="text-lime-400 mt-0.5">+</span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            )}
            {report.weaknesses && report.weaknesses.length > 0 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-zinc-900/80 rounded-xl p-4 border border-orange-400/10"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-4 h-4 text-orange-400" />
                  <h4 className="text-orange-400 text-xs font-semibold">Focus Areas</h4>
                </div>
                <ul className="space-y-1.5">
                  {report.weaknesses.map((w, i) => (
                    <li key={i} className="text-zinc-300 text-xs flex items-start gap-1.5">
                      <span className="text-orange-400 mt-0.5">!</span>
                      <span>{w}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            )}
          </div>
        )}

        {/* 90-Day Prediction Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-4"
        >
          <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-lime-400" />
            {t('dayPrediction', lang)}
          </h3>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={predictionData} barGap={8}>
                <XAxis
                  dataKey="month"
                  tick={{ fill: '#71717A', fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis hide />
                <Bar dataKey="current" radius={[4, 4, 0, 0]}>
                  {predictionData.map((_, i) => (
                    <Cell key={i} fill="#27272A" />
                  ))}
                </Bar>
                <Bar dataKey="predicted" radius={[4, 4, 0, 0]}>
                  {predictionData.map((_, i) => (
                    <Cell key={i} fill="#A3E635" />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="flex items-center justify-center gap-6 mt-2">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-zinc-700" />
              <span className="text-zinc-500 text-xs">Current</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-lime-400" />
              <span className="text-zinc-500 text-xs">Predicted</span>
            </div>
          </div>
          {/* AI Prediction Details */}
          {report && (
            <div className="mt-3 space-y-2 pt-3 border-t border-white/5">
              {[
                { label: 'Month 1', data: report.month1Prediction },
                { label: 'Month 2', data: report.month2Prediction },
                { label: 'Month 3', data: report.month3Prediction },
              ].map((m, i) => (
                <div key={i} className="flex items-center justify-between text-xs">
                  <span className="text-zinc-500">{m.label}</span>
                  <div className="text-right">
                    <span className="text-zinc-300">{m.data?.weightChange || '—'}</span>
                    <span className="text-zinc-600 mx-1">|</span>
                    <span className="text-lime-400">{m.data?.confidence || '—'}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>

        {/* AI Advice Cards */}
        {report && (
          <div className="space-y-3 mb-4">
            {report.dietAdvice && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.45 }}
                className="bg-zinc-900/80 rounded-xl p-4 border border-white/5"
              >
                <div className="flex items-center gap-2 mb-2">
                  <UtensilsCrossed className="w-4 h-4 text-lime-400" />
                  <h4 className="text-white text-sm font-semibold">Diet Advice</h4>
                </div>
                <p className="text-zinc-300 text-sm">{report.dietAdvice}</p>
              </motion.div>
            )}
            {report.workoutAdvice && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-zinc-900/80 rounded-xl p-4 border border-white/5"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Dumbbell className="w-4 h-4 text-lime-400" />
                  <h4 className="text-white text-sm font-semibold">Workout Advice</h4>
                </div>
                <p className="text-zinc-300 text-sm">{report.workoutAdvice}</p>
              </motion.div>
            )}
            {report.lifestyleAdvice && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.55 }}
                className="bg-zinc-900/80 rounded-xl p-4 border border-white/5"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Heart className="w-4 h-4 text-lime-400" />
                  <h4 className="text-white text-sm font-semibold">Lifestyle</h4>
                </div>
                <p className="text-zinc-300 text-sm">{report.lifestyleAdvice}</p>
              </motion.div>
            )}
          </div>
        )}

        {/* Diet & Training Cards */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-zinc-900/80 rounded-xl p-4 border border-white/5"
          >
            <UtensilsCrossed className="w-6 h-6 text-lime-400 mb-2" />
            <h4 className="text-white font-semibold text-sm mb-1">Diet</h4>
            <p className="text-zinc-400 text-xs">{report?.dietRecommendation?.type || 'Custom Plan'}</p>
            <p className="text-lime-400 text-xs mt-1">{report?.dietRecommendation?.calories || '—'} kcal • {report?.dietRecommendation?.protein || '—'}g protein</p>
            {report?.dietRecommendation?.reason && (
              <p className="text-zinc-600 text-xs mt-1">{report.dietRecommendation.reason}</p>
            )}
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.65 }}
            className="bg-zinc-900/80 rounded-xl p-4 border border-white/5"
          >
            <Dumbbell className="w-6 h-6 text-lime-400 mb-2" />
            <h4 className="text-white font-semibold text-sm mb-1">Training</h4>
            <p className="text-zinc-400 text-xs">{report?.workoutRecommendation?.splitType || 'Custom Split'}</p>
            <p className="text-lime-400 text-xs mt-1">{report?.workoutRecommendation?.daysPerWeek || '—'}x/week • {report?.workoutRecommendation?.sessionDuration || '—'}</p>
            {report?.workoutRecommendation?.focus && (
              <p className="text-zinc-600 text-xs mt-1">{report.workoutRecommendation.focus}</p>
            )}
          </motion.div>
        </div>

        {/* Score Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-4 space-y-3"
        >
          <h4 className="text-white font-semibold text-sm mb-2">Score Breakdown</h4>
          {[
            { label: 'Readiness', value: scores?.readinessScore ?? 70, icon: Target },
            { label: 'Consistency', value: scores?.consistencyScore ?? 65, icon: Activity },
            { label: 'Transformation', value: scores?.bodyTransformationScore ?? 72, icon: TrendingUp },
            { label: 'Nutrition', value: scores?.nutritionComplianceScore ?? 60, icon: UtensilsCrossed },
            { label: 'Support Need', value: 100 - (scores?.supportNeedScore ?? 50), icon: Shield },
          ].map((item, i) => (
            <div key={i}>
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <item.icon className="w-3.5 h-3.5 text-zinc-500" />
                  <span className="text-zinc-400 text-xs">{item.label}</span>
                </div>
                <span className="text-white text-xs font-bold">{item.value}%</span>
              </div>
              <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-lime-400 rounded-full transition-all duration-1000"
                  style={{ width: `${item.value}%` }}
                />
              </div>
            </div>
          ))}
        </motion.div>

        {/* Motivational Message */}
        {report?.motivationalMessage && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="bg-gradient-to-r from-lime-400/10 to-orange-400/10 rounded-xl p-4 border border-lime-400/20 mb-6"
          >
            <div className="flex items-start gap-3">
              <Zap className="w-5 h-5 text-orange-400 flex-shrink-0 mt-0.5" />
              <p className="text-white text-sm font-medium italic">"{report.motivationalMessage}"</p>
            </div>
          </motion.div>
        )}

        {/* CTA */}
        <Button
          onClick={() => {
            // Generate plans when unlocking
            navigate('paywall' as ScreenName);
          }}
          className="w-full bg-lime-400 hover:bg-lime-300 text-black font-bold h-12 rounded-xl neon-glow text-lg"
        >
          {t('unlockFullPlan', lang)}
          <ArrowRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </div>
  );
}
