'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { Copy, Share2, Gift, Users, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

export default function ReferralScreen() {
  const { referral, language } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (referral?.code) {
      navigator.clipboard?.writeText(referral.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-md mx-auto px-6 py-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-2xl font-bold text-white mb-2">Referral Program</h1>
          <p className="text-zinc-400 text-sm mb-6">Invite friends & earn rewards! 🎁</p>

          {/* Referral Code */}
          <div className="bg-zinc-900/80 rounded-xl p-6 border border-white/5 text-center mb-4">
            <Gift className="w-10 h-10 text-lime-400 mx-auto mb-3" />
            <p className="text-zinc-400 text-sm mb-2">Your Referral Code</p>
            <div className="flex items-center justify-center gap-2 mb-4">
              <span className="text-2xl font-extrabold text-lime-400 tracking-wider">
                {referral?.code || 'FITMUSCLES10'}
              </span>
              <button
                onClick={handleCopy}
                className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 transition-colors"
              >
                {copied ? (
                  <Check className="w-4 h-4 text-lime-400" />
                ) : (
                  <Copy className="w-4 h-4 text-zinc-400" />
                )}
              </button>
            </div>
            <Button className="bg-lime-400 hover:bg-lime-300 text-black font-bold rounded-xl px-6">
              <Share2 className="w-4 h-4 mr-2" />
              Share Code
            </Button>
          </div>

          {/* Rewards */}
          <div className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-4">
            <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
              <Gift className="w-4 h-4 text-lime-400" />
              Earned Rewards
            </h3>
            {referral?.rewards && referral.rewards.length > 0 ? (
              <div className="space-y-2">
                {referral.rewards.map((reward, i) => (
                  <div key={i} className="flex items-center justify-between py-2">
                    <div className="flex items-center gap-2">
                      <span className="text-lime-400 text-sm">🏆</span>
                      <span className="text-zinc-300 text-sm">{reward.value}</span>
                    </div>
                    <span className="text-zinc-500 text-xs">{reward.earnedAt}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-zinc-500 text-sm">No rewards yet. Start sharing!</p>
            )}
          </div>

          {/* Invited Users */}
          <div className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-4">
            <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
              <Users className="w-4 h-4 text-lime-400" />
              Invited Friends
            </h3>
            {referral?.invitedUsers && referral.invitedUsers.length > 0 ? (
              <div className="space-y-2">
                {referral.invitedUsers.map((user, i) => (
                  <div key={i} className="flex items-center justify-between py-2">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-sm font-bold text-zinc-400">
                        {user.name.charAt(0)}
                      </div>
                      <span className="text-zinc-300 text-sm">{user.name}</span>
                    </div>
                    <span className="text-lime-400 text-xs font-medium">{user.status}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-zinc-500 text-sm">No invites yet</p>
            )}
          </div>

          {/* How it works */}
          <div className="bg-lime-400/5 rounded-xl p-4 border border-lime-400/20">
            <h3 className="text-white font-semibold mb-2">How it works</h3>
            <div className="space-y-2">
              {[
                'Share your referral code with friends',
                'Friend signs up using your code',
                'You both get 10% off on subscription',
                'No limit on referrals! 🎉',
              ].map((step, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-lime-400 text-xs font-bold">{i + 1}.</span>
                  <span className="text-zinc-300 text-sm">{step}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
