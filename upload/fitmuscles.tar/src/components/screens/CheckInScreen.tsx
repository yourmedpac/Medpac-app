'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Minus, Plus, Droplets } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import type { CheckIn, ScreenName } from '@/lib/types';

const moods = [
  { id: 'sore' as const, label: 'Sore', icon: '😣', color: 'text-red-400' },
  { id: 'tired' as const, label: 'Tired', icon: '😴', color: 'text-yellow-400' },
  { id: 'good' as const, label: 'Good', icon: '😊', color: 'text-lime-400' },
  { id: 'energized' as const, label: 'Energized', icon: '🔥', color: 'text-orange-400' },
];

export default function CheckInScreen() {
  const { navigate, language, addCheckIn, streak, mealPlan, workoutPlan } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const [workoutDone, setWorkoutDone] = useState<boolean | null>(null);
  const proteinTarget = mealPlan?.dailyProtein || 120;
  const [protein, setProtein] = useState(Math.round(proteinTarget * 0.7));
  const [water, setWater] = useState(2);
  const [mood, setMood] = useState<'sore' | 'tired' | 'good' | 'energized' | null>(null);
  const [logged, setLogged] = useState(false);

  const handleLog = () => {
    const checkIn: CheckIn = {
      id: 'ci_' + Date.now(),
      date: new Date().toISOString(),
      workoutDone: workoutDone ?? false,
      proteinIntake: protein,
      waterIntake: water,
      mood: mood ?? 'good',
    };
    addCheckIn(checkIn);
    setLogged(true);
    setTimeout(() => navigate('dashboard' as ScreenName), 1500);
  };

  if (logged) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="text-center"
        >
          <span className="text-6xl mb-4 block">🎉</span>
          <h2 className="text-2xl font-bold text-white mb-2">Day Logged!</h2>
          <p className="text-lime-400 font-semibold">{streak + 1} Day Streak! 🔥</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-md mx-auto px-6 py-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-extrabold text-white mb-2">{t('timeToLockIn', lang)}</h1>
          <p className="text-zinc-400">{t('crushedGoals', lang)}</p>
        </motion.div>

        {/* Workout Done */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6"
        >
          <h3 className="text-white font-semibold mb-3">Workout done?</h3>
          <div className="flex gap-3">
            <button
              onClick={() => setWorkoutDone(true)}
              className={`flex-1 py-3 px-4 rounded-xl font-bold text-sm transition-all ${
                workoutDone === true
                  ? 'bg-lime-400 text-black neon-glow'
                  : 'bg-zinc-900 text-zinc-400 border border-white/5 hover:border-white/20'
              }`}
            >
              💪 {t('hellYes', lang)}
            </button>
            <button
              onClick={() => setWorkoutDone(false)}
              className={`flex-1 py-3 px-4 rounded-xl font-bold text-sm transition-all ${
                workoutDone === false
                  ? 'bg-zinc-700 text-white'
                  : 'bg-zinc-900 text-zinc-400 border border-white/5 hover:border-white/20'
              }`}
            >
              😴 {t('restDay', lang)}
            </button>
          </div>
        </motion.div>

        {/* Protein - Dynamic target from meal plan */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <h3 className="text-white font-semibold mb-3">{t('proteinTargetHit', lang)}</h3>
          <div className="bg-zinc-900/80 rounded-xl p-4 border border-white/5">
            <div className="text-center mb-3">
              <span className="text-3xl font-extrabold text-lime-400">{protein}g</span>
              <span className="text-zinc-500 text-sm ml-1">/ {proteinTarget}g</span>
            </div>
            <Slider
              value={[protein]}
              onValueChange={(v) => setProtein(v[0])}
              min={0}
              max={Math.max(proteinTarget * 1.5, 200)}
              step={5}
              className="w-full"
            />
            <div className="flex justify-between text-zinc-500 text-xs mt-2">
              <span>0g</span>
              <span className={protein >= proteinTarget ? 'text-lime-400 font-bold' : ''}>
                {protein >= proteinTarget ? '✓ Target hit!' : `${proteinTarget}g target`}
              </span>
            </div>
          </div>
        </motion.div>

        {/* Water */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-6"
        >
          <h3 className="text-white font-semibold mb-3">{t('waterIntake', lang)}</h3>
          <div className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 flex items-center justify-between">
            <button
              onClick={() => setWater(Math.max(0, water - 0.5))}
              className="w-12 h-12 rounded-xl bg-zinc-800 text-white flex items-center justify-center hover:bg-zinc-700"
            >
              <Minus className="w-5 h-5" />
            </button>
            <div className="text-center">
              <Droplets className="w-6 h-6 text-blue-400 mx-auto mb-1" />
              <span className="text-2xl font-extrabold text-white">{water}</span>
              <span className="text-zinc-500 text-sm ml-1">Liters</span>
            </div>
            <button
              onClick={() => setWater(Math.min(6, water + 0.5))}
              className="w-12 h-12 rounded-xl bg-zinc-800 text-white flex items-center justify-center hover:bg-zinc-700"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </motion.div>

        {/* Mood */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-8"
        >
          <h3 className="text-white font-semibold mb-3">{t('howYouFeel', lang)}</h3>
          <div className="grid grid-cols-4 gap-2">
            {moods.map((m) => (
              <button
                key={m.id}
                onClick={() => setMood(m.id)}
                className={`py-3 px-2 rounded-xl text-center transition-all ${
                  mood === m.id
                    ? 'bg-lime-400/10 border-2 border-lime-400'
                    : 'bg-zinc-900 border-2 border-transparent hover:border-white/10'
                }`}
              >
                <span className="text-2xl block mb-1">{m.icon}</span>
                <span className={`text-xs font-medium ${mood === m.id ? 'text-lime-400' : 'text-zinc-400'}`}>
                  {m.label}
                </span>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Log Button */}
        <Button
          onClick={handleLog}
          disabled={workoutDone === null || mood === null}
          className={`w-full h-14 rounded-xl font-bold text-lg transition-all ${
            workoutDone !== null && mood !== null
              ? 'bg-lime-400 hover:bg-lime-300 text-black neon-glow'
              : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
          }`}
        >
          {t('logDay', lang)}
        </Button>
      </div>
    </div>
  );
}
