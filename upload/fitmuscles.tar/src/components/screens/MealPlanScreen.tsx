'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion, AnimatePresence } from 'framer-motion';
import { UtensilsCrossed, Flame, RotateCcw, Zap, Sparkles, Loader2, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import type { Meal, ScreenName } from '@/lib/types';
import type { AIMealSwap } from '@/lib/ai';

export default function MealPlanScreen() {
  const { mealPlan, setMealPlan, language, quizAnswers, workoutPlan, isSwappingMeal, setSwappingMeal } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const [swappingMealId, setSwappingMealId] = useState<string | null>(null);
  const [swapSuggestion, setSwapSuggestion] = useState<AIMealSwap | null>(null);

  const plan = mealPlan;

  // Guard: if no plan yet, show loading
  if (!plan) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <UtensilsCrossed className="w-8 h-8 text-lime-400 animate-pulse mx-auto mb-3" />
          <p className="text-zinc-400 text-sm">Loading your meal plan...</p>
        </div>
      </div>
    );
  }

  const mealIcons: Record<string, string> = {
    breakfast: '🌅',
    lunch: '☀️',
    snack: '🍎',
    dinner: '🌙',
  };

  // Calculate remaining calories/protein
  const totalConsumed = plan.meals.reduce((s, m) => s + m.totalCalories, 0);
  const totalProtein = plan.meals.reduce((s, m) => s + m.totalProtein, 0);

  const handleSwapMeal = async (meal: Meal) => {
    setSwappingMealId(meal.id);
    setSwappingMeal(true);

    try {
      const res = await fetch('/api/meal-swap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentMeal: {
            name: meal.name,
            type: meal.type,
            totalCalories: meal.totalCalories,
            totalProtein: meal.totalProtein,
          },
          answers: quizAnswers,
          remainingCalories: (plan.dailyCalories || 2000) - totalConsumed + meal.totalCalories,
          remainingProtein: (plan.dailyProtein || 120) - totalProtein + meal.totalProtein,
        }),
      });
      const data = await res.json();
      if (data.success && data.swap) {
        setSwapSuggestion({ ...data.swap, mealId: meal.id });
      }
    } catch (err) {
      console.error('Meal swap failed:', err);
    } finally {
      setSwappingMeal(false);
    }
  };

  const acceptSwap = () => {
    if (!swapSuggestion || !mealPlan) return;
    const mealId = (swapSuggestion as { mealId?: string }).mealId;
    const updatedMeals = mealPlan.meals.map(m => {
      if (m.id === mealId) {
        return {
          ...m,
          name: swapSuggestion.name,
          items: swapSuggestion.items,
          totalCalories: swapSuggestion.totalCalories,
          totalProtein: swapSuggestion.totalProtein,
          swapped: true,
        };
      }
      return m;
    });
    setMealPlan({ ...mealPlan, meals: updatedMeals });
    setSwapSuggestion(null);
    setSwappingMealId(null);
  };

  const rejectSwap = () => {
    setSwapSuggestion(null);
    setSwappingMealId(null);
  };

  return (
    <div className="min-h-screen bg-black pb-4">
      <div className="max-w-md mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="pt-2 pb-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-white mb-1">{t('todayGoal', lang)}</h1>
              <p className="text-zinc-500 text-sm">{plan.name}</p>
            </div>
            {plan.id.startsWith('ai_') && (
              <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-lime-400/10 border border-lime-400/20">
                <Sparkles className="w-3 h-3 text-lime-400" />
                <span className="text-lime-400 text-xs font-medium">AI Plan</span>
              </div>
            )}
          </div>
        </motion.div>

        {/* Macro Cards */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 text-center"
          >
            <Flame className="w-6 h-6 text-orange-400 mx-auto mb-2" />
            <p className="text-2xl font-extrabold text-white">{plan.dailyCalories.toLocaleString()}</p>
            <p className="text-zinc-500 text-xs">{t('calories', lang)} kcal/day</p>
            <p className="text-zinc-600 text-xs mt-1">~{totalConsumed} in meals</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 text-center"
          >
            <Zap className="w-6 h-6 text-lime-400 mx-auto mb-2" />
            <p className="text-2xl font-extrabold text-white">{plan.dailyProtein}g</p>
            <p className="text-zinc-500 text-xs">{t('protein', lang)} target/day</p>
            <p className="text-zinc-600 text-xs mt-1">~{totalProtein}g in meals</p>
          </motion.div>
        </div>

        {/* Separator */}
        <div className="flex items-center justify-center mb-4">
          <div className="flex-1 h-px bg-white/5" />
          <span className="px-3 text-zinc-600">🔥</span>
          <div className="flex-1 h-px bg-white/5" />
        </div>

        {/* Meal Cards */}
        <div className="space-y-3">
          {plan.meals.map((meal, i) => (
            <motion.div
              key={meal.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className={`bg-zinc-900/80 rounded-xl p-4 border transition-all ${
                meal.swapped ? 'border-lime-400/30' : 'border-white/5'
              }`}
            >
              {/* Meal Header */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{mealIcons[meal.type] || '🍽️'}</span>
                  <div>
                    <h3 className="text-white font-semibold">{meal.name}</h3>
                    <p className="text-zinc-500 text-xs">{meal.time}</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  onClick={() => handleSwapMeal(meal)}
                  disabled={isSwappingMeal && swappingMealId === meal.id}
                  className="text-lime-400 text-xs h-7 px-2 hover:bg-lime-400/10"
                >
                  {isSwappingMeal && swappingMealId === meal.id ? (
                    <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                  ) : (
                    <RotateCcw className="w-3 h-3 mr-1" />
                  )}
                  {t('swapMeal', lang)}
                </Button>
              </div>

              {/* Items */}
              <div className="space-y-2 mb-3">
                {meal.items.map((item, j) => (
                  <div key={j} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-zinc-500 text-xs">•</span>
                      <span className="text-zinc-300 text-sm">{item.name}</span>
                    </div>
                    <span className="text-zinc-500 text-xs">{item.quantity}</span>
                  </div>
                ))}
              </div>

              {/* Macros */}
              <div className="flex items-center gap-4 pt-2 border-t border-white/5">
                <span className="text-lime-400 text-sm font-semibold">{meal.totalCalories} kcal</span>
                <span className="text-zinc-500 text-sm">{meal.totalProtein}g protein</span>
                {meal.swapped && (
                  <span className="text-lime-400 text-xs ml-auto">AI Swapped</span>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Swap Suggestion Overlay */}
        <AnimatePresence>
          {swapSuggestion && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
              onClick={rejectSwap}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="bg-zinc-900 rounded-2xl p-6 max-w-sm w-full border border-lime-400/20"
                onClick={e => e.stopPropagation()}
              >
                <div className="flex items-center gap-2 mb-4">
                  <Sparkles className="w-5 h-5 text-lime-400" />
                  <h3 className="text-white font-bold text-lg">AI Suggests</h3>
                </div>

                <h4 className="text-lime-400 font-semibold mb-2">{swapSuggestion.name}</h4>

                <div className="space-y-1.5 mb-3">
                  {swapSuggestion.items.map((item, j) => (
                    <div key={j} className="flex justify-between text-sm">
                      <span className="text-zinc-300">{item.name}</span>
                      <span className="text-zinc-500">{item.quantity}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-4 mb-3 pt-2 border-t border-white/5">
                  <span className="text-lime-400 text-sm font-semibold">{swapSuggestion.totalCalories} kcal</span>
                  <span className="text-zinc-400 text-sm">{swapSuggestion.totalProtein}g protein</span>
                </div>

                {swapSuggestion.reason && (
                  <p className="text-zinc-400 text-xs mb-4 italic">{swapSuggestion.reason}</p>
                )}

                <div className="flex gap-3">
                  <Button
                    onClick={acceptSwap}
                    className="flex-1 bg-lime-400 hover:bg-lime-300 text-black font-bold h-11 rounded-xl"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Accept Swap
                  </Button>
                  <Button
                    onClick={rejectSwap}
                    className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-400 font-medium h-11 rounded-xl"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Keep
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
