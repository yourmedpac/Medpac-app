'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { Plus, Dumbbell, Loader2, Sparkles, ChevronDown, ChevronUp, Clock, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useEffect, useState, useRef } from 'react';
import type { WorkoutPlan as WorkoutPlanType, ScreenName } from '@/lib/types';
import type { AIWorkoutPlan } from '@/lib/ai';

export default function WorkoutScreen() {
  const {
    workoutPlan, setWorkoutPlan, navigate, language, quizAnswers,
    scoringResult, isGeneratingPlan, setGeneratingPlan
  } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const [expandedExercise, setExpandedExercise] = useState<string | null>(null);
  const hasFetchedAI = useRef(false);

  // Fetch AI-generated workout plan (only once per mount)
  useEffect(() => {
    // Skip if already have an AI-generated plan
    if (workoutPlan && workoutPlan.id.startsWith('ai_')) {
      return;
    }
    if (!quizAnswers || Object.keys(quizAnswers).length === 0 || hasFetchedAI.current) return;

    const fetchAIPlan = async () => {
      setGeneratingPlan(true);
      hasFetchedAI.current = true;
      try {
        const res = await fetch('/api/plans', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            answers: quizAnswers,
            scores: scoringResult,
          }),
        });
        const data = await res.json();
        if (data.success && data.workoutPlan) {
          const aiPlan = data.workoutPlan as AIWorkoutPlan;
          // Convert AI plan to app format
          const plan: WorkoutPlanType = {
            id: 'ai_wp_' + Date.now(),
            name: aiPlan.name,
            description: aiPlan.description,
            daysPerWeek: aiPlan.daysPerWeek,
            duration: aiPlan.duration || '90 Days',
            days: aiPlan.days.map(d => ({
              id: `day_${d.dayNumber}`,
              dayNumber: d.dayNumber,
              title: d.title,
              exercises: d.exercises.map(e => ({
                id: e.id,
                name: e.name,
                equipment: e.equipment,
                sets: e.sets.map(s => ({ weight: s.weight, reps: s.reps, completed: false })),
                completed: false,
                skipped: false,
                restSeconds: e.restSeconds,
                tips: e.tips,
              })),
              completed: false,
              weekNumber: d.weekNumber,
            })),
            currentDay: 1,
          };
          setWorkoutPlan(plan);
          // Also save meal plan
          if (data.mealPlan) {
            const aiMeal = data.mealPlan;
            const mealPlan = {
              id: 'ai_mp_' + Date.now(),
              name: aiMeal.name,
              dailyCalories: aiMeal.dailyCalories,
              dailyProtein: aiMeal.dailyProtein,
              dietType: quizAnswers.q20 as string || 'non_veg',
              meals: aiMeal.meals.map((m: { id: string; type: string; name: string; time: string; items: { name: string; quantity: string; calories: number; protein: number; carbs: number; fat: number }[]; totalCalories: number; totalProtein: number; swapped: boolean }) => ({
                id: m.id,
                type: m.type as 'breakfast' | 'lunch' | 'snack' | 'dinner',
                name: m.name,
                time: m.time,
                items: m.items,
                totalCalories: m.totalCalories,
                totalProtein: m.totalProtein,
                swapped: m.swapped,
              })),
            };
            useStore.getState().setMealPlan(mealPlan);
          }
        }
      } catch (err) {
        console.error('Failed to fetch AI plan:', err);
      } finally {
        setGeneratingPlan(false);
      }
    };

    fetchAIPlan();
  }, []); // Run once on mount only

  const plan = workoutPlan;

  // Guard: if no plan yet, show loading
  if (!plan) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-lime-400 animate-spin mx-auto mb-3" />
          <p className="text-zinc-400 text-sm">Loading your workout plan...</p>
        </div>
      </div>
    );
  }

  const currentDayIndex = Math.min(plan.currentDay - 1, plan.days.length - 1);
  const currentDay = plan.days[currentDayIndex];
  const completedExercises = currentDay?.exercises.filter(e => e.completed).length || 0;
  const totalExercises = currentDay?.exercises.length || 1;
  const progressPercent = (completedExercises / totalExercises) * 100;

  const handleCompleteExercise = (exerciseIndex: number) => {
    const updatedDays = [...plan.days];
    const updatedExercises = [...updatedDays[currentDayIndex].exercises];
    const exercise = { ...updatedExercises[exerciseIndex] };
    exercise.completed = !exercise.completed;
    exercise.sets = exercise.sets.map(s => ({ ...s, completed: exercise.completed }));
    updatedExercises[exerciseIndex] = exercise;
    updatedDays[currentDayIndex] = {
      ...updatedDays[currentDayIndex],
      exercises: updatedExercises,
    };
    setWorkoutPlan({ ...plan, days: updatedDays });
  };

  const handleSkipExercise = (exerciseIndex: number) => {
    const updatedDays = [...plan.days];
    const updatedExercises = [...updatedDays[currentDayIndex].exercises];
    const exercise = { ...updatedExercises[exerciseIndex] };
    exercise.skipped = !exercise.skipped;
    updatedExercises[exerciseIndex] = exercise;
    updatedDays[currentDayIndex] = {
      ...updatedDays[currentDayIndex],
      exercises: updatedExercises,
    };
    setWorkoutPlan({ ...plan, days: updatedDays });
  };

  // Loading state
  if (isGeneratingPlan && !workoutPlan) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center max-w-xs"
        >
          <div className="relative w-20 h-20 mx-auto mb-4">
            <Dumbbell className="w-10 h-10 text-lime-400 absolute inset-0 m-auto animate-pulse" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Creating Your Plan...</h2>
          <p className="text-zinc-400 text-sm mb-4">
            AI is designing a personalized workout based on your body, goals, and fitness level.
          </p>
          <div className="flex items-center justify-center gap-2 text-lime-400 text-sm">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Generating exercises...</span>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black pb-4">
      <div className="max-w-md mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="pt-2 pb-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-white mb-1">{currentDay?.title || 'Workout'}</h1>
              <p className="text-zinc-500 text-sm">Day {plan.currentDay} {t('dayOf90', lang)}</p>
            </div>
            {plan.id.startsWith('ai_') && (
              <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-lime-400/10 border border-lime-400/20">
                <Sparkles className="w-3 h-3 text-lime-400" />
                <span className="text-lime-400 text-xs font-medium">AI Plan</span>
              </div>
            )}
          </div>
        </motion.div>

        {/* Progress */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-zinc-900/80 rounded-xl p-4 border border-white/5 mb-4"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-zinc-400 text-sm">{t('workoutProgress', lang)}</span>
            <span className="text-lime-400 font-bold text-sm">{Math.round(progressPercent)}%</span>
          </div>
          <Progress value={progressPercent} className="h-2 bg-zinc-800" />
        </motion.div>

        {/* Exercise Cards */}
        <div className="space-y-3">
          {currentDay?.exercises.map((exercise, i) => {
            const isExpanded = expandedExercise === exercise.id;
            const tips = (exercise as { tips?: string; restSeconds?: number }).tips;
            const restSeconds = (exercise as { restSeconds?: number }).restSeconds;

            return (
              <motion.div
                key={exercise.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className={`bg-zinc-900/80 rounded-xl p-4 border transition-all ${
                  exercise.completed ? 'border-lime-400/30' :
                  exercise.skipped ? 'border-zinc-700 opacity-50' :
                  'border-white/5'
                }`}
              >
                <div
                  className="flex items-center justify-between mb-2 cursor-pointer"
                  onClick={() => setExpandedExercise(isExpanded ? null : exercise.id)}
                >
                  <div className="flex-1">
                    <h3 className={`font-bold ${exercise.completed ? 'text-lime-400 line-through' : 'text-white'}`}>
                      {exercise.name}
                    </h3>
                    <div className="flex items-center gap-3 mt-0.5">
                      <p className="text-zinc-500 text-xs">{exercise.equipment}</p>
                      {restSeconds && (
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-zinc-600" />
                          <span className="text-zinc-600 text-xs">{restSeconds}s rest</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {tips && (
                      <Info className="w-3.5 h-3.5 text-lime-400/60" />
                    )}
                    {exercise.completed && (
                      <span className="text-lime-400 text-xs font-semibold">Done</span>
                    )}
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-zinc-500" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-zinc-500" />
                    )}
                  </div>
                </div>

                {/* AI Tips */}
                {isExpanded && tips && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    className="mb-3 p-2 rounded-lg bg-lime-400/5 border border-lime-400/10"
                  >
                    <div className="flex items-start gap-2">
                      <Sparkles className="w-3 h-3 text-lime-400 flex-shrink-0 mt-0.5" />
                      <p className="text-lime-400/80 text-xs">{tips}</p>
                    </div>
                  </motion.div>
                )}

                {/* Sets */}
                <div className="space-y-1.5 mb-3">
                  {exercise.sets.map((set, j) => (
                    <div key={j} className="flex items-center justify-between text-sm">
                      <span className="text-zinc-500 text-xs">Set {j + 1}</span>
                      <span className="text-zinc-300 text-xs">
                        {set.weight > 0 ? `${set.weight}kg x` : ''} {set.reps} reps
                      </span>
                      {set.completed && <span className="text-lime-400 text-xs">✓</span>}
                    </div>
                  ))}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button
                    onClick={() => handleCompleteExercise(i)}
                    className={`flex-1 h-8 text-xs font-semibold rounded-lg ${
                      exercise.completed
                        ? 'bg-lime-400/20 text-lime-400 hover:bg-lime-400/30'
                        : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700 hover:text-white'
                    }`}
                    variant="ghost"
                  >
                    {exercise.completed ? '✓ ' + t('complete', lang) : t('complete', lang)}
                  </Button>
                  <Button
                    onClick={() => handleSkipExercise(i)}
                    className={`h-8 text-xs font-medium rounded-lg ${
                      exercise.skipped
                        ? 'bg-zinc-700 text-zinc-400'
                        : 'bg-zinc-800/50 text-zinc-500 hover:bg-zinc-700 hover:text-zinc-300'
                    }`}
                    variant="ghost"
                  >
                    {t('skip', lang)}
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Add Exercise */}
        <Button
          className="w-full mt-4 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 h-12 rounded-xl border border-dashed border-white/10"
          variant="ghost"
        >
          <Plus className="w-4 h-4 mr-2" />
          {t('addExercise', lang)}
        </Button>

        {/* Day Navigation */}
        <div className="flex gap-2 mt-4 overflow-x-auto pb-2">
          {plan.days.map((day) => (
            <button
              key={day.id}
              onClick={() => {
                setWorkoutPlan({ ...plan, currentDay: day.dayNumber });
              }}
              className={`flex-shrink-0 px-4 py-2 rounded-lg text-xs font-medium transition-all ${
                day.dayNumber === plan.currentDay
                  ? 'bg-lime-400 text-black'
                  : day.completed
                  ? 'bg-lime-400/10 text-lime-400 border border-lime-400/30'
                  : 'bg-zinc-800 text-zinc-400'
              }`}
            >
              D{day.dayNumber}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
