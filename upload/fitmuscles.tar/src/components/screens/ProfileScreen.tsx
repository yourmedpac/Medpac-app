'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Globe, User, Target, Bell, CreditCard, LogOut,
  ChevronRight, Shield, Share2, Crown, Moon, Scale, X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import { calculateBMI } from '@/lib/scoring';
import type { ScreenName, Language } from '@/lib/types';

const languageNames: Record<Language, string> = {
  hinglish: 'Hinglish 🇮🇳',
  en: 'English 🇬🇧',
  hi: 'हिंदी 🇮🇳',
  ta: 'தமிழ் 🇮🇳',
  te: 'తెలుగు 🇮🇳',
};

export default function ProfileScreen() {
  const { navigate, language, user, setUser, subscription, setSubscription, quizAnswers, setQuizAnswer, scoringResult, setScoringResult } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const [showBodyEditor, setShowBodyEditor] = useState(false);
  const [editHeight, setEditHeight] = useState(Number(quizAnswers.q6) || 170);
  const [editWeight, setEditWeight] = useState(Number(quizAnswers.q7) || 75);

  const bmiResult = calculateBMI(editHeight, editWeight);

  const handleLogout = () => {
    setUser(null);
    setSubscription(null);
    navigate('landing' as ScreenName);
  };

  const handleSaveBodyData = () => {
    setQuizAnswer('q6', editHeight);
    setQuizAnswer('q7', editWeight);
    // Recalculate scores with new data
    if (scoringResult) {
      const newScores = { ...scoringResult, bmi: bmiResult.bmi, bmiCategory: bmiResult.category, height: editHeight, weight: editWeight, targetWeight: bmiResult.targetWeight };
      setScoringResult(newScores);
    }
    setShowBodyEditor(false);
  };

  const menuItems = [
    { icon: Globe, label: t('language', lang), value: languageNames[language as Language], action: () => navigate('language' as ScreenName) },
    { icon: Scale, label: t('editBodyData', lang), value: `${quizAnswers.q7 || 75}kg • BMI ${scoringResult?.bmi || '—'}`, action: () => setShowBodyEditor(true) },
    { icon: Target, label: t('changeGoal', lang), value: '', action: () => navigate('quiz' as ScreenName) },
    { icon: Crown, label: 'Subscription', value: subscription?.plan ?? 'Free', action: () => navigate('subscription' as ScreenName) },
    { icon: Bell, label: t('manageNotifications', lang), value: '', action: () => {} },
    { icon: CreditCard, label: t('managePayment', lang), value: '', action: () => navigate('subscription' as ScreenName) },
    { icon: Share2, label: 'Referral', value: '', action: () => navigate('referral' as ScreenName) },
    { icon: Moon, label: 'Dark Mode', value: 'Always On', action: () => {} },
  ];

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-md mx-auto px-6 py-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {/* Profile Header */}
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-2xl bg-lime-400/10 flex items-center justify-center border-2 border-lime-400/30">
              <span className="text-2xl font-bold text-lime-400">
                {user?.name?.charAt(0)?.toUpperCase() || 'F'}
              </span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">{user?.name || 'FitMuscles User'}</h1>
              <p className="text-zinc-500 text-sm">{user?.email || 'user@fitmuscles.com'}</p>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs px-2 py-0.5 rounded-full bg-lime-400/10 text-lime-400 font-medium">
                  {subscription?.plan === 'free' || !subscription ? 'Free Plan' : subscription.plan + ' Plan'}
                </span>
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div className="bg-zinc-900/80 rounded-xl border border-white/5 divide-y divide-white/5 mb-6">
            {menuItems.map((item, i) => (
              <button
                key={i}
                onClick={item.action}
                className="w-full flex items-center gap-4 p-4 hover:bg-white/5 transition-colors"
              >
                <item.icon className="w-5 h-5 text-zinc-400" />
                <span className="flex-1 text-left text-white text-sm">{item.label}</span>
                {item.value && (
                  <span className="text-zinc-500 text-xs">{item.value}</span>
                )}
                <ChevronRight className="w-4 h-4 text-zinc-600" />
              </button>
            ))}
          </div>

          {/* Admin Access */}
          <button
            onClick={() => navigate('admin' as ScreenName)}
            className="w-full flex items-center gap-4 p-4 bg-zinc-900/80 rounded-xl border border-white/5 hover:bg-white/5 transition-colors mb-6"
          >
            <Shield className="w-5 h-5 text-zinc-400" />
            <span className="flex-1 text-left text-white text-sm">Admin Panel</span>
            <ChevronRight className="w-4 h-4 text-zinc-600" />
          </button>

          {/* Logout */}
          <Button
            onClick={handleLogout}
            variant="ghost"
            className="w-full text-red-400 hover:text-red-300 hover:bg-red-400/10 h-12 rounded-xl font-semibold"
          >
            <LogOut className="w-5 h-5 mr-2" />
            {t('logout', lang)}
          </Button>

          {/* App Info */}
          <div className="text-center mt-8">
            <p className="text-zinc-600 text-xs">FitMuscles v1.0.0</p>
            <p className="text-zinc-700 text-xs">Made with 💚 in India</p>
          </div>
        </motion.div>

        {/* Body Data Editor Modal */}
        <AnimatePresence>
          {showBodyEditor && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 z-50 flex items-end sm:items-center justify-center"
              onClick={() => setShowBodyEditor(false)}
            >
              <motion.div
                initial={{ y: 300, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: 300, opacity: 0 }}
                className="bg-zinc-900 rounded-t-2xl sm:rounded-2xl p-6 max-w-sm w-full border border-white/10"
                onClick={e => e.stopPropagation()}
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-white font-bold text-lg">Edit Body Data</h3>
                  <button onClick={() => setShowBodyEditor(false)} className="text-zinc-400 hover:text-white">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Height Slider */}
                <div className="mb-6">
                  <label className="text-zinc-400 text-sm mb-2 block">Height</label>
                  <div className="text-center mb-2">
                    <span className="text-3xl font-extrabold text-lime-400">{editHeight}</span>
                    <span className="text-zinc-400 text-lg ml-1">cm</span>
                  </div>
                  <input
                    type="range"
                    min={140}
                    max={200}
                    step={1}
                    value={editHeight}
                    onChange={(e) => setEditHeight(Number(e.target.value))}
                    className="w-full h-2 bg-zinc-800 rounded-full appearance-none cursor-pointer accent-lime-400"
                  />
                  <div className="flex justify-between text-zinc-500 text-xs mt-1">
                    <span>140 cm</span>
                    <span>200 cm</span>
                  </div>
                </div>

                {/* Weight Slider */}
                <div className="mb-6">
                  <label className="text-zinc-400 text-sm mb-2 block">Weight</label>
                  <div className="text-center mb-2">
                    <span className="text-3xl font-extrabold text-lime-400">{editWeight}</span>
                    <span className="text-zinc-400 text-lg ml-1">kg</span>
                  </div>
                  <input
                    type="range"
                    min={40}
                    max={150}
                    step={0.5}
                    value={editWeight}
                    onChange={(e) => setEditWeight(Number(e.target.value))}
                    className="w-full h-2 bg-zinc-800 rounded-full appearance-none cursor-pointer accent-lime-400"
                  />
                  <div className="flex justify-between text-zinc-500 text-xs mt-1">
                    <span>40 kg</span>
                    <span>150 kg</span>
                  </div>
                </div>

                {/* BMI Result */}
                <div className="bg-zinc-800/50 rounded-xl p-4 mb-6 text-center">
                  <p className="text-zinc-400 text-xs mb-1">Your BMI</p>
                  <p className="text-3xl font-extrabold text-lime-400">{bmiResult.bmi}</p>
                  <p className={`text-sm font-bold ${bmiResult.color} mt-1`}>{bmiResult.category}</p>
                  {bmiResult.category !== 'Normal' && (
                    <p className="text-zinc-500 text-xs mt-2">Target weight: {bmiResult.targetWeight} kg</p>
                  )}
                </div>

                <Button
                  onClick={handleSaveBodyData}
                  className="w-full bg-lime-400 hover:bg-lime-300 text-black font-bold h-12 rounded-xl"
                >
                  Save Changes
                </Button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
