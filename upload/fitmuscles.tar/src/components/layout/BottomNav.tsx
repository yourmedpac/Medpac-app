'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { Calendar, Dumbbell, UtensilsCrossed, BarChart3 } from 'lucide-react';
import type { ScreenName } from '@/lib/types';

const navItems: { id: ScreenName; icon: typeof Calendar; labelKey: 'navToday' | 'navWorkout' | 'navMeals' | 'navReport' }[] = [
  { id: 'dashboard', icon: Calendar, labelKey: 'navToday' },
  { id: 'workout', icon: Dumbbell, labelKey: 'navWorkout' },
  { id: 'meals', icon: UtensilsCrossed, labelKey: 'navMeals' },
  { id: 'progress', icon: BarChart3, labelKey: 'navReport' },
];

export default function BottomNav() {
  const { currentScreen, navigate, language } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-[#0A0A0A]/95 backdrop-blur-lg border-t border-white/10">
      <div className="max-w-md mx-auto flex items-center justify-around py-2 px-2">
        {navItems.map((item) => {
          const isActive = currentScreen === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.id)}
              className={`flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'text-lime-400'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'drop-shadow-[0_0_8px_rgba(163,230,53,0.5)]' : ''}`} />
              <span className={`text-[11px] font-medium ${isActive ? 'text-lime-400' : 'text-zinc-500'}`}>
                {t(item.labelKey, lang)}
              </span>
              {isActive && (
                <div className="w-1 h-1 rounded-full bg-lime-400 mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
