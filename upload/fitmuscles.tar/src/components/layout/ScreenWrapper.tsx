'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { ReactNode } from 'react';

interface ScreenWrapperProps {
  children: ReactNode;
  showNav?: boolean;
}

export default function ScreenWrapper({ children, showNav = false }: ScreenWrapperProps) {
  return (
    <div className="min-h-screen bg-black text-white">
      <div className={`max-w-md mx-auto ${showNav ? 'pb-20' : ''}`}>
        <AnimatePresence mode="wait">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
