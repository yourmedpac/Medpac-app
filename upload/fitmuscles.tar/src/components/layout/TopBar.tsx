'use client';

import { useStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { Globe, Bell, User, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { ScreenName } from '@/lib/types';

interface TopBarProps {
  showBack?: boolean;
  onBack?: () => void;
  title?: string;
}

export default function TopBar({ showBack, onBack, title }: TopBarProps) {
  const { language, navigate, notifications } = useStore();
  const lang = language as 'hinglish' | 'en' | 'hi' | 'ta' | 'te';
  const unreadCount = notifications.filter(n => !n.read).length;

  const isDashboardScreen = ['dashboard', 'workout', 'meals', 'progress'].includes(
    useStore.getState().currentScreen
  );

  return (
    <div className="sticky top-0 z-50 flex items-center justify-between px-4 py-3 bg-black/80 backdrop-blur-lg border-b border-white/5">
      <div className="flex items-center gap-2">
        {showBack && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="text-white hover:bg-white/10 -ml-2"
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
        )}
        {title ? (
          <h1 className="text-white font-semibold text-lg">{title}</h1>
        ) : (
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('landing' as ScreenName)}>
            <div className="w-8 h-8 rounded-lg bg-lime-400 flex items-center justify-center">
              <span className="text-black font-bold text-sm">F</span>
            </div>
            <span className="text-white font-bold text-lg">FitMuscles</span>
          </div>
        )}
      </div>
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="text-zinc-400 hover:text-white hover:bg-white/10"
          onClick={() => navigate('language' as ScreenName)}
        >
          <Globe className="w-5 h-5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="text-zinc-400 hover:text-white hover:bg-white/10 relative"
          onClick={() => navigate('checkin' as ScreenName)}
        >
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 rounded-full text-[10px] text-white flex items-center justify-center">
              {unreadCount}
            </span>
          )}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="text-zinc-400 hover:text-white hover:bg-white/10"
          onClick={() => navigate('profile' as ScreenName)}
        >
          <User className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}
